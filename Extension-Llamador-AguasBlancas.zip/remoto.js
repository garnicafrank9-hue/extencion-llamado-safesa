/*
 * Conexión por internet entre la extensión y el TV (compartido por los dos lados).
 *
 * El TV y las PCs se encuentran en un servidor público de mensajería MQTT. Todo lo que viaja
 * va cifrado con AES-GCM usando una clave que se deriva del código de vinculación del TV:
 * el servidor solo ve datos ilegibles. El nombre del canal también sale del código, así que
 * sin el código no se puede ni encontrar ni leer ni enviar nada al TV.
 */
(function (g) {
  "use strict";

  var ALFABETO = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // sin 0/O ni 1/I para que no se confundan
  var LARGO = 16;
  var SAL = "llamador-aguas-blancas-v1";
  var ITERACIONES = 120000;
  var VENTANA_MS = 10 * 60 * 1000; // mensajes más viejos que esto se descartan (evita repeticiones)

  // Servidores públicos (sin cuenta). El TV escucha en todos; la PC usa el primero que responda.
  var SERVIDORES = ["wss://broker.emqx.io:8084/mqtt", "wss://broker.hivemq.com:8884/mqtt"];

  // Rutas que se pueden pedir por internet. Subir videos y cambiar la vinculación, solo en la red local.
  var RUTAS_PERMITIDAS = ["/llamar", "/estado", "/voces", "/publicidad", "/publicidad/youtube",
    "/publicidad/modificar", "/publicidad/borrar", "/publicidad/reproducir", "/publicidad/detener", "/volumen",
    "/horarios", "/horarios/guardar", "/preparar", "/avisos", "/avisos/guardar", "/avisos/decir", "/actualizar/estado"];

  var enc = new TextEncoder(), dec = new TextDecoder();

  function normalizar(codigo) {
    return String(codigo || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  }

  function valido(codigo) {
    var c = normalizar(codigo);
    if (c.length !== LARGO) return false;
    for (var i = 0; i < c.length; i++) if (ALFABETO.indexOf(c[i]) < 0) return false;
    return true;
  }

  function formatear(codigo) {
    return normalizar(codigo).replace(/(.{4})(?=.)/g, "$1-");
  }

  function aHex(buf) {
    return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ("0" + b.toString(16)).slice(-2); }).join("");
  }
  function aBase64(bytes) {
    var s = ""; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s);
  }
  function deBase64(txt) {
    var s = atob(txt), b = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
    return b;
  }

  var cache = {};
  /** Clave AES y nombres de canal a partir del código. */
  function derivar(codigo) {
    var c = normalizar(codigo);
    if (!valido(c)) return Promise.reject(new Error("el código de vinculación no es válido"));
    if (cache[c]) return cache[c];
    var sutil = (g.crypto || self.crypto).subtle;
    cache[c] = Promise.all([
      sutil.importKey("raw", enc.encode(c), "PBKDF2", false, ["deriveKey"]).then(function (base) {
        return sutil.deriveKey({ name: "PBKDF2", salt: enc.encode(SAL), iterations: ITERACIONES, hash: "SHA-256" },
          base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
      }),
      sutil.digest("SHA-256", enc.encode("canal|" + SAL + "|" + c))
    ]).then(function (r) {
      var canal = "llamador-ab/" + aHex(r[1]).slice(0, 40);
      return { clave: r[0], temaTv: canal + "/tv", temaPc: canal + "/pc" };
    });
    return cache[c];
  }

  function cifrar(clave, obj) {
    var sutil = (g.crypto || self.crypto).subtle;
    var iv = (g.crypto || self.crypto).getRandomValues(new Uint8Array(12));
    return sutil.encrypt({ name: "AES-GCM", iv: iv }, clave, enc.encode(JSON.stringify(obj))).then(function (ct) {
      var todo = new Uint8Array(12 + ct.byteLength);
      todo.set(iv, 0); todo.set(new Uint8Array(ct), 12);
      return aBase64(todo);
    });
  }

  function descifrar(clave, texto) {
    var sutil = (g.crypto || self.crypto).subtle;
    var b = deBase64(String(texto));
    if (b.length < 29) return Promise.reject(new Error("mensaje inválido"));
    return sutil.decrypt({ name: "AES-GCM", iv: b.slice(0, 12) }, clave, b.slice(12)).then(function (pt) {
      return JSON.parse(dec.decode(pt));
    });
  }

  function nuevoId() {
    return aHex((g.crypto || self.crypto).getRandomValues(new Uint8Array(9)));
  }

  /** ¿El mensaje es reciente? (protege contra mensajes viejos reenviados) */
  function reciente(ts) {
    return typeof ts === "number" && Math.abs(Date.now() - ts) < VENTANA_MS;
  }

  g.LlamadorRemoto = {
    ALFABETO: ALFABETO, SERVIDORES: SERVIDORES, RUTAS_PERMITIDAS: RUTAS_PERMITIDAS,
    normalizar: normalizar, valido: valido, formatear: formatear, derivar: derivar,
    cifrar: cifrar, descifrar: descifrar, nuevoId: nuevoId, reciente: reciente
  };
})(typeof self !== "undefined" ? self : this);
