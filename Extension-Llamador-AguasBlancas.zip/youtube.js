// Lectura y verificación de links de YouTube para la publicidad del TV.
(function (g) {
  "use strict";

  const HOSTS = /(^|\.)(youtube\.com|youtube-nocookie\.com|youtu\.be)$/i;

  /**
   * Devuelve { id } con el código del video, o { error } explicando por qué el link no sirve.
   * Acepta: youtu.be/ID?si=…, youtube.com/watch?v=ID&t=…, m.youtube.com, music.youtube.com,
   * /shorts/ID, /live/ID, /embed/ID, /v/ID, o el código de 11 caracteres solo.
   */
  function leerLink(texto) {
    let t = String(texto || "").trim();
    if (!t) return { error: "" };
    // A veces se copia con texto alrededor ("Mirá este video: https://…")
    const enTexto = t.match(/https?:\/\/\S+/i);
    if (enTexto) t = enTexto[0];
    if (/^[A-Za-z0-9_-]{11}$/.test(t)) return { id: t };
    if (!/^https?:\/\//i.test(t)) t = "https://" + t;
    let u;
    try { u = new URL(t); } catch (e) { return { error: "No parece un link. Copiá el link del video con «Compartir» en YouTube." }; }
    if (!HOSTS.test(u.hostname)) return { error: "El link no es de YouTube." };
    let id = null;
    if (/youtu\.be$/i.test(u.hostname)) id = u.pathname.split("/")[1];
    else if (u.searchParams.get("v")) id = u.searchParams.get("v");
    else {
      const m = u.pathname.match(/^\/(?:shorts|live|embed|v|e)\/([^/?#]+)/);
      if (m) id = m[1];
    }
    if (id && /^[A-Za-z0-9_-]{11}$/.test(id)) return { id };
    if (u.searchParams.get("list")) return { error: "Es una lista de reproducción. Abrí un video de la lista y copiá el link de ese video." };
    if (/^\/(@|channel\/|c\/|user\/)/.test(u.pathname)) return { error: "Es el link de un canal. Abrí el video y copiá su link." };
    return { error: "No se encontró el video en el link. Copialo con «Compartir» en YouTube." };
  }

  function linkNormal(id) { return "https://www.youtube.com/watch?v=" + id; }
  function miniatura(id) { return "https://i.ytimg.com/vi/" + id + "/mqdefault.jpg"; }

  const cache = new Map();
  /**
   * Consulta a YouTube título y canal, y si el video se puede mostrar fuera de YouTube.
   * estado: "ok" | "sin-insertar" (el dueño no lo permite) | "no-existe" (privado o borrado) | "desconocido".
   */
  async function verificar(id) {
    if (cache.has(id)) return cache.get(id);
    const control = new AbortController();
    const reloj = setTimeout(() => control.abort(), 7000);
    let r;
    try {
      const resp = await fetch("https://www.youtube.com/oembed?format=json&url=" + encodeURIComponent(linkNormal(id)), { signal: control.signal });
      if (resp.ok) {
        const j = await resp.json();
        r = { estado: "ok", titulo: j.title || "", canal: j.author_name || "" };
      } else if (resp.status === 401 || resp.status === 403) {
        r = { estado: "sin-insertar" };
      } else if (resp.status === 404 || resp.status === 400) {
        r = { estado: "no-existe" };
      } else {
        r = { estado: "desconocido" };
      }
    } catch (e) {
      r = { estado: "desconocido" };
    } finally {
      clearTimeout(reloj);
    }
    if (r.estado !== "desconocido") cache.set(id, r);
    return r;
  }

  g.YouTubeLlamador = { leerLink, linkNormal, miniatura, verificar };
})(this);
