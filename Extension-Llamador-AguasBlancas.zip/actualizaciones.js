// Actualizaciones: estado de la aplicación del TV, búsqueda e instalación, subida manual del APK
// y aviso de versión nueva de esta extensión.
const $ = (id) => document.getElementById(id);
const TRABAJANDO = ["buscando", "descargando", "instalando"];
const MAX_APK = 60 * 1024 * 1024;

let tv = null;            // última respuesta de /actualizar/estado
let via = "local";        // por dónde llegó: "local" o "internet"
let BASE = "";            // dirección del TV en la red local (solo para subir el APK)
let configSucia = false;  // se tocó la configuración y todavía no se guardó
let esperando = null;     // {codigo, desde}: se pidió instalar y se espera que el TV vuelva con la versión nueva
let subiendo = false;
let reloj = 0;

function ocultarMensaje() {
  const e = $("estado");
  clearTimeout(e._t);
  e.className = "mensaje";
  $("pieEstado").hidden = true;
}

function mostrar(msg, ok, esBusqueda) {
  const e = $("estado");
  e.textContent = msg;
  e.className = "mensaje " + (ok ? "ok" : "error");
  e._busqueda = !!esBusqueda;
  $("pieEstado").hidden = false;
  clearTimeout(e._t);
  if (ok) e._t = setTimeout(ocultarMensaje, 9000);
}

function primeraMayuscula(s) { s = String(s); return s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : "."); }

function api(ruta, cuerpo) {
  return new Promise((ok, mal) => {
    chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
      if (chrome.runtime.lastError) return mal(new Error("La extensión no respondió; recargá la página."));
      if (r && r.ok) ok(r); else mal(new Error(primeraMayuscula((r && r.error) || "sin respuesta del TV")));
    });
  });
}

/** Compara versiones tipo 1.16.0: devuelve >0 si a es más nueva que b. */
function comparar(a, b) {
  const x = String(a).split(".").map((n) => parseInt(n, 10) || 0), y = String(b).split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d) return d;
  }
  return 0;
}

function hace(ms) {
  const s = Math.max(0, Math.round(ms / 1000));
  if (s < 90) return "hace instantes";
  const m = Math.round(s / 60);
  if (m < 90) return "hace " + m + " minutos";
  const h = Math.round(m / 60);
  if (h < 36) return "hace " + h + " horas";
  return "hace " + Math.round(h / 24) + " días";
}

// ---------- Dibujo ----------

function insignia(texto, clase) {
  const i = $("insignia");
  i.textContent = texto;
  i.className = "insignia" + (clase ? " " + clase : "");
}

function dibujar() {
  const soloVer = via === "internet";
  $("avisoRed").classList.toggle("visible", soloVer);

  if (!tv) {
    $("versionTv").textContent = "—";
    insignia("Sin conexión con el TV", "error");
    $("textoEstado").textContent = "No se pudo leer el estado del TV. Revisá la conexión en la pestaña «Este consultorio».";
    $("progreso").hidden = true;
    $("metaRevision").textContent = "";
    $("nueva").hidden = true;
    $("buscar").disabled = true;
    $("instalar").hidden = true;
    $("guardarConfig").disabled = true;
    $("subir").disabled = true;
    dibujarExtension();
    return;
  }

  $("versionTv").textContent = tv.version || "—";
  const e = tv.estado;
  if (e === "al-dia") insignia("Al día", "al-dia");
  else if (e === "buscando") insignia("Buscando…", "trabajando");
  else if (e === "descargando") insignia(tv.porcentaje >= 0 ? "Descargando " + tv.porcentaje + " %" : "Descargando…", "trabajando");
  else if (e === "listo") insignia("Lista para instalar", "listo");
  else if (e === "instalando") insignia("Instalando…", "trabajando");
  else if (e === "error") insignia("Con problemas", "error");
  else insignia("Sin configurar", "");

  $("textoEstado").textContent = tv.texto || (e === "al-dia" ? "La aplicación del TV está al día." : "");
  const p = e === "descargando" && tv.porcentaje >= 0;
  $("progreso").hidden = !p;
  if (p) $("progresoBarra").style.width = tv.porcentaje + "%";

  let meta = tv.ultimaRevision ? "Última búsqueda: " + hace(tv.ahora - tv.ultimaRevision) + "." : (tv.configurada ? "Todavía no buscó." : "");
  if (tv.ultima && tv.ultima.versionName) meta += (meta ? " " : "") + "Última actualización: versión " + tv.ultima.versionName + ".";
  $("metaRevision").textContent = meta;

  const n = tv.nueva;
  $("nueva").hidden = !(n && e !== "al-dia");
  if (n) {
    $("nuevaTitulo").textContent = "Versión " + n.versionName + " " + (e === "listo" ? "lista para instalar" : "en camino");
    $("nuevaNotas").textContent = n.notas || "";
    $("nuevaNotas").hidden = !n.notas;
  }

  const ocupado = TRABAJANDO.includes(e) || tv.ocupado;
  if (!ocupado && $("estado")._busqueda) ocultarMensaje();
  $("buscar").disabled = soloVer || !tv.configurada || ocupado;
  $("instalar").hidden = e !== "listo";
  $("instalar").disabled = soloVer;
  $("guardarConfig").disabled = soloVer;
  $("subir").disabled = soloVer || subiendo || ocupado;

  if (!configSucia) {
    if (document.activeElement !== $("urlAct")) $("urlAct").value = tv.url || "";
    $("auto").checked = !!tv.automatica;
    $("solo").checked = !!tv.instalarSolo;
  }
  dibujarExtension();
}

function dibujarExtension() {
  const mia = chrome.runtime.getManifest().version;
  $("versionExt").textContent = mia;
  const ext = tv && tv.extension;
  const nueva = ext && ext.version && comparar(ext.version, mia) > 0;
  $("extNueva").hidden = !nueva;
  if (nueva) {
    $("insigniaExt").textContent = "Hay una versión nueva";
    $("insigniaExt").className = "insignia listo";
    $("extNuevaTitulo").textContent = "Versión " + ext.version + " de la extensión";
    $("extNuevaNotas").textContent = ext.notas || "";
    $("extNuevaNotas").hidden = !ext.notas;
    const enlace = typeof ext.url === "string" && /^https:\/\//i.test(ext.url) ? ext.url : "";
    $("extDescarga").hidden = !enlace;
    if (enlace) $("extEnlace").href = enlace;
  } else if (ext && ext.version) {
    $("insigniaExt").textContent = "Al día";
    $("insigniaExt").className = "insignia al-dia";
  } else {
    $("insigniaExt").textContent = tv ? "Sin datos" : "Sin conexión";
    $("insigniaExt").className = "insignia";
  }
}

// ---------- Lectura periódica ----------

async function leer() {
  clearTimeout(reloj);
  try {
    const r = await api("/actualizar/estado");
    via = r.via === "internet" ? "internet" : "local";
    tv = r;
    if (esperando) {
      if (r.versionCode > esperando.codigo) {
        mostrar("Listo: el TV se actualizó a la versión " + r.version + ".", true);
        esperando = null;
      } else if (r.estado !== "instalando" && Date.now() - esperando.desde > 20000) {
        // Volvió con la misma versión: la instalación no se hizo (el motivo está en el texto del estado).
        mostrar(r.texto || "La instalación no se completó.", false);
        esperando = null;
      }
    }
  } catch (err) {
    if (esperando) {
      // El TV se está reiniciando: es normal que no conteste unos instantes.
      insignia("Reiniciando el TV…", "trabajando");
      $("textoEstado").textContent = "El TV se está reiniciando con la versión nueva. Se vuelve a conectar solo.";
      if (Date.now() - esperando.desde > 5 * 60 * 1000) {
        mostrar("El TV no volvió a conectarse. Revisá que esté encendido; si la pantalla de llamados no abrió sola, abrí la aplicación con el control remoto.", false);
        esperando = null;
      }
      reloj = setTimeout(leer, 2500);
      return;
    }
    tv = null;
  }
  dibujar();
  const rapido = esperando || (tv && (TRABAJANDO.includes(tv.estado) || tv.ocupado));
  reloj = setTimeout(leer, rapido ? 1500 : 8000);
}

// ---------- Acciones ----------

$("buscar").addEventListener("click", async () => {
  $("buscar").disabled = true;
  try {
    tv = Object.assign({}, tv, await api("/actualizar/buscar", {}));
    mostrar("Buscando una versión nueva…", true, true);
  } catch (e) {
    mostrar(e.message, false);
  }
  leer();
});

$("instalar").addEventListener("click", () => {
  const n = tv && tv.nueva;
  $("dlgInstalarTexto").textContent = n
    ? "Se va a instalar la versión " + n.versionName + " (ahora el TV tiene la " + tv.version + ")."
    : "Se va a instalar la versión que está lista.";
  $("dlgInstalar").showModal();
});
$("dlgInstalarCancelar").addEventListener("click", () => $("dlgInstalar").close());
$("dlgInstalarOk").addEventListener("click", async () => {
  $("dlgInstalar").close();
  const codigo = tv ? tv.versionCode : 0;
  try {
    await api("/actualizar/instalar", {});
    esperando = { codigo, desde: Date.now() };
    mostrar("Instalando… la pantalla del TV se reinicia en un momento.", true);
  } catch (e) {
    mostrar(e.message, false);
  }
  leer();
});

["urlAct", "auto", "solo"].forEach((id) => $(id).addEventListener("input", () => { configSucia = true; }));
$("guardarConfig").addEventListener("click", async () => {
  const url = $("urlAct").value.trim();
  if (url && !/^https?:\/\/\S+$/i.test(url)) return mostrar("La dirección tiene que empezar con https://", false);
  try {
    tv = Object.assign({}, tv, await api("/actualizar/configurar", { url, automatica: $("auto").checked, instalarSolo: $("solo").checked }));
    configSucia = false;
    mostrar(url ? "Guardado. Para probar la dirección, tocá «Buscar ahora»." : "Guardado: el TV ya no busca actualizaciones.", true);
    dibujar();
  } catch (e) {
    mostrar(e.message, false);
  }
});

function subirApk(f, instalar) {
  return new Promise((ok, mal) => {
    const x = new XMLHttpRequest();
    x.open("POST", BASE + "/actualizar/subir");
    x.setRequestHeader("X-Instalar", instalar ? "1" : "0");
    x.upload.onprogress = (e) => {
      if (e.lengthComputable) $("barraSubida").firstElementChild.style.width = Math.round(e.loaded / e.total * 100) + "%";
    };
    x.onload = () => {
      let j = {};
      try { j = JSON.parse(x.responseText); } catch (e) { /* vacío */ }
      j.ok ? ok(j) : mal(new Error(primeraMayuscula(j.error || "el TV respondió " + x.status)));
    };
    x.onerror = () => mal(new Error("No se pudo subir: esta PC no llega al TV por la red local."));
    x.timeout = 5 * 60 * 1000;
    x.ontimeout = () => mal(new Error("La subida tardó demasiado."));
    x.send(f);
  });
}

$("subir").addEventListener("click", async () => {
  const f = $("archivoApk").files[0];
  if (!f) return mostrar("Elegí primero el archivo APK.", false);
  if (!/\.apk$/i.test(f.name)) return mostrar("El archivo tiene que ser un APK (termina en .apk).", false);
  if (f.size > MAX_APK) return mostrar("El archivo es demasiado grande para ser la aplicación del TV.", false);
  if (!BASE) return mostrar("Para subir el archivo, esta PC tiene que estar en la misma red que el TV y tener cargada su dirección en «Este consultorio».", false);
  const instalar = $("instalarYa").checked;
  subiendo = true;
  $("subir").disabled = true;
  $("barraSubida").style.display = "block";
  $("barraSubida").firstElementChild.style.width = "0";
  const codigo = tv ? tv.versionCode : 0;
  try {
    await subirApk(f, instalar);
    if (instalar) {
      esperando = { codigo, desde: Date.now() };
      mostrar("Archivo recibido. Instalando… la pantalla del TV se reinicia en un momento.", true);
    } else {
      mostrar("Archivo recibido y verificado. Ya está listo para instalar.", true);
    }
    $("archivoApk").value = "";
  } catch (e) {
    mostrar(e.message, false);
  }
  subiendo = false;
  $("barraSubida").style.display = "none";
  leer();
});

// ---------- Inicio ----------

Almacen.get({ ipTv: "", puerto: 8765, codigo: "" }).then(async (c) => {
  if (c.ipTv) {
    try {
      if (await chrome.permissions.contains({ origins: ["http://" + c.ipTv + "/*"] })) BASE = "http://" + c.ipTv + ":" + (parseInt(c.puerto, 10) || 8765);
    } catch (e) { /* sin permiso */ }
  }
  if (!c.ipTv && !c.codigo) {
    mostrar("Primero configurá la conexión con el TV en la pestaña «Este consultorio».", false);
  }
  dibujar();
  leer();
});
