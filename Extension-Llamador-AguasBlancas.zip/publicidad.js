// Administración de la publicidad del TV: turnos mañana y tarde, horarios, links de YouTube, videos y volumen.
// Todo pasa por la extensión, que elige sola el camino (red local o internet).
const $ = (id) => document.getElementById(id);
const YT = window.YouTubeLlamador;

const TURNOS = {
  manana: { nombre: "Mañana", desde: 7 * 60, hasta: 13 * 60, texto: "07:00 y 13:00" },
  tarde: { nombre: "Tarde", desde: 14 * 60, hasta: 20 * 60, texto: "14:00 y 20:00" }
};

const OTRO = { manana: "tarde", tarde: "manana" };   // turno al que se copia desde cada uno
const DESPLAZAMIENTO = 7 * 60;                        // minutos entre un turno y el otro

let BASE = "";                 // dirección del TV en la red local (solo para subir videos)
let via = "local";
let datos = null;              // última respuesta del TV
let turno = turnoInicial();    // pestaña visible
const seleccion = new Set();
let ordenActual = [];
let editando = null;           // mientras se editan horas, no se refresca la lista
let videoActual = null;        // { id, titulo, estado } del link pegado

// ---------- utilidades ----------

function avisar(msg, ok) {
  const e = $("estado");
  e.textContent = msg;
  e.className = "mensaje " + (ok ? "ok" : "error");
  clearTimeout(avisar._t);
  avisar._t = setTimeout(() => { e.className = "mensaje"; }, ok ? 5000 : 9000);
}

function aMin(h) { const p = h.split(/[:.]/); return +p[0] * 60 + +p[1]; }
function aHora(m) { return String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0"); }
function turnoDe(h) {
  const m = aMin(h);
  for (const k in TURNOS) if (m >= TURNOS[k].desde && m <= TURNOS[k].hasta) return k;
  return "otros";
}
function turnoInicial() {
  try { const t = localStorage.getItem("turnoPublicidad"); if (t === "manana" || t === "tarde") return t; } catch (e) { /* sin almacenamiento */ }
  return new Date().getHours() < 14 ? "manana" : "tarde";
}

/** "8, 10:30 y 9.15" -> ["08:00","09:15","10:30"]; null si alguna no es una hora. */
function leerHoras(texto) {
  const partes = String(texto).split(/[,;\s]+|\by\b/).map((x) => x.trim()).filter(Boolean);
  if (!partes.length) return null;
  const r = [];
  for (const p of partes) {
    const m = p.match(/^([01]?\d|2[0-3])(?:[:.h]([0-5]\d))?$/i);
    if (!m) return null;
    const h = String(+m[1]).padStart(2, "0") + ":" + (m[2] || "00");
    if (!r.includes(h)) r.push(h);
  }
  return r.sort();
}

/** Mapa hora -> publicidad que la usa (sin contar la indicada). Cada hora tiene una sola publicidad. */
function horasOcupadas(exceptoId) {
  const m = {};
  if (datos) datos.items.forEach((it) => {
    if (it.id === exceptoId) return;
    (it.horas || []).forEach((h) => { if (!m[h]) m[h] = it; });
  });
  return m;
}

/** Minutos entre una publicidad y la siguiente cuando la hora ya está ocupada. */
const PASO_MIN = 4;

/** Primera hora libre desde h, corriéndose de a 4 minutos sin salir del turno ni llegar a "tope". null si no hay. */
function horaLibreDesde(h, ocupadas, tope) {
  const t = TURNOS[turnoDe(h)];
  const fin = Math.min(t ? t.hasta : 1440, tope || 1440);
  for (let m = aMin(h); m < fin; m += PASO_MIN) {
    if (!ocupadas[aHora(m)]) return aHora(m);
  }
  return null;
}

/** Mensaje si alguna de las horas ya la usa otra publicidad; "" si están libres. Sugiere la próxima libre. */
function choques(horas, exceptoId) {
  const oc = horasOcupadas(exceptoId);
  const malas = horas.filter((h) => oc[h]);
  if (!malas.length) return "";
  const usadas = Object.assign({}, oc);
  horas.forEach((h) => { if (!oc[h]) usadas[h] = true; });
  return malas.map((h) => {
    const libre = horaLibreDesde(h, usadas);
    if (libre) usadas[libre] = true;
    return h + " ya la usa «" + oc[h].nombre + "»" + (libre ? " (probá " + libre + ")" : "");
  }).join("; ") + ". Cada hora puede tener una sola publicidad.";
}

/** Primera hora de la publicidad dentro del turno (para ordenar la lista). */
function primeraHora(it, t) {
  const hs = (it.horas || []).filter((h) => (t === "otros" ? turnoDe(h) === "otros" : turnoDe(h) === t)).map(aMin);
  return hs.length ? Math.min(...hs) : 9999;
}

function fueraDeTurno(horas, t) {
  return horas.filter((h) => turnoDe(h) !== t);
}

function api(ruta, cuerpo) {
  return new Promise((ok, mal) => {
    chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
      if (chrome.runtime.lastError) return mal(new Error("La extensión no respondió; recargá la página."));
      if (r && r.ok) ok(r); else mal(new Error(primeraMayuscula((r && r.error) || "sin respuesta del TV")));
    });
  });
}
function primeraMayuscula(s) { s = String(s); return s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : "."); }

async function accion(fn, mensajeOk) {
  try {
    await fn();
    if (mensajeOk) avisar(mensajeOk, true);
  } catch (e) {
    avisar(e.message, false);
  }
  cargar();
}

function el(tag, clase, texto) {
  const e = document.createElement(tag);
  if (clase) e.className = clase;
  if (texto !== undefined) e.textContent = texto;
  return e;
}
function boton(texto, clase, fn) { const b = el("button", clase, texto); b.type = "button"; b.addEventListener("click", fn); return b; }

// ---------- turnos (pestañas) ----------

function elegirTurno(t) {
  turno = t;
  try { localStorage.setItem("turnoPublicidad", t); } catch (e) { /* sin almacenamiento */ }
  document.querySelectorAll(".turnos [role=tab]").forEach((b) => b.setAttribute("aria-selected", b.dataset.turno === t ? "true" : "false"));
  $("hoja").setAttribute("aria-labelledby", "tab-" + t);
  $("thHoras").textContent = t === "otros" ? "Horas" : "Horas del turno";
  seleccion.clear();
  editando = null;
  if (t !== "otros") {
    const r = document.querySelector('input[name=turnoNuevo][value="' + t + '"]');
    if (r) { r.checked = true; actualizarRango(); }
  }
  dibujar();
}

document.querySelectorAll(".turnos [role=tab]").forEach((b) => b.addEventListener("click", () => elegirTurno(b.dataset.turno)));

// ---------- listado ----------

async function cargar() {
  clearTimeout(cargar._t);
  if (editando) { cargar._t = setTimeout(cargar, 3000); return; }
  try {
    datos = await api("/publicidad");
  } catch (e) {
    $("conexion").textContent = "No se pudo conectar con el TV: " + e.message + " Revisá la conexión en «Este consultorio» y que la aplicación del TV esté abierta.";
    cargar._t = setTimeout(cargar, 20000);
    return;
  }
  via = datos.via || "local";
  $("conexion").textContent = (via === "internet" ? "Conectado por internet. " : "") + "Hora del TV: " + datos.ahora + ". Espacio libre para videos: " +
    (datos.espacioLibreMB > 1024 ? (datos.espacioLibreMB / 1024).toFixed(1).replace(".", ",") + " GB." : datos.espacioLibreMB + " MB.");

  if (!document.activeElement || !document.activeElement.matches("input[type=range]")) {
    $("volLlamado").value = datos.config.volLlamado; $("vLl").textContent = datos.config.volLlamado + "%";
    $("volPublicidad").value = datos.config.volPublicidad; $("vPu").textContent = datos.config.volPublicidad + "%";
  }
  dibujar();
  cargar._t = setTimeout(cargar, datos.enCurso ? 4000 : 20000);
}

function itemsDelTurno(t) {
  if (!datos) return [];
  return datos.items.filter((it) => {
    const hs = it.horas || [];
    if (t === "otros") return !hs.length || hs.some((h) => turnoDe(h) === "otros");
    return hs.some((h) => turnoDe(h) === t);
  }).sort((a, b) => primeraHora(a, t) - primeraHora(b, t) || a.nombre.localeCompare(b.nombre));
}

function dibujar() {
  if (!datos) return;
  const porId = {};
  datos.items.forEach((it) => { porId[it.id] = it; });

  // Lo que suena ahora
  const fila = (datos.fila || []).filter((id) => porId[id]);
  if (datos.enCurso && porId[datos.enCurso]) {
    $("ahoraTexto").textContent = "En el TV: " + porId[datos.enCurso].nombre + "." +
      (fila.length ? " Después: " + fila.map((id) => porId[id].nombre).join(", ") + "." : "");
    $("ahora").classList.add("visible");
  } else {
    $("ahora").classList.remove("visible");
  }

  // Cantidades por turno
  ["manana", "tarde", "otros"].forEach((t) => { $("cuenta-" + t).textContent = itemsDelTurno(t).length; });
  const hayOtros = itemsDelTurno("otros").length > 0;
  $("tab-otros").hidden = !hayOtros;
  if (!hayOtros && turno === "otros") { elegirTurno("manana"); return; }

  const items = itemsDelTurno(turno);
  ordenActual = items.map((it) => it.id);
  [...seleccion].forEach((id) => { if (!ordenActual.includes(id)) seleccion.delete(id); });

  const tbody = $("lista");
  tbody.innerHTML = "";
  const vacio = $("vacio");
  vacio.hidden = items.length > 0;
  if (!items.length) {
    vacio.innerHTML = "";
    vacio.append(el("b", "", "No hay publicidades en el turno " + (TURNOS[turno] ? TURNOS[turno].nombre.toLowerCase() : "") + "."),
      el("div", "", "Agregá una desde «Agregar publicidad», más abajo."));
    const otro = TURNOS[turno] ? itemsDelTurno(OTRO[turno]) : [];
    if (otro.length) {
      const b = boton("Copiar las de la " + TURNOS[OTRO[turno]].nombre.toLowerCase() + " (" + otro.length + ")", "primario", () => abrirCopia(otro.map((x) => x.id), OTRO[turno]));
      b.style.marginTop = "14px";
      vacio.appendChild(b);
    }
  }

  items.forEach((it) => {
    const tr = el("tr", (!it.activo ? "apagado " : "") + (it.id === datos.enCurso ? "sonando" : ""));

    const marca = el("input", "sel"); marca.type = "checkbox"; marca.checked = seleccion.has(it.id);
    marca.setAttribute("aria-label", "Seleccionar " + it.nombre);
    marca.addEventListener("change", () => { marca.checked ? seleccion.add(it.id) : seleccion.delete(it.id); actualizarSeleccion(); });
    tr.appendChild(td(marca));

    const sw = el("label", "switch"); sw.title = it.activo ? "Activa: suena en sus horarios" : "Pausada: no suena en sus horarios";
    const chk = el("input"); chk.type = "checkbox"; chk.checked = it.activo;
    chk.setAttribute("aria-label", "Activa");
    chk.addEventListener("change", () => accion(() => api("/publicidad/modificar", { id: it.id, activo: chk.checked }),
      chk.checked ? "«" + it.nombre + "» activada." : "«" + it.nombre + "» pausada."));
    sw.append(chk, el("span"));
    tr.appendChild(td(sw));

    // Video: miniatura + nombre
    const video = el("div", "video");
    if (it.tipo === "youtube") {
      const img = el("img", "miniatura"); img.alt = ""; img.loading = "lazy"; img.src = YT.miniatura(it.videoId);
      img.addEventListener("error", () => { img.replaceWith(iconoVideo()); });
      video.appendChild(img);
    } else {
      video.appendChild(iconoVideo());
    }
    const info = el("div");
    info.append(el("div", "nombre", it.nombre),
      el("div", "chico", it.tipo === "youtube" ? "YouTube" : "Video guardado en el TV (" + String(it.tamanoMB).replace(".", ",") + " MB)"));
    video.appendChild(info);
    tr.appendChild(td(video));

    // Horas de este turno (y aviso si también tiene en el otro)
    const horas = (it.horas || []).slice().sort();
    const propias = turno === "otros" ? horas.filter((h) => turnoDe(h) === "otros") : horas.filter((h) => turnoDe(h) === turno);
    const cajaHoras = el("div");
    const hs = el("div", "horas");
    propias.forEach((h) => {
      const hecha = it.hecho && it.hecho[h] === datos.hoy;
      const s = el("span", "hora" + (hecha ? " hecha" : ""), h);
      if (hecha) s.title = "Ya se reprodujo hoy a esta hora";
      hs.appendChild(s);
    });
    cajaHoras.appendChild(hs);
    const repetidas = propias.filter((h) => horasOcupadas(it.id)[h]);
    if (repetidas.length) {
      const oc = horasOcupadas(it.id);
      const av = el("div", "otro-turno repetida", "Hora repetida: " + repetidas.map((h) => h + " (también «" + oc[h].nombre + "»)").join(", ") + ". Editá las horas para que no se superpongan.");
      cajaHoras.appendChild(av);
    }
    const otras = horas.filter((h) => !propias.includes(h));
    if (otras.length) {
      const nombres = [...new Set(otras.map(turnoDe))].map((t) => t === "otros" ? "fuera de turno" : "a la " + TURNOS[t].nombre.toLowerCase());
      cajaHoras.appendChild(el("div", "otro-turno", "También " + nombres.join(" y ") + ": " + otras.join(", ")));
    }
    const tdHoras = td(cajaHoras);
    tr.appendChild(tdHoras);

    tr.appendChild(td(estado(it, fila)));

    const acc = el("div", "acciones");
    acc.append(
      boton("Ver ahora", "", () => accion(() => api("/publicidad/reproducir", { ids: [it.id] }), mensajeReproducir([it]))),
      boton("Detener", "peligro", () => accion(() => api("/publicidad/detener", {}), "Publicidad detenida.")),
      boton("Editar horas", "", () => editarHoras(it, tdHoras)),
      ...(turno !== "otros" ? [boton("Copiar a la " + TURNOS[OTRO[turno]].nombre.toLowerCase(), "", () => abrirCopia([it.id]))] : []),
      boton("Borrar", "peligro", () => {
        if (!confirm("¿Borrar «" + it.nombre + "»?" + (it.tipo === "archivo" ? " El video se elimina del TV." : "") + " Se quita de los dos turnos.")) return;
        accion(() => api("/publicidad/borrar", { id: it.id }), "«" + it.nombre + "» se borró.");
      })
    );
    if (it.tipo === "youtube") {
      acc.append(boton("Abrir en YouTube", "", () => window.open(YT.linkNormal(it.videoId), "_blank", "noopener")),
        boton("Copiar link", "", async () => {
          try { await navigator.clipboard.writeText("https://youtu.be/" + it.videoId); avisar("Link copiado: ya lo podés pegar donde quieras.", true); }
          catch (e) { avisar("No se pudo copiar el link.", false); }
        }));
    }
    const tdAcc = td(acc); tdAcc.style.textAlign = "right";
    tr.appendChild(tdAcc);
    tbody.appendChild(tr);
  });
  actualizarSeleccion();
}

function td(contenido) { const c = el("td"); c.appendChild(contenido); return c; }

function iconoVideo() {
  const d = el("div", "miniatura");
  d.innerHTML = '<svg width="28" height="28" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="#0f4c5c" stroke-width="1.8"/><path d="M10 9.5v5l4.5-2.5z" fill="#0f4c5c"/></svg>';
  return d;
}

function estado(it, fila) {
  const c = el("div");
  if (it.id === datos.enCurso) { c.appendChild(el("span", "pill rep", "Sonando ahora")); return c; }
  if (fila.includes(it.id)) { c.appendChild(el("span", "pill fila", "En fila (" + (fila.indexOf(it.id) + 1) + "º)")); return c; }
  if (!it.ultimoEstado) { c.className = "chico"; c.textContent = "Todavía no"; return c; }
  const est = it.ultimoEstado;
  c.appendChild(el("span", "pill " + (est === "ok" ? "ok" : est === "error" ? "error" : est === "detenida" ? "det" : "rep"),
    est === "ok" ? "Reproducida" : est === "error" ? "No se pudo" : est === "detenida" ? "Detenida" : "Interrumpida"));
  c.appendChild(el("div", "chico", it.ultimaVez || ""));
  if (it.ultimoDetalle) c.appendChild(el("div", "chico", primeraMayuscula(it.ultimoDetalle)));
  return c;
}

// Edición de las horas del turno visible, en la misma fila.
function editarHoras(it, celdaHoras) {
  editando = it.id;
  const horas = (it.horas || []).slice().sort();
  const propias = horas.filter((h) => turnoDe(h) === turno);
  const resto = fueraDeTurno(horas, turno);
  celdaHoras.innerHTML = "";
  const caja = el("div", "editor-horas");
  const input = el("input"); input.type = "text"; input.value = propias.join(", ");
  input.setAttribute("aria-label", "Horas de " + it.nombre);
  const guardar = boton("Guardar", "primario", async () => {
    let nuevas = input.value.trim() ? leerHoras(input.value) : [];
    if (nuevas === null) { avisar("Revisá las horas: usá el formato 10:30, separadas por coma.", false); input.focus(); return; }
    if (turno !== "otros") {
      const malas = nuevas.filter((h) => turnoDe(h) !== turno);
      if (malas.length) { avisar("En el turno " + TURNOS[turno].nombre.toLowerCase() + " las horas van entre " + TURNOS[turno].texto + " (" + malas.join(", ") + " no corresponde).", false); input.focus(); return; }
    }
    const todas = [...new Set([...resto, ...nuevas])].sort();
    const choque = choques(nuevas, it.id);
    if (choque) { avisar(choque, false); input.focus(); return; }
    if (!todas.length) { avisar("Dejá al menos una hora. Para que no suene más, pausala o borrala.", false); input.focus(); return; }
    editando = null;
    await accion(() => api("/publicidad/modificar", { id: it.id, horas: todas.join(", ") }), "Horas de «" + it.nombre + "» actualizadas.");
  });
  const cancelar = boton("Cancelar", "", () => { editando = null; dibujar(); });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") guardar.click(); if (e.key === "Escape") cancelar.click(); });
  caja.append(input, guardar, cancelar);
  celdaHoras.appendChild(caja);
  if (turno !== "otros") celdaHoras.appendChild(el("div", "chico", "Entre " + TURNOS[turno].texto + "."));
  input.focus(); input.select();
}

function actualizarSeleccion() {
  const n = seleccion.size;
  const nombreTurno = TURNOS[turno] ? TURNOS[turno].nombre.toLowerCase() : "fuera de turno";
  const puedeCopiar = !!TURNOS[turno];
  $("copiarSel").hidden = !puedeCopiar;
  if (puedeCopiar) {
    $("copiarSel").disabled = ordenActual.length === 0;
    $("copiarSel").textContent = (n ? "Copiar seleccionadas" : "Copiar todas") + " a la " + TURNOS[OTRO[turno]].nombre.toLowerCase();
  }
  $("reproducirSel").disabled = n === 0;
  $("reproducirSel").textContent = n ? "Reproducir seleccionadas (" + n + ")" : "Reproducir seleccionadas";
  $("cuentaSel").textContent = n
    ? (n === 1 ? "1 publicidad seleccionada." : n + " publicidades seleccionadas: se reproducen una detrás de otra, en el orden de la lista.")
    : ordenActual.length ? "Marcá las publicidades de la " + nombreTurno + " que quieras ver ahora." : "";
  const todas = ordenActual.length > 0 && ordenActual.every((id) => seleccion.has(id));
  $("selTodas").checked = todas;
  $("selTodas").indeterminate = n > 0 && !todas;
  $("selTodas").disabled = !ordenActual.length;
}

$("selTodas").addEventListener("change", () => {
  if ($("selTodas").checked) ordenActual.forEach((id) => seleccion.add(id)); else seleccion.clear();
  document.querySelectorAll("#lista input.sel").forEach((c) => { c.checked = $("selTodas").checked; });
  actualizarSeleccion();
});

$("reproducirSel").addEventListener("click", () => {
  const ids = ordenActual.filter((id) => seleccion.has(id));
  if (!ids.length) return;
  const elegidas = ids.map((id) => datos.items.find((it) => it.id === id)).filter(Boolean);
  accion(() => api("/publicidad/reproducir", { ids }), mensajeReproducir(elegidas));
});

/** Lo que se dice al pedir reproducir: si ya hay una sonando, no se corta; se espera a que termine. */
function mensajeReproducir(items) {
  const actual = datos && datos.enCurso && datos.items.find((x) => x.id === datos.enCurso);
  const que = items.length === 1 ? "«" + items[0].nombre + "»" : items.length + " publicidades, una detrás de otra,";
  if (actual && !(items.length === 1 && items[0].id === actual.id)) {
    return "Se va a reproducir " + que + " cuando termine «" + actual.nombre + "».";
  }
  return items.length === 1 ? "Reproduciendo «" + items[0].nombre + "» en el TV." : "Reproduciendo " + items.length + " publicidades en el TV, una detrás de otra.";
}

$("detenerTodo").addEventListener("click", () => accion(() => api("/publicidad/detener", {}), "Publicidad detenida."));

// ---------- copiar al otro turno ----------
// La misma publicidad pasa a sonar también en el otro turno, 7 horas después (o antes): 08:00 de la mañana -> 15:00 de la tarde.
// Si esa hora ya la usa otra publicidad, se corre de a 4 minutos. El video es el mismo: no se duplica ni se vuelve a subir.

let copiaPlan = null;

function planCopia(ids, origen) {
  const destino = OTRO[origen];
  const delta = destino === "tarde" ? DESPLAZAMIENTO : -DESPLAZAMIENTO;
  const oc = Object.assign({}, horasOcupadas(null));
  const filas = [];
  ids.forEach((id) => {
    const it = datos.items.find((x) => x.id === id);
    if (!it) return;
    const tiene = new Set(it.horas || []);
    const propias = (it.horas || []).filter((h) => turnoDe(h) === origen).sort();
    const f = { it, propias, nuevas: [], ya: [], sinLugar: [], movidas: [] };
    propias.forEach((h) => {
      const d = aHora(aMin(h) + delta);
      if (turnoDe(d) !== destino) { f.sinLugar.push(h); return; }
      if (tiene.has(d)) { f.ya.push(d); return; }
      let libre = null;
      for (let m = aMin(d); m <= TURNOS[destino].hasta; m += PASO_MIN) { if (!oc[aHora(m)]) { libre = aHora(m); break; } }
      if (!libre) { f.sinLugar.push(h); return; }
      oc[libre] = it; f.nuevas.push(libre);
      if (libre !== d) f.movidas.push(d + " → " + libre);
    });
    filas.push(f);
  });
  return { origen, destino, filas, total: filas.reduce((n, f) => n + f.nuevas.length, 0) };
}

function chips(horas, clase) {
  const c = el("span", "horas");
  horas.forEach((h) => c.appendChild(el("span", "hora" + (clase ? " " + clase : ""), h)));
  return c;
}

function abrirCopia(ids, origen) {
  if (!datos) return;
  origen = origen || turno;
  if (!OTRO[origen]) return;
  const plan = planCopia(ids, origen);
  copiaPlan = plan;
  const nOrigen = TURNOS[origen].nombre.toLowerCase(), nDestino = TURNOS[plan.destino].nombre.toLowerCase();
  $("dlgTitulo").textContent = "Copiar a la " + nDestino;
  $("dlgAyuda").textContent = "Las horas de la " + nOrigen + " se pasan a la " + nDestino + ", " + (plan.destino === "tarde" ? "sumando 7 horas" : "restando 7 horas") +
    ". Si una hora ya está ocupada, se corre 4 minutos. Las horas de la " + nOrigen + " no cambian.";
  const lista = $("dlgLista");
  lista.innerHTML = "";
  plan.filas.forEach((f) => {
    const caja = el("div", "dlg-item" + (f.nuevas.length ? "" : " vacia"));
    const cab = el("div", "dlg-nombre", f.it.nombre);
    const cuerpo = el("div", "dlg-horas");
    cuerpo.append(el("span", "dlg-rotulo", "Hoy " + nOrigen), chips(f.propias), el("span", "dlg-flecha", "→"),
      el("span", "dlg-rotulo", "Nueva " + nDestino), f.nuevas.length ? chips(f.nuevas, "nueva") : el("span", "chico", "nada para agregar"));
    caja.append(cab, cuerpo);
    const notas = [];
    if (f.movidas.length) notas.push("Se corrió 4 min por estar ocupada: " + f.movidas.join(", ") + ".");
    if (f.ya.length) notas.push("Ya la tenía: " + f.ya.join(", ") + ".");
    if (f.sinLugar.length) notas.push("Sin lugar libre para: " + f.sinLugar.join(", ") + ".");
    notas.forEach((n) => caja.appendChild(el("div", "dlg-nota", n)));
    lista.appendChild(caja);
  });
  $("dlgOk").disabled = plan.total === 0;
  $("dlgOk").textContent = plan.total ? "Copiar " + plan.total + (plan.total === 1 ? " hora" : " horas") : "Nada para copiar";
  const d = $("dlgCopiar");
  if (typeof d.showModal === "function") d.showModal(); else d.setAttribute("open", "");
}

function cerrarCopia() {
  const d = $("dlgCopiar");
  if (d.close) d.close(); else d.removeAttribute("open");
  copiaPlan = null;
}

$("dlgCancelar").addEventListener("click", cerrarCopia);
$("dlgCopiar").addEventListener("cancel", () => { copiaPlan = null; });
$("copiarSel").addEventListener("click", () => {
  const ids = seleccion.size ? ordenActual.filter((id) => seleccion.has(id)) : ordenActual.slice();
  if (ids.length) abrirCopia(ids);
});
$("dlgOk").addEventListener("click", async () => {
  let plan = copiaPlan;
  if (!plan || !plan.total) return;
  $("dlgOk").disabled = true;
  // Los datos pudieron cambiar mientras estaba abierta la ventana (otra PC): se vuelve a calcular y, si difiere, se muestra de nuevo.
  const fresco = planCopia(plan.filas.map((f) => f.it.id), plan.origen);
  const firma = (p) => JSON.stringify(p.filas.map((f) => [f.it.id, f.nuevas]));
  if (firma(fresco) !== firma(plan)) {
    cerrarCopia();
    avisar("Las publicidades cambiaron mientras revisabas. Mirá cómo quedan y confirmá de nuevo.", false);
    return abrirCopia(fresco.filas.map((f) => f.it.id), plan.origen);
  }
  plan = fresco;
  let hechas = 0, fallas = [];
  for (const f of plan.filas) {
    if (!f.nuevas.length) continue;
    try {
      await api("/publicidad/modificar", { id: f.it.id, horas: [...new Set([...(f.it.horas || []), ...f.nuevas])].sort().join(", ") });
      hechas++;
    } catch (e) { fallas.push("«" + f.it.nombre + "»: " + e.message); }
  }
  cerrarCopia();
  const nDestino = TURNOS[plan.destino].nombre.toLowerCase();
  if (fallas.length) avisar("Se copiaron " + hechas + " y " + fallas.length + " fallaron: " + fallas.join(" "), false);
  else avisar(hechas === 1 ? "Listo: la publicidad ya suena también a la " + nDestino + "." : "Listo: " + hechas + " publicidades ya suenan también a la " + nDestino + ".", true);
  await cargar();
  elegirTurno(plan.destino);
});

// ---------- volumen ----------

["volLlamado", "volPublicidad"].forEach((id) => {
  const r = $(id);
  r.addEventListener("input", () => { $(id === "volLlamado" ? "vLl" : "vPu").textContent = r.value + "%"; });
  r.addEventListener("change", () => accion(() => api("/volumen", {
    llamado: +$("volLlamado").value, publicidad: +$("volPublicidad").value
  }), "Volumen guardado. Se aplica desde el próximo llamado o video."));
});

// ---------- alta ----------

function turnoNuevo() { return document.querySelector("input[name=turnoNuevo]:checked").value; }

function actualizarRango() {
  const t = TURNOS[turnoNuevo()];
  $("rangoTurno").textContent = "Entre " + t.texto + ".";
  $("horas").placeholder = turnoNuevo() === "manana" ? "08:00, 10:30" : "15:00, 17:30";
}
document.querySelectorAll("input[name=turnoNuevo]").forEach((r) => r.addEventListener("change", actualizarRango));

// Completar horas automáticamente dentro del turno
document.querySelectorAll(".generar button[data-cada]").forEach((b) => b.addEventListener("click", () => {
  // Si la hora ya tiene publicidad, esta va 4 minutos después (16:00 ocupada -> 16:04, 16:08...).
  // Si la anterior dura más, en el TV queda en fila hasta que termine: no se interrumpen.
  const t = TURNOS[turnoNuevo()], cada = +b.dataset.cada, hs = [], oc = Object.assign({}, horasOcupadas(null));
  const corridas = [], sinLugar = [];
  for (let m = t.desde; m < t.hasta; m += cada) {
    const h = aHora(m);
    const libre = horaLibreDesde(h, oc, m + cada);
    if (!libre) { sinLugar.push(h); continue; }
    oc[libre] = true;
    hs.push(libre);
    if (libre !== h) corridas.push(h + " → " + libre);
  }
  $("horas").value = hs.join(", ");
  revisarHoras();
  const partes = [];
  if (corridas.length) partes.push("Horas ocupadas, se corrieron " + PASO_MIN + " min: " + corridas.join(", ") + ".");
  if (sinLugar.length) partes.push("Sin lugar cerca de: " + sinLugar.join(", ") + ".");
  if (partes.length) avisar(partes.join(" "), true);
}));

// Mientras se escriben las horas, se avisa si alguna está ocupada o fuera del turno
function revisarHoras() {
  const caja = $("chequeoHoras");
  const txt = $("horas").value.trim();
  caja.textContent = ""; caja.className = "chequeo";
  if (!txt) return true;
  const hs = leerHoras(txt);
  if (!hs) { caja.textContent = "Escribí las horas como 08:00, 10:30."; caja.className = "chequeo error"; return false; }
  const t = turnoNuevo();
  const fuera = hs.filter((h) => turnoDe(h) !== t);
  if (fuera.length) { caja.textContent = fuera.join(", ") + " no está en el turno " + TURNOS[t].nombre.toLowerCase() + " (" + TURNOS[t].texto + ")."; caja.className = "chequeo error"; return false; }
  const ch = choques(hs, null);
  if (ch) { caja.textContent = ch; caja.className = "chequeo error"; return false; }
  caja.textContent = "✓ " + (hs.length === 1 ? "Hora libre" : "Las " + hs.length + " horas están libres") + ".";
  caja.className = "chequeo ok";
  return true;
}
$("horas").addEventListener("input", revisarHoras);
document.querySelectorAll("input[name=turnoNuevo]").forEach((r) => r.addEventListener("change", revisarHoras));

document.querySelectorAll("input[name=tipo]").forEach((r) => r.addEventListener("change", () => {
  const yt = document.querySelector("input[name=tipo]:checked").value === "youtube";
  $("campoYoutube").hidden = !yt;
  $("campoArchivo").hidden = yt;
}));

$("archivo").addEventListener("change", () => {
  const f = $("archivo").files[0];
  if (f && !$("nombre").value) $("nombre").value = f.name.replace(/\.[^.]+$/, "");
});

// Link de YouTube: se lee al pegar o escribir, con vista previa y verificación
let consultaYt = 0;
async function revisarLink() {
  const n = ++consultaYt;
  const r = YT.leerLink($("url").value);
  const vista = $("vista"), ver = $("vistaVerifica");
  videoActual = null;
  if (!r.id) {
    vista.classList.remove("visible");
    if (r.error) { vista.classList.add("visible"); $("vistaImg").removeAttribute("src"); $("vistaTitulo").textContent = ""; $("vistaCanal").textContent = "";
      ver.className = "verifica error"; ver.textContent = r.error; $("vistaAbrir").hidden = true; }
    return;
  }
  videoActual = { id: r.id, estado: "verificando" };
  vista.classList.add("visible");
  $("vistaImg").src = YT.miniatura(r.id);
  $("vistaTitulo").textContent = "Video de YouTube";
  $("vistaCanal").textContent = "";
  $("vistaAbrir").hidden = false; $("vistaAbrir").href = YT.linkNormal(r.id);
  ver.className = "verifica duda"; ver.textContent = "Verificando el video…";

  const repetido = datos && datos.items.find((it) => it.tipo === "youtube" && it.videoId === r.id);
  const info = await YT.verificar(r.id);
  if (n !== consultaYt) return; // cambió el link mientras se consultaba
  videoActual = { id: r.id, estado: info.estado, titulo: info.titulo };
  if (info.titulo) { $("vistaTitulo").textContent = info.titulo; if (!$("nombre").value.trim()) $("nombre").value = info.titulo.slice(0, 80); }
  if (info.canal) $("vistaCanal").textContent = info.canal;
  if (repetido) { ver.className = "verifica duda"; ver.textContent = "Este video ya está agregado como «" + repetido.nombre + "». Podés editarle las horas en la lista."; videoActual.repetido = repetido; return; }
  if (info.estado === "ok") { ver.className = "verifica ok"; ver.textContent = "✓ Se puede reproducir en el TV."; }
  else if (info.estado === "sin-insertar") { ver.className = "verifica error"; ver.textContent = "El dueño del video no permite reproducirlo fuera de YouTube. Elegí otro video o subí el archivo."; }
  else if (info.estado === "no-existe") { ver.className = "verifica error"; ver.textContent = "El video no existe o es privado."; }
  else { ver.className = "verifica duda"; ver.textContent = "No se pudo verificar ahora (¿sin internet?). Se puede agregar igual."; }
}
$("url").addEventListener("input", () => { clearTimeout(revisarLink._t); revisarLink._t = setTimeout(revisarLink, 250); });
$("url").addEventListener("paste", () => setTimeout(revisarLink, 0));

$("pegar").addEventListener("click", async () => {
  try {
    const t = await navigator.clipboard.readText();
    if (!t) return avisar("No hay nada copiado. En YouTube tocá «Compartir» y después «Copiar».", false);
    $("url").value = t.trim();
    revisarLink();
  } catch (e) {
    $("url").focus();
    avisar("Chrome no dejó leer lo copiado: pegalo en el campo con Ctrl+V.", false);
  }
});

function subir(f, nombre, horas) {
  return new Promise((ok, mal) => {
    const x = new XMLHttpRequest();
    x.open("POST", BASE + "/publicidad/subir");
    x.setRequestHeader("X-Nombre", encodeURIComponent(nombre));
    x.setRequestHeader("X-Archivo", encodeURIComponent(f.name));
    x.setRequestHeader("X-Horas", encodeURIComponent(horas));
    x.upload.onprogress = (e) => {
      if (e.lengthComputable) $("barra").firstElementChild.style.width = Math.round(e.loaded / e.total * 100) + "%";
    };
    x.onload = () => {
      let j = {};
      try { j = JSON.parse(x.responseText); } catch (e) { /* vacío */ }
      j.ok ? ok(j) : mal(new Error(primeraMayuscula(j.error || "el TV respondió " + x.status)));
    };
    x.onerror = () => mal(new Error("No se pudo subir: esta PC no llega al TV por la red local. Los videos solo se suben desde la misma red que el TV."));
    x.send(f);
  });
}

$("agregar").addEventListener("click", async () => {
  const tipo = document.querySelector("input[name=tipo]:checked").value;
  const t = turnoNuevo();
  const nombre = $("nombre").value.trim();
  const horas = leerHoras($("horas").value);
  if (!horas) return avisar("Poné al menos una hora, por ejemplo 08:00 (varias separadas por coma), o usá «Completar».", false);
  const malas = horas.filter((h) => turnoDe(h) !== t);
  if (malas.length) return avisar("En el turno " + TURNOS[t].nombre.toLowerCase() + " las horas van entre " + TURNOS[t].texto + ". Revisá: " + malas.join(", ") + ".", false);
  const choque = choques(horas, null);
  if (choque) return avisar(choque, false);
  const btn = $("agregar");
  btn.disabled = true;
  try {
    if (tipo === "youtube") {
      const r = YT.leerLink($("url").value);
      if (!r.id) throw new Error(r.error || "Pegá el link del video de YouTube.");
      if (videoActual && videoActual.id === r.id && videoActual.estado === "verificando") await revisarLink();
      const v = videoActual && videoActual.id === r.id ? videoActual : null;
      if (v && v.repetido) throw new Error("Ese video ya está agregado como «" + v.repetido.nombre + "». Editale las horas en la lista.");
      if (v && (v.estado === "sin-insertar" || v.estado === "no-existe")) throw new Error("Ese video no se puede reproducir en el TV. Elegí otro o subí el archivo.");
      await api("/publicidad/youtube", { nombre: nombre || (v && v.titulo) || "Video de YouTube", url: YT.linkNormal(r.id), horas: horas.join(", ") });
      $("url").value = ""; $("vista").classList.remove("visible"); videoActual = null;
    } else {
      const f = $("archivo").files[0];
      if (!f) throw new Error("Elegí el video a subir.");
      if (f.size > 1.5 * 1024 * 1024 * 1024) throw new Error("El video supera 1,5 GB.");
      if (!BASE || via === "internet") throw new Error("Para subir un video, esta PC tiene que estar en la misma red que el TV. Desde otra red podés agregar links de YouTube.");
      $("barra").style.display = "block";
      avisar("Subiendo " + f.name + "… no cierres esta pestaña.", true);
      await subir(f, nombre || f.name, horas.join(", "));
      $("archivo").value = "";
    }
    $("nombre").value = ""; $("horas").value = ""; revisarHoras();
    avisar("Agregada al turno " + TURNOS[t].nombre.toLowerCase() + ": se reproduce todos los días a las " + horas.join(", ") + ".", true);
    if (turno !== t) elegirTurno(t);
  } catch (e) {
    avisar(e.message, false);
  } finally {
    btn.disabled = false;
    $("barra").style.display = "none";
    $("barra").firstElementChild.style.width = "0";
    cargar();
  }
});

// ---------- inicio ----------

elegirTurno(turno);
actualizarRango();
Almacen.get({ ipTv: "", puerto: 8765, codigo: "" }).then(async (c) => {
  if (!c.ipTv && !c.codigo) {
    $("conexion").textContent = "Primero configurá la conexión con el TV en la pestaña «Este consultorio».";
    return;
  }
  if (c.ipTv) {
    const permiso = await chrome.permissions.contains({ origins: ["http://" + c.ipTv + "/*"] });
    if (permiso) BASE = "http://" + c.ipTv + ":" + (c.puerto || 8765);
    else if (!c.codigo) {
      $("conexion").textContent = "Falta el permiso para comunicarse con el TV: tocá «Probar conexión» en la pestaña «Este consultorio».";
      return;
    }
  }
  cargar();
});
