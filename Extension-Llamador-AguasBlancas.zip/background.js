// Llamador de pacientes: envía llamados y comandos al TV.
// Primero intenta por la red local; si el TV no responde y hay código de vinculación, va por internet (cifrado).
importScripts("lib/mqtt.min.js", "remoto.js", "almacen.js");

const PREDETERMINADO = {
  consultorio: "",
  ipTv: "",
  puerto: 8765,
  codigo: "",           // código de vinculación del TV (conexión por internet)
  servidor: "",         // servidor MQTT propio (opcional; vacío = públicos)
  usuarioServidor: "",
  claveServidor: "",
  soloConsultorio: true,
  voz: "auto",
  tono: "normal",
  velocidad: "normal"
};

const R = self.LlamadorRemoto;
let localFalloHasta = 0;   // si la red local falló hace poco, se va directo por internet
let localOkHasta = 0;      // si la red local respondió hace poco, se le da más margen antes de usar internet
let ultimaRevisionLocal = 0;
const localEnCurso = new Set();   // inicio de cada pedido local que todavía no respondió

async function config() {
  return Object.assign({}, PREDETERMINADO, await Almacen.get(PREDETERMINADO));
}

// ---------- Red local ----------

async function enviarLocal(c, ruta, cuerpo, espera) {
  if (!c.ipTv) throw new Error("falta la dirección del TV");
  const ip = String(c.ipTv).trim();
  if (!/^[\w.-]+$/.test(ip)) throw new Error("la dirección del TV no es válida");
  if (!/^\/[\w\/-]*$/.test(ruta)) throw new Error("acción no válida");
  const marca = { desde: Date.now() };
  localEnCurso.add(marca);
  const base = "http://" + ip + ":" + (parseInt(c.puerto, 10) || 8765);
  const control = new AbortController();
  const reloj = setTimeout(() => control.abort(), espera);
  try {
    const r = await fetch(base + ruta, {
      method: cuerpo ? "POST" : "GET",
      headers: cuerpo ? { "Content-Type": "application/json" } : undefined,
      body: cuerpo ? JSON.stringify(cuerpo) : undefined,
      signal: control.signal
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j.ok === false) {
      const e = new Error(j.error || "el TV respondió " + r.status);
      e.respondio = true; // el TV contestó: no tiene sentido reintentar por internet
      throw e;
    }
    return j;
  } catch (e) {
    if (e.respondio) throw e;
    if (e.name === "AbortError") throw new Error("el TV no responde en la red local");
    throw new Error("no se encontró el TV en " + base);
  } finally {
    clearTimeout(reloj);
    localEnCurso.delete(marca);
  }
}

/** ¿Hay un pedido por la red local que lleva demasiado sin respuesta? (el TV no está en esta red) */
function localTrabado(ms) {
  const limite = Date.now() - ms;
  for (const m of localEnCurso) if (m.desde < limite) return true;
  return false;
}

// ---------- Internet ----------

let conexion = null;       // { clave, cliente, k, pendientes, cierre }
let conectando = null;     // { clave, promesa }: intento en curso (evita abrir dos conexiones a la vez)

function cerrarConexion() {
  conectando = null;
  if (!conexion) return;
  try { conexion.cliente.end(true); } catch (e) { /* nada */ }
  conexion = null;
}

function conectarServidor(url, c, k) {
  return new Promise((ok, mal) => {
    const cliente = mqtt.connect(url, {
      clientId: "pc-" + R.nuevoId(),
      username: c.usuarioServidor || undefined,
      password: c.claveServidor || undefined,
      reconnectPeriod: 0, connectTimeout: 6000, keepalive: 30, clean: true
    });
    const fallar = () => { try { cliente.end(true); } catch (e) { /* nada */ } mal(new Error("sin conexión con " + url)); };
    cliente.on("error", () => {});   // un error posterior no debe tumbar el servicio
    cliente.once("connect", () => {
      cliente.subscribe(k.temaPc, { qos: 1 }, (err) => (err ? fallar() : ok(cliente)));
    });
    cliente.once("error", fallar);
    setTimeout(() => { if (!cliente.connected) fallar(); }, 7000);
  });
}

async function obtenerConexion(c) {
  const clave = R.normalizar(c.codigo) + "|" + c.servidor + "|" + c.usuarioServidor;
  if (conexion && conexion.clave === clave && conexion.cliente.connected) return conexion;
  if (conectando && conectando.clave === clave) return conectando.promesa;
  cerrarConexion();
  const intento = { clave };
  intento.promesa = abrirConexion(c, clave, intento).finally(() => { if (conectando === intento) conectando = null; });
  conectando = intento;
  return intento.promesa;
}

async function abrirConexion(c, clave, intento) {
  const k = await R.derivar(c.codigo);
  const servidores = c.servidor ? [c.servidor] : R.SERVIDORES;
  for (const url of servidores) {
    try {
      const cliente = await conectarServidor(url, c, k);
      if (conectando !== intento) {   // mientras tanto cambió la configuración: esta conexión ya no sirve
        try { cliente.end(true); } catch (e) { /* nada */ }
        throw new Error("la configuración cambió");
      }
      const nueva = { clave, cliente, k, pendientes: new Map(), cierre: null };
      cliente.on("message", async (tema, carga) => {
        if (tema !== k.temaPc) return;
        try {
          const m = await R.descifrar(k.clave, carga.toString());
          const p = m && m.tipo === "respuesta" && nueva.pendientes.get(m.id);
          if (p) { nueva.pendientes.delete(m.id); p(m); }
        } catch (e) { /* mensaje ajeno: se ignora */ }
      });
      cliente.on("close", () => { if (conexion === nueva) conexion = null; });
      conexion = nueva;
      return nueva;
    } catch (e) {
      if (conectando !== intento) break;   // la configuración cambió: no tiene sentido seguir
      /* se prueba el siguiente servidor */
    }
  }
  throw new Error("no hay conexión con el servicio de internet (¿esta PC tiene internet?)");
}

// La conexión por internet queda abierta mientras se use (el panel la mantiene viva); si no, se cierra sola.
function mantenerAbierta(con) {
  clearTimeout(con.cierre);
  con.cierre = setTimeout(cerrarConexion, 90000);
}

async function enviarInternet(c, ruta, cuerpo) {
  if (!R.valido(c.codigo)) throw new Error("el código de vinculación no es válido");
  if (!R.RUTAS_PERMITIDAS.includes(ruta)) throw new Error("esta acción solo se puede hacer desde la red local del TV");
  const con = await obtenerConexion(c);
  const id = R.nuevoId();
  const respuesta = new Promise((ok, mal) => {
    con.pendientes.set(id, ok);
    setTimeout(() => {
      if (con.pendientes.delete(id)) mal(new Error("el TV no contestó por internet (¿está prendido, con la aplicación abierta y con internet?)"));
    }, ruta === "/llamar" ? 6000 : ruta === "/foto/subir" ? 30000 : 10000);
  });
  const texto = await R.cifrar(con.k.clave, { tipo: "solicitud", id, ts: Date.now(), metodo: cuerpo ? "POST" : "GET", ruta, cuerpo: cuerpo || null });
  con.cliente.publish(con.k.temaTv, texto, { qos: 1 });
  mantenerAbierta(con);
  const m = await respuesta;
  const body = m.body || {};
  if (m.status >= 400 || body.ok === false) throw new Error(body.error || "el TV respondió " + m.status);
  return body;
}

// ---------- Envío con elección automática del camino ----------

function marcarLocal(ok) {
  if (ok) { localOkHasta = Date.now() + 60000; localFalloHasta = 0; }
  else { localFalloHasta = Date.now() + 60000; localOkHasta = 0; }
}

/**
 * Envío rápido para los llamados: si hay red local y código, sale por la red local y, si en poco tiempo
 * no hubo respuesta, también por internet. Gana el primero que contesta. El TV descarta el repetido
 * (mismo idLlamado), así que el paciente se anuncia una sola vez.
 */
async function enviarRapido(ruta, cuerpo) {
  const c = await config();
  if (!(c.ipTv && c.codigo)) return enviar(ruta, cuerpo);
  cuerpo = Object.assign({ idLlamado: R.nuevoId() }, cuerpo);
  const ahora = Date.now();
  const margen = ahora < localFalloHasta || localTrabado(300) ? 0 : ahora < localOkHasta ? 800 : 300;

  return new Promise((resolver, rechazar) => {
    let terminado = false, pendientes = 2, errores = [], temporizador = null;
    const ganar = (r) => { if (!terminado) { terminado = true; clearTimeout(temporizador); resolver(r); } };
    const perder = (e) => {
      errores.push(e);
      if (--pendientes === 0 && !terminado) {
        terminado = true;
        // Si el TV contestó con un error por la red local, ese es el mensaje que importa.
        const local = errores.find((x) => x.respondio);
        rechazar(local || errores[errores.length - 1]);
      }
    };
    let internetIniciado = false;
    const porInternet = () => {
      if (internetIniciado || terminado) return;
      internetIniciado = true;
      enviarInternet(c, ruta, cuerpo).then((r) => ganar(Object.assign({ via: "internet" }, r)), perder);
    };

    if (margen === 0) {
      // La red local viene fallando: directo por internet y, en paralelo, se vuelve a probar la local.
      porInternet();
      enviarLocal(c, ruta, cuerpo, 2500).then((r) => { marcarLocal(true); ganar(Object.assign({ via: "local" }, r)); },
        (e) => { if (!e.respondio) marcarLocal(false); perder(e); });
      return;
    }
    enviarLocal(c, ruta, cuerpo, 4000).then((r) => { marcarLocal(true); ganar(Object.assign({ via: "local" }, r)); },
      (e) => {
        if (!e.respondio) marcarLocal(false);
        if (e.respondio) { pendientes = 1; terminado = true; clearTimeout(temporizador); rechazar(e); return; }
        perder(e);
        porInternet();
      });
    temporizador = setTimeout(porInternet, margen);
  });
}

/** Deja todo listo para llamar al instante: verifica la red local y abre la conexión por internet. */
async function precalentar() {
  const c = await config();
  const tareas = [];
  if (c.ipTv && Date.now() - ultimaRevisionLocal > 20000) {
    ultimaRevisionLocal = Date.now();
    tareas.push(enviarLocal(c, "/estado", null, 1500).then(() => marcarLocal(true), (e) => marcarLocal(!!e.respondio)));
  }
  if (c.codigo && R.valido(c.codigo)) {
    tareas.push(obtenerConexion(c).then(mantenerAbierta, () => {}));
  }
  await Promise.all(tareas);
  return {};
}

async function enviar(ruta, cuerpo) {
  const c = await config();
  if (!c.ipTv && !c.codigo) throw new Error("falta configurar la conexión con el TV (dirección o código)");
  let errorLocal = null;
  const soloLocal = !R.RUTAS_PERMITIDAS.includes(ruta);
  if (c.ipTv && (Date.now() > localFalloHasta || !c.codigo || soloLocal)) {
    try {
      const r = await enviarLocal(c, ruta, cuerpo, ruta === "/foto/subir" ? 8000 : c.codigo && !soloLocal ? 2500 : 5000);
      marcarLocal(true);
      return Object.assign({ via: "local" }, r);
    } catch (e) {
      if (!e.respondio) marcarLocal(false);
      if (e.respondio || !c.codigo) throw e;
      errorLocal = e;
    }
  }
  if (soloLocal && errorLocal) throw new Error(errorLocal.message + ". Esta acción solo se puede hacer desde la red local del TV");
  if (c.codigo) {
    try {
      return Object.assign({ via: "internet" }, await enviarInternet(c, ruta, cuerpo));
    } catch (e) {
      throw new Error(e.message);
    }
  }
  throw errorLocal;
}

async function llamar(datos) {
  const c = await config();
  if (c.soloConsultorio && datos.ambito && datos.ambito.toUpperCase() !== "CONSULTORIO") {
    return { ok: true, omitido: true };
  }
  return enviarRapido("/llamar", {
    paciente: datos.paciente,
    consultorio: c.consultorio || "",
    voz: c.voz,
    tono: c.tono,
    velocidad: c.velocidad,
    turnoId: datos.turnoId || ""
  });
}

/**
 * El médico apuntó al parlante: se avisa al TV para que prepare la voz de ese paciente.
 * Es una ayuda para que el llamado suene antes: si falla, no pasa nada (no se muestra error).
 */
async function preparar(datos) {
  const c = await config();
  if (c.soloConsultorio && datos.ambito && datos.ambito.toUpperCase() !== "CONSULTORIO") return {};
  return enviarPreparacion(c, { paciente: datos.paciente, consultorio: c.consultorio || "", voz: c.voz, velocidad: c.velocidad });
}

/** Nombres de la grilla del panel: el TV los deja listos en segundo plano. */
async function prepararLista(lista) {
  const c = await config();
  const pacientes = (Array.isArray(lista) ? lista : [])
    .filter((d) => d && d.paciente && !(c.soloConsultorio && d.ambito && d.ambito.toUpperCase() !== "CONSULTORIO"))
    .map((d) => d.paciente).slice(0, 25);
  if (!pacientes.length) return {};
  return enviarPreparacion(c, { pacientes, consultorio: c.consultorio || "", voz: c.voz, velocidad: c.velocidad });
}

async function enviarPreparacion(c, cuerpo) {
  if (c.ipTv && Date.now() > localFalloHasta) {
    try { await enviarLocal(c, "/preparar", cuerpo, 1500); return {}; } catch (e) { if (!c.codigo) return {}; }
  }
  if (c.codigo && R.valido(c.codigo)) {
    try { await enviarInternet(c, "/preparar", cuerpo); } catch (e) { /* no importa */ }
  }
  return {};
}

chrome.runtime.onMessage.addListener((msg, _sender, responder) => {
  let tarea = null;
  if (!msg) return false;
  if (msg.tipo === "llamar") tarea = llamar(msg.datos);
  else if (msg.tipo === "estado") tarea = enviar("/estado");
  else if (msg.tipo === "voces") tarea = enviar("/voces");
  else if (msg.tipo === "prueba") tarea = enviarRapido("/llamar", msg.datos);
  else if (msg.tipo === "precalentar") tarea = precalentar();
  else if (msg.tipo === "preparar") tarea = preparar(msg.datos || {});
  else if (msg.tipo === "prepararLista") tarea = prepararLista(msg.datos);
  else if (msg.tipo === "api") tarea = enviar(msg.ruta, msg.cuerpo);
  else if (msg.tipo === "vinculoLocal") tarea = config().then((c) => enviarLocal(c, "/vinculo", null, 4000));
  else if (msg.tipo === "reiniciarConexion") {
    localFalloHasta = 0; localOkHasta = 0; ultimaRevisionLocal = 0; cerrarConexion(); tarea = Promise.resolve({});
  }
  if (!tarea) return false;
  tarea
    .then((r) => responder(Object.assign({ ok: true }, r)))
    .catch((e) => responder({ ok: false, error: e.message }));
  return true; // respuesta asíncrona
});

// Si cambia la configuración de la conexión, se olvida lo que se sabía de la anterior.
chrome.storage.onChanged.addListener((cambios, area) => {
  if (area !== "local") return;
  if (["ipTv", "puerto", "codigo", "servidor", "usuarioServidor", "claveServidor"].some((k) => k in cambios)) {
    localFalloHasta = 0; localOkHasta = 0; ultimaRevisionLocal = 0;
    cerrarConexion();
  }
});

chrome.runtime.onInstalled.addListener((info) => {
  if (info.reason === "install") chrome.runtime.openOptionsPage();
});
