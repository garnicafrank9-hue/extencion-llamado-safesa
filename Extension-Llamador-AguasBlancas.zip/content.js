// Llamador a TV - script que corre dentro del Registro de Enfermería y de la Estación de Odontología.
// Detecta el clic en el botón "Llamar Paciente" (parlante, id vLLAMADAS_XXXX)
// y lee los datos de esa misma fila de la grilla (los campos comparten el sufijo XXXX).
(function () {
  "use strict";
  if (window.__llamadorTvInstalado) return;
  window.__llamadorTvInstalado = true;

  const ultimoEnvio = {}; // turno -> timestamp, para evitar dobles clics

  function texto(prefijo, sufijo) {
    const el = document.getElementById("span_SDT_EPISODIOS__" + prefijo + "_" + sufijo);
    return el ? el.textContent.replace(/\s+/g, " ").trim() : "";
  }

  // Odontología guarda el ámbito como código; el Registro de Enfermería, como texto.
  const AMBITOS = { "1": "CONSULTORIO", "2": "HOSPITALIZACION", "3": "EMERGENCIAS", "99": "PASIVOS" };

  function leerFila(sufijo) {
    const profesional = texto("MEDICOID", sufijo).replace(/^\d+\s*-\s*/, ""); // "5311 - APERTTI..." -> "APERTTI..."
    return {
      paciente: texto("PERSONA", sufijo),
      turnoId: texto("TURNOID", sufijo),
      hora: texto("HORA", sufijo),
      servicio: texto("SERVICIOID", sufijo),
      profesional: profesional,
      ambito: AMBITOS[texto("AMBITOID", sufijo)] || texto("AMBITOID", sufijo)
    };
  }

  // Aviso discreto abajo a la derecha del panel, con el estilo del llamador.
  function aviso(titulo, detalle, ok, esperando) {
    let caja = document.getElementById("llamador-tv-aviso");
    if (!caja) {
      caja = document.createElement("div");
      caja.id = "llamador-tv-aviso";
      caja.setAttribute("role", "status");
      caja.style.cssText =
        "position:fixed;right:20px;bottom:20px;z-index:2147483647;display:flex;gap:12px;align-items:flex-start;" +
        "padding:12px 16px 12px 14px;max-width:380px;background:#fff;color:#13323b;border-radius:10px;" +
        "font:14px/1.35 'Segoe UI',Arial,sans-serif;box-shadow:0 8px 24px rgba(15,76,92,.22);" +
        "border-left:6px solid #1e9e74;transition:opacity .3s,transform .3s;opacity:0;transform:translateY(8px)";
      const icono = document.createElement("div");
      icono.style.cssText = "flex:none;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;" +
        "justify-content:center;color:#fff;font:700 16px/1 Arial,sans-serif;margin-top:1px";
      const texto = document.createElement("div");
      const t = document.createElement("div"); t.style.cssText = "font-weight:700;color:#0f4c5c";
      const d = document.createElement("div"); d.style.cssText = "color:#4d6a70;margin-top:2px";
      texto.append(t, d);
      caja.append(icono, texto);
      document.body.appendChild(caja);
    }
    const [icono, texto] = caja.children;
    const color = ok ? "#1e9e74" : "#b3261e";
    caja.style.borderLeftColor = color;
    icono.style.background = color;
    icono.textContent = esperando ? "\u2026" : ok ? "\u2713" : "!";
    texto.children[0].textContent = titulo;
    texto.children[1].textContent = detalle || "";
    texto.children[1].style.display = detalle ? "block" : "none";
    requestAnimationFrame(() => { caja.style.opacity = "1"; caja.style.transform = "none"; });
    clearTimeout(caja._t);
    caja._t = setTimeout(() => { caja.style.opacity = "0"; caja.style.transform = "translateY(8px)"; }, esperando ? 15000 : ok ? 3500 : 8000);
  }

  function alLlamar(boton) {
    const sufijo = boton.id.slice("vLLAMADAS_".length);
    const datos = leerFila(sufijo);
    if (!datos.paciente) return;

    const clave = datos.turnoId || datos.paciente;
    const ahora = Date.now();
    if (ultimoEnvio[clave] && ahora - ultimoEnvio[clave] < 3000) return;
    ultimoEnvio[clave] = ahora;

    // Si tarda (por ejemplo, la primera vez por internet), se avisa que está en curso.
    const enCurso = setTimeout(() => aviso("Llamando…", datos.paciente, true, true), 700);
    const recargar = () => aviso("Recargá el panel", "La extensión del llamador se actualizó. Apretá F5 para seguir llamando.", false);
    try {
      chrome.runtime.sendMessage({ tipo: "llamar", datos: datos }, (resp) => {
        clearTimeout(enCurso);
        if (chrome.runtime.lastError) { ultimoEnvio[clave] = 0; return recargar(); }
        if (!resp || resp.omitido) return;
        if (resp.ok) aviso("Llamado enviado al TV", datos.paciente, true);
        else {
          ultimoEnvio[clave] = 0;   // falló: que se pueda reintentar enseguida
          aviso("No se pudo llamar en el TV", (resp.error || "error desconocido").replace(/^./, (c) => c.toUpperCase()) + ".", false);
        }
      });
    } catch (e) {
      clearTimeout(enCurso);
      ultimoEnvio[clave] = 0;
      recargar();
    }
  }

  function botonLlamar(evento) {
    const t = evento.target;
    if (!t || !t.closest) return null;
    return t.closest('[id^="vLLAMADAS_"]');
  }

  // Escucha en fase de captura sobre el documento: sigue funcionando
  // aunque GeneXus redibuje la grilla (paginado, refresco automático, etc.).
  document.addEventListener("click", (e) => {
    const b = botonLlamar(e);
    if (b) alLlamar(b);
  }, true);

  // Cuando el médico apunta al parlante, el TV ya empieza a preparar la voz de ese paciente:
  // si después lo llama, el nombre suena enseguida. (El TV no muestra nada ni guarda el nombre.)
  const preparados = {}; // turno -> timestamp
  let apuntado = null, temporizador = null;
  function preparar(boton) {
    const datos = leerFila(boton.id.slice("vLLAMADAS_".length));
    if (!datos.paciente) return;
    const clave = datos.turnoId || datos.paciente;
    if (preparados[clave] && Date.now() - preparados[clave] < 90000) return;
    preparados[clave] = Date.now();
    try { chrome.runtime.sendMessage({ tipo: "preparar", datos: datos }, () => void chrome.runtime.lastError); } catch (e) { /* extensión recargada */ }
  }
  document.addEventListener("mouseover", (e) => {
    const b = botonLlamar(e);
    if (b === apuntado) return;
    apuntado = b;
    clearTimeout(temporizador);
    if (b) temporizador = setTimeout(() => { if (apuntado === b) preparar(b); }, 200);
  }, true);
  document.addEventListener("focusin", (e) => { const b = botonLlamar(e); if (b) preparar(b); }, true);

  // Además, el TV prepara de antemano los nombres de todos los pacientes que se ven en la grilla:
  // cuando el médico llama a uno, su nombre ya está listo y suena apenas termina el timbre.
  const enLista = {}; // nombre -> timestamp del último envío
  let revisionPendiente = null;
  function prepararGrilla() {
    revisionPendiente = null;
    if (document.visibilityState !== "visible") return;
    const ahora = Date.now(), nuevos = [];
    document.querySelectorAll('[id^="vLLAMADAS_"]').forEach((b) => {
      const d = leerFila(b.id.slice("vLLAMADAS_".length));
      if (!d.paciente || (enLista[d.paciente] && ahora - enLista[d.paciente] < 20 * 60000)) return;
      nuevos.push({ paciente: d.paciente, ambito: d.ambito });
    });
    if (!nuevos.length) return;
    const lote = nuevos.slice(0, 25);
    lote.forEach((d) => { enLista[d.paciente] = ahora; });
    try { chrome.runtime.sendMessage({ tipo: "prepararLista", datos: lote }, () => void chrome.runtime.lastError); } catch (e) { /* extensión recargada */ }
    if (nuevos.length > lote.length) revisionPendiente = setTimeout(prepararGrilla, 3000);
  }
  function revisarGrilla() {
    if (!revisionPendiente) revisionPendiente = setTimeout(prepararGrilla, 1500);
  }
  new MutationObserver(revisarGrilla).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener("visibilitychange", revisarGrilla);
  revisarGrilla();

  // Mientras el panel está abierto y a la vista, la extensión mantiene lista la conexión con el TV,
  // así el llamado sale al instante (sin esperar a conectarse cuando el médico toca el parlante).
  function precalentar() {
    if (document.visibilityState !== "visible") return;
    try { chrome.runtime.sendMessage({ tipo: "precalentar" }, () => void chrome.runtime.lastError); } catch (e) { /* extensión recargada */ }
  }
  if (window === window.top) {
    precalentar();
    setInterval(precalentar, 25000);
    document.addEventListener("visibilitychange", precalentar);
  }

  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" && e.key !== " ") return;
    const b = botonLlamar(e);
    if (b) alLlamar(b);
  }, true);
})();
