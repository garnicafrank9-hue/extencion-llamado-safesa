// Llamador a TV - script que corre dentro del Registro de Enfermería y de la Estación de Odontología.
// Detecta el clic en el botón "Llamar Paciente" (parlante, id vLLAMADAS_XXXX)
// y lee los datos de esa misma fila de la grilla (los campos comparten el sufijo XXXX).
(function () {
  "use strict";
  if (window.__llamadorTvInstalado) return;
  window.__llamadorTvInstalado = true;

  const ultimoEnvio = Object.create(null); // turno -> timestamp, para evitar dobles clics
  const llamadosEnCurso = new Map();

  function texto(prefijo, sufijo) {
    const el = document.getElementById("span_SDT_EPISODIOS__" + prefijo + "_" + sufijo);
    return el ? el.textContent.replace(/\s+/g, " ").trim() : "";
  }

  // Odontología guarda el ámbito como código; el Registro de Enfermería, como texto.
  const AMBITOS = { "1": "CONSULTORIO", "2": "HOSPITALIZACION", "3": "EMERGENCIAS", "99": "PASIVOS" };

  function leerFila(sufijo) {
    const profesional = texto("MEDICOID", sufijo).replace(/^\d+\s*-\s*/, ""); // "5311 - APERTTI..." -> "APERTTI..."
    return {
      paciente: texto("PERSONA", sufijo),
      turnoId: texto("TURNOID", sufijo),
      hora: texto("HORA", sufijo),
      servicio: texto("SERVICIOID", sufijo),
      profesional: profesional,
      ambito: AMBITOS[texto("AMBITOID", sufijo)] || texto("AMBITOID", sufijo)
    };
  }

  // Aviso discreto abajo a la derecha del panel, con el estilo del llamador.
  function aviso(titulo, detalle, ok, esperando) {
    let caja = document.getElementById("llamador-tv-aviso");
    if (!caja) {
      caja = document.createElement("div");
      caja.id = "llamador-tv-aviso";
      caja.setAttribute("role", "status");
      caja.style.cssText =
        "position:fixed;right:20px;bottom:20px;z-index:2147483647;display:flex;gap:12px;align-items:flex-start;" +
        "padding:12px 16px 12px 14px;max-width:380px;background:#fff;color:#13323b;border-radius:10px;" +
        "font:14px/1.35 'Segoe UI',Arial,sans-serif;box-shadow:0 8px 24px rgba(15,76,92,.22);" +
        "border-left:6px solid #1e9e74;transition:opacity .3s,transform .3s;opacity:0;transform:translateY(8px)";
      const icono = document.createElement("div");
      icono.style.cssText = "flex:none;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;" +
        "justify-content:center;color:#fff;font:700 16px/1 Arial,sans-serif;margin-top:1px";
      const texto = document.createElement("div");
      const t = document.createElement("div"); t.style.cssText = "font-weight:700;color:#0f4c5c";
      const d = document.createElement("div"); d.style.cssText = "color:#4d6a70;margin-top:2px";
      texto.append(t, d);
      caja.append(icono, texto);
      document.body.appendChild(caja);
    }
    const [icono, texto] = caja.children;
    const color = ok ? "#1e9e74" : "#b3261e";
    caja.style.borderLeftColor = color;
    icono.style.background = color;
    icono.textContent = esperando ? "\u2026" : ok ? "\u2713" : "!";
    texto.children[0].textContent = titulo;
    texto.children[1].textContent = detalle || "";
    texto.children[1].style.display = detalle ? "block" : "none";
    requestAnimationFrame(() => { caja.style.opacity = "1"; caja.style.transform = "none"; });
    clearTimeout(caja._t);
    caja._t = setTimeout(() => { caja.style.opacity = "0"; caja.style.transform = "translateY(8px)"; }, esperando ? 15000 : ok ? 3500 : 8000);
  }

  function alLlamar(boton) {
    const sufijo = boton.id.slice("vLLAMADAS_".length);
    const datos = leerFila(sufijo);
    if (!datos.paciente) return;

    const clave = (datos.turnoId || "") + "\u0000" + datos.paciente;
    const ahora = Date.now();
    if (llamadosEnCurso.has(clave)) return;
    if (ultimoEnvio[clave] && ahora - ultimoEnvio[clave] < 3000) return;
    ultimoEnvio[clave] = ahora;
    const solicitud = {};
    llamadosEnCurso.set(clave, solicitud);

    // Si tarda (por ejemplo, la primera vez por internet), se avisa que está en curso.
    const enCurso = setTimeout(() => aviso("Llamando…", datos.paciente, true, true), 700);
    const limite = setTimeout(() => {
      if (llamadosEnCurso.get(clave) !== solicitud) return;
      llamadosEnCurso.delete(clave);
      ultimoEnvio[clave] = 0;
      aviso("Sin confirmación del TV", "Revisá si el llamado llegó antes de volver a llamar.", false);
    }, 35000);
    const terminar = () => {
      if (llamadosEnCurso.get(clave) !== solicitud) return false;
      llamadosEnCurso.delete(clave);
      clearTimeout(enCurso); clearTimeout(limite);
      return true;
    };
    const recargar = () => aviso("Recargá el panel", "La extensión del llamador se actualizó. Apretá F5 para seguir llamando.", false);
    try {
      chrome.runtime.sendMessage({ tipo: "llamar", datos: datos }, (resp) => {
        const error = chrome.runtime.lastError;
        if (!terminar()) return;
        if (error) { ultimoEnvio[clave] = 0; return recargar(); }
        if (!resp) {
          ultimoEnvio[clave] = 0;
          return aviso("Sin confirmación del TV", "Revisá si el llamado llegó antes de volver a llamar.", false);
        }
        if (resp.omitido) return;
        if (resp.ok) aviso("Llamado enviado al TV", datos.paciente, true);
        else {
          ultimoEnvio[clave] = 0;   // falló: que se pueda reintentar enseguida
          aviso("No se pudo llamar en el TV", (resp.error || "error desconocido").replace(/^./, (c) => c.toUpperCase()) + ".", false);
        }
      });
    } catch (e) {
      terminar();
      ultimoEnvio[clave] = 0;
      recargar();
    }
  }

  function botonLlamar(evento) {
    const t = evento.target;
    if (!t || !t.closest) return null;
    return t.closest('[id^="vLLAMADAS_"]');
  }

  // Escucha en fase de captura sobre el documento: sigue funcionando
  // aunque GeneXus redibuje la grilla (paginado, refresco automático, etc.).
  document.addEventListener("click", (e) => {
    const b = botonLlamar(e);
    if (b) alLlamar(b);
  }, true);

  // «Recibido» significa que el TV aceptó la solicitud, no que terminó de
  // generar el audio. El APK actual no informa preparación completada por nombre.
  const recibidos = new Map();
  const preparando = new Map();
  const enLista = new Map();
  let apuntado = null, temporizador = null;
  let revisionPendiente = null, loteEnCurso = null;
  let esperaReintento = 3000, reintentarDesde = 0;

  // Siempre termina, incluso si se reinicia el service worker. Una respuesta
  // tardía no puede completar otra solicitud ni modificar una configuración nueva.
  function pedirPreparacion(mensaje, terminar) {
    let finalizado = false;
    const fin = (ok) => {
      if (finalizado) return;
      finalizado = true;
      clearTimeout(reloj);
      terminar(ok);
    };
    const reloj = setTimeout(() => fin(false), 35000);
    try {
      chrome.runtime.sendMessage(mensaje, (resp) => {
        const error = chrome.runtime.lastError;
        fin(!error && !!resp && resp.ok === true);
      });
    } catch (e) { fin(false); }
    return () => { finalizado = true; clearTimeout(reloj); };
  }

  function clavePreparacion(datos) { return datos.paciente + "\0" + datos.ambito; }

  function preparar(boton) {
    const datos = leerFila(boton.id.slice("vLLAMADAS_".length));
    if (!datos.paciente) return;
    const clave = clavePreparacion(datos);
    if (Date.now() - (recibidos.get(clave) || 0) < 90000 || preparando.has(clave)) return;
    const solicitud = {};
    preparando.set(clave, solicitud);
    solicitud.cancelar = pedirPreparacion({ tipo: "preparar", datos }, (ok) => {
      if (preparando.get(clave) !== solicitud) return;
      preparando.delete(clave);
      if (ok) recibidos.set(clave, Date.now());
      else programarRevision(3000);
    });
  }
  document.addEventListener("mouseover", (e) => {
    const b = botonLlamar(e);
    if (b === apuntado) return;
    apuntado = b;
    clearTimeout(temporizador);
    if (b) temporizador = setTimeout(() => { if (apuntado === b) preparar(b); }, 200);
  }, true);
  document.addEventListener("focusin", (e) => { const b = botonLlamar(e); if (b) preparar(b); }, true);

  function programarRevision(espera, inmediata = false) {
    if (inmediata) { clearTimeout(revisionPendiente); revisionPendiente = null; }
    if (revisionPendiente === null) revisionPendiente = setTimeout(prepararGrilla, espera);
  }

  function prepararGrilla() {
    revisionPendiente = null;
    if (document.visibilityState !== "visible" || loteEnCurso) return;
    const ahora = Date.now();
    if (ahora < reintentarDesde) return programarRevision(reintentarDesde - ahora);
    const nuevos = new Map();
    document.querySelectorAll('[id^="vLLAMADAS_"]').forEach((b) => {
      const d = leerFila(b.id.slice("vLLAMADAS_".length));
      const clave = clavePreparacion(d);
      if (!d.paciente || ahora - (enLista.get(clave) || 0) < 4 * 60000) return;
      nuevos.set(clave, { paciente: d.paciente, ambito: d.ambito });
    });
    if (!nuevos.size) return;
    const lote = [...nuevos.entries()].slice(0, 25);
    const solicitud = {};
    loteEnCurso = solicitud;
    solicitud.cancelar = pedirPreparacion({ tipo: "prepararLista", datos: lote.map(([, d]) => d) }, (ok) => {
      if (loteEnCurso !== solicitud) return;
      loteEnCurso = null;
      if (ok) {
        lote.forEach(([clave]) => enLista.set(clave, Date.now()));
        esperaReintento = 3000;
        reintentarDesde = 0;
        // Busca también filas que aparecieron mientras este lote viajaba.
        programarRevision(3000);
      } else {
        reintentarDesde = Date.now() + esperaReintento;
        programarRevision(esperaReintento, true);
        esperaReintento = Math.min(esperaReintento * 2, 30000);
      }
    });
  }
  function revisarGrilla() { programarRevision(500); }
  function renovarPreparacion() {
    for (const solicitud of preparando.values()) solicitud.cancelar();
    preparando.clear();
    if (loteEnCurso) loteEnCurso.cancelar();
    loteEnCurso = null;
    recibidos.clear(); enLista.clear();
    esperaReintento = 3000; reintentarDesde = 0;
    programarRevision(0, true);
  }
  new MutationObserver(revisarGrilla).observe(document.documentElement, { childList: true, characterData: true, subtree: true });
  document.addEventListener("visibilitychange", revisarGrilla);
  window.addEventListener("online", () => { renovarPreparacion(); precalentar(); });
  chrome.storage.onChanged.addListener((cambios, area) => {
    const claves = ["ipTv", "puerto", "codigo", "servidor", "usuarioServidor", "claveServidor",
      "consultorio", "voz", "velocidad", "tono", "soloConsultorio"];
    if (area === "local" && claves.some((k) => k in cambios)) { renovarPreparacion(); precalentar(); }
  });
  setInterval(() => {
    const limite = Date.now() - 4 * 60000;
    for (const mapa of [recibidos, enLista]) {
      for (const [clave, fecha] of mapa) if (fecha < limite) mapa.delete(clave);
    }
    for (const clave of Object.keys(ultimoEnvio)) if (ultimoEnvio[clave] < limite) delete ultimoEnvio[clave];
    revisarGrilla();
  }, 60000);
  revisarGrilla();

  // Mientras el panel está abierto y a la vista, la extensión mantiene lista la conexión con el TV,
  // así el llamado sale al instante (sin esperar a conectarse cuando el médico toca el parlante).
  function precalentar() {
    if (document.visibilityState !== "visible") return;
    try { chrome.runtime.sendMessage({ tipo: "precalentar" }, () => void chrome.runtime.lastError); } catch (e) { /* extensión recargada */ }
  }
  if (window === window.top) {
    precalentar();
    setInterval(precalentar, 25000);
    document.addEventListener("visibilitychange", precalentar);
  }

  document.addEventListener("keydown", (e) => {
    if (e.repeat || (e.key !== "Enter" && e.key !== " ")) return;
    const b = botonLlamar(e);
    if (b) alLlamar(b);
  }, true);
})();
