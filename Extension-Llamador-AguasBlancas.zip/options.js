const PREDETERMINADO = {
  consultorio: "",
  ipTv: "",
  puerto: 8765,
  codigo: "",
  servidor: "",
  usuarioServidor: "",
  claveServidor: "",
  soloConsultorio: true,
  voz: "auto",
  tono: "normal",
  velocidad: "normal",
  respaldo: true
};
const $ = (id) => document.getElementById(id);

function mostrar(msg, ok) {
  const e = $("estado");
  e.textContent = msg;
  e.className = "mensaje " + (ok ? "ok" : "error");
}

function leerFormulario() {
  return {
    consultorio: $("consultorio").value.trim(),
    ipTv: $("ipTv").value.trim().replace(/^https?:\/\//, "").replace(/[:/].*$/, ""),
    puerto: parseInt($("puerto").value, 10) || 8765,
    codigo: LlamadorRemoto.normalizar($("codigo").value),
    servidor: $("servidor").value.trim(),
    usuarioServidor: $("usuarioServidor").value.trim(),
    claveServidor: $("claveServidor").value,
    soloConsultorio: $("soloConsultorio").checked,
    voz: $("voz").value || "auto",
    tono: $("tono").value,
    velocidad: $("velocidad").value,
    respaldo: $("respaldo").checked
  };
}

// Pide permiso para hablar con la dirección del TV. Chrome solo muestra la pregunta la primera vez;
// se llama directo desde el clic (sin esperas antes), porque Chrome exige que sea parte del clic.
function permisoTv(c) {
  return chrome.permissions.request({ origins: ["http://" + c.ipTv + "/*"] }).catch(() => false);
}

async function guardar() {
  const c = leerFormulario();
  if (!c.consultorio) return mostrar("Escribí el número de consultorio.", false), false;
  if (!c.ipTv && !c.codigo) return mostrar("Cargá la dirección del TV (misma red) o el código de vinculación (otra red).", false), false;
  if (c.ipTv && !/^[\w.-]+$/.test(c.ipTv)) return mostrar("Revisá la dirección del TV (ej: 192.168.1.50).", false), false;
  if (c.codigo && !LlamadorRemoto.valido(c.codigo)) return mostrar("El código de vinculación tiene 16 letras y números. Revisalo en el TV con OK del control remoto.", false), false;
  if (c.servidor && !/^wss?:\/\//.test(c.servidor)) return mostrar("La dirección del servidor propio tiene que empezar con wss://", false), false;
  if (c.ipTv && !(await permisoTv(c))) return mostrar("Sin el permiso, la extensión no puede comunicarse con el TV por la red local.", false), false;
  await Almacen.set(c);
  $("codigo").value = c.codigo ? LlamadorRemoto.formatear(c.codigo) : "";
  enviarMensaje({ tipo: "reiniciarConexion" });
  mostrar("Cambios guardados.", true);
  if (window.revisarConexionTv) window.revisarConexionTv();
  return true;
}

// ---------- Elegir la voz del llamado ----------
const VL = window.VocesLlamador;
let vocesTv = null;   // lo que informó el TV (null = todavía no respondió)
let descargaTv = null; // estado de la descarga de voces en el TV
let diagTv = null;     // cómo anduvo la voz en los últimos llamados (lo informa el TV)

function vozIncluidaEnTv() { return vocesTv && vocesTv.some((v) => v.incluida); }

// Arma las tarjetas de voces (se ven siempre, aunque el TV no responda).
function dibujarVoces() {
  const elegida = $("voz").value || "auto";
  [["femenina", "vocesFemeninas"], ["masculina", "vocesMasculinas"]].forEach(([g, idCaja]) => {
    const caja = $(idCaja);
    caja.innerHTML = "";
    VL.VOCES.filter((v) => v.genero === g).forEach((v) => {
      const deTv = vocesTv && vocesTv.find((x) => x.id === v.id);
      const bajando = !!(deTv && deTv.descargada === false);
      const label = document.createElement("label");
      label.className = "voz";
      const radio = document.createElement("input");
      radio.type = "radio"; radio.name = "vozElegida"; radio.value = v.id;
      radio.checked = elegida === v.id;
      const texto = document.createElement("span"); texto.className = "voz-texto";
      const b = document.createElement("b"); b.textContent = v.nombre;
      const det = document.createElement("span");
      det.textContent = (v.nativa ? "Acento de " + v.acento : "Acento latino neutro") + (v.recomendada ? " · rápida y la que mejor se entiende" : v.menosClara ? " · rápida, pero se entiende menos" : v.rapida ? " · rápida" : " · más lenta") +
        (bajando ? " · el TV la está descargando" : deTv && deTv.rtf ? " · en este TV tarda ~" + segundos(deTv.rtf * 1.6) + " en preparar un nombre" : "");
      if (v.nativa && !bajando) det.className = "nativa";
      texto.append(b, det);
      label.append(radio, texto, VL.botonMuestra(v));
      caja.appendChild(label);
    });
  });
  document.querySelector('#opcionAuto input').checked = elegida === "auto";
  document.querySelector('#opcionTv input').checked = elegida === "sistema";
  dibujarVozDelTv();
  explicarVoz();
}

// La tarjeta «Voz del TV»: la voz de fábrica del TV, que sale al instante.
function dibujarVozDelTv() {
  const deTv = vocesTv && vocesTv.find((x) => x.id === VL.VOZ_TV.id);
  const base = "Instantánea: la dice el propio TV (la voz de Google o la que tenga), sin esperar a prepararla. Suena menos natural que las voces de la app.";
  let t = base;
  if (deTv && deTv.descargada === false) t = "Este TV no tiene instalada una voz en español, así que no se puede usar. Podés instalarla en el TV: Ajustes > Sistema > Idioma > Salida de texto a voz.";
  else if (deTv) t = base + (deTv.acento ? " Voz en este TV: " + deTv.acento + "." : "") + (deTv.ms >= 0 && deTv.ms < 60000 ? " Tarda ~" + segundos(deTv.ms / 1000) + "." : "");
  $("tvDetalle").textContent = t;
}

function segundos(s) { return (Math.max(0.1, s)).toFixed(1).replace(".", ",") + " s"; }

// Explica qué voz se va a escuchar (en «Automática», cuál le toca a este consultorio).
function explicarVoz() {
  const n = parseInt((/(\d+)/.exec($("consultorio").value) || [0, 1])[1], 10) || 1;
  const disponibles = vozIncluidaEnTv() ? vocesTv.map((v) => v.id) : null;
  const auto = VL.automatica(n, disponibles);
  $("autoDetalle").textContent = "Usa a " + auto.nombre + " en todos los consultorios: es la voz que sale más rápido y la que mejor se entiende en la sala. Si querés que cada consultorio suene distinto, elegí otra voz en la PC de ese consultorio.";
  const ayuda = $("ayudaVoces");
  if (vocesTv && !vozIncluidaEnTv()) {
    ayuda.textContent = "Este TV tiene la app anterior, que usa las voces del TV. Instalá la versión nueva de la app para usar estas voces latinas.";
    return;
  }
  const v = $("voz").value === "auto" ? auto : VL.buscar($("voz").value);
  // Con «Voz del TV» el respaldo no tiene sentido: esa voz ya sale al instante.
  const sinRespaldo = !!(v && v.sistema);
  $("campoRespaldo").hidden = sinRespaldo;
  $("ayudaRespaldo").hidden = sinRespaldo;
  let texto = v && v.sistema ? "En el TV se va a escuchar la voz del propio TV, siempre al instante. La elección se guarda sola; tocá «Escuchar en el TV» para oírla allá."
    : v ? "En el TV se va a escuchar a " + v.nombre + (!$("respaldo").checked ? ", aunque el nombre tarde en estar listo" : ". Si el nombre todavía no está listo, lo dice la voz del TV") + ". La elección se guarda sola; tocá «Escuchar en el TV» para oírla allá." : "";
  if (descargaTv && !descargaTv.completa) {
    texto = (descargaTv.texto ? descargaTv.texto + (descargaTv.porcentaje >= 0 ? " (" + descargaTv.porcentaje + " %)" : "") + ". "
      : "El TV todavía no terminó de descargar las voces. ") +
      "Mientras tanto usa una voz parecida que ya tenga (o la del TV). " + texto;
  }
  ayuda.textContent = texto;
}

// Pide al TV qué voces tiene (para marcar las que no estén y si la app es la anterior).
async function cargarVoces() {
  const r = await enviarMensaje({ tipo: "voces" });
  if (!r || !r.ok || !Array.isArray(r.voces)) return false;
  vocesTv = r.voces;
  descargaTv = r.descarga || null;
  diagTv = r.diagnostico || null;
  // Mientras el TV descarga voces, se actualiza el avance cada 15 segundos.
  clearTimeout(cargarVoces._t);
  if (descargaTv && !descargaTv.completa) cargarVoces._t = setTimeout(cargarVoces, 15000);
  // El tono solo existe en las voces del sistema (app anterior del TV)
  $("campoTono").hidden = vozIncluidaEnTv() || !vocesTv.length;
  dibujarVoces();
  dibujarDiagnostico();
  return true;
}

// ---------- Diagnóstico de la voz (lo que midió el TV en los últimos llamados; sin nombres de pacientes) ----------

function seg(ms) { return (ms / 1000).toFixed(1).replace(".", ",") + " s"; }

function hace(ms) {
  const m = Math.floor((Date.now() - ms) / 60000);
  return m < 1 ? "hace un momento" : m < 60 ? "hace " + m + " min" : "hace " + Math.round(m / 60) + " h";
}

/** Segundos que tarda la voz elegida en preparar un nombre en este TV (lo midió el TV), o 0 si no se sabe. */
function tardaEnPreparar(nombreVoz) {
  const v = VL.VOCES.find((x) => x.nombre === nombreVoz);
  const deTv = v && vocesTv && vocesTv.find((x) => x.id === v.id);
  return deTv && deTv.rtf ? deTv.rtf * 1.6 : 0;
}

/** Texto para la persona: qué pasó en el último llamado y qué conviene hacer. */
function evaluarDiagnostico(d) {
  const ls = Array.isArray(d.llamados) ? d.llamados : [];
  const m = d.motor || {};
  const tv = d.tv || {};
  const consejos = [];
  let nivel = "bien", titulo;
  if (m.disponible === false) {
    // Sin las voces de la app, todo se dice con la voz del TV.
    nivel = tv.disponible ? "medio" : "mal";
    titulo = "Este TV todavía no tiene instaladas las voces de la app: los llamados se dicen con la voz del propio TV" + (tv.disponible ? "." : ", que tarda más y suena robótica.");
    const bajada = descargaTv && !descargaTv.completa ? (descargaTv.texto || "") + (descargaTv.porcentaje >= 0 ? " (" + descargaTv.porcentaje + " %)" : "") : "";
    consejos.push(bajada ? "El TV está descargando las voces: " + bajada + ". Dejalo prendido y con internet hasta que termine (el avance se ve abajo a la derecha en la pantalla del TV)." :
      "Dejá el TV prendido y con internet para que descargue las voces (unos 420 MB, una sola vez). El avance se ve abajo a la derecha en la pantalla del TV.");
    if (descargaTv && descargaTv.error) consejos.push("La descarga tuvo un problema: " + descargaTv.error);
  } else if (!ls.length) {
    titulo = "Todavía no hubo llamados desde que se prendió el TV. Tocá «Escuchar en el TV» y volvé a mirar acá.";
  } else {
    const u = ls[0];
    const tarda = tardaEnPreparar(u.voz);
    if (u.respaldo) {
      // La voz elegida no tenía el nombre listo: lo dijo la voz del TV (es lo esperado en un TV lento, no una falla).
      nivel = "medio";
      titulo = "El nombre todavía no estaba preparado con " + u.voz + ", así que lo dijo la voz del TV para no hacer esperar (empezó a sonar " + seg(u.totalMs) + " después de que el TV recibió el llamado).";
      consejos.push("Los nombres de los pacientes que ya están en la lista del panel se preparan solos con " + u.voz + (tarda ? " (en este TV cada uno tarda ~" + seg(tarda * 1000) + ")" : "") +
        ": dejá el panel abierto desde antes de empezar a atender y el nombre sale con esa voz.");
      consejos.push("Si preferís que siempre suene igual y al instante, elegí «Voz del TV».");
    } else if (u.sistema && u.voz === "Voz del TV" && !u.motivo) {
      titulo = "Bien: la voz del TV empezó a decir el nombre " + seg(u.totalMs) + " después de que el TV recibió el llamado.";
    } else if (u.sistema) {
      nivel = "mal";
      titulo = "El último llamado se dijo con la voz de fábrica del TV en modo directo (suena robótica y tarda más), porque falló lo anterior" + (u.motivo ? ": " + u.motivo : "") + ".";
      consejos.push("Probá elegir «Voz del TV» o Claudia, y tocá «Escuchar en el TV». Si sigue igual, avisame con una captura de este cuadro.");
    } else if (u.totalMs > 3500) {
      nivel = "mal";
      titulo = "El nombre empezó a sonar " + seg(u.totalMs) + " después de que el TV recibió el llamado: es demasiado.";
    } else if (u.totalMs > 2000) {
      nivel = "medio";
      titulo = "El nombre empezó a sonar " + seg(u.totalMs) + " después de que el TV recibió el llamado (el timbre dura medio segundo).";
    } else {
      titulo = "Bien: el nombre empezó a sonar " + seg(u.totalMs) + " después de que el TV recibió el llamado.";
    }
    if (u.consPrimero) consejos.push("Cuando terminó el timbre el nombre todavía no estaba listo, así que el TV dijo primero el consultorio para no dejar silencio.");
    if (!u.sistema && u.totalMs > 2000 && !u.listoAntes) {
      consejos.push("El nombre no estaba preparado de antemano" + (u.generadoMs >= 0 ? " y se generó en el momento (" + seg(u.generadoMs) + ")" : "") +
        ". Se prepara solo cuando el panel de pacientes está abierto en esta PC y el TV está encendido: dejá el panel abierto desde antes de empezar a atender" +
        (!$("respaldo").checked ? ", o activá «Si el nombre todavía no está listo, que lo diga la voz del TV»." : "."));
    }
  }
  if (m.recargas > 0) {
    nivel = nivel === "bien" ? "medio" : nivel;
    consejos.push("El TV tuvo que apagar y volver a cargar una voz " + m.recargas + (m.recargas === 1 ? " vez" : " veces") + ": hay más voces distintas en uso que las que entran en su memoria (" + m.maxMotores + "). Usá la misma voz, o «Automática», en todos los consultorios.");
  }
  if (tv.espanol === false) consejos.push("Este TV no tiene instalada una voz en español para su propia voz: sin ella no se puede usar «Voz del TV» ni el respaldo. Instalala en el TV (Ajustes > Sistema > Idioma > Salida de texto a voz).");
  else if (tv.disponible === false && tv.fallos > 0) consejos.push("La voz del TV falló " + tv.fallos + " veces seguidas y se la dejó descansar unos minutos" + (tv.error ? " (" + tv.error + ")" : "") + ".");
  if (d.conRespaldo > 0 && !(ls[0] && ls[0].respaldo)) consejos.push("Desde que se prendió el TV, " + d.conRespaldo + (d.conRespaldo === 1 ? " nombre" : " nombres") + " se dijeron con la voz del TV porque la voz elegida no los tenía listos.");
  const directos = (d.conVozDelTv || 0) - (d.conRespaldo || 0);
  if (directos > 0 && m.disponible !== false && !(ls[0] && ls[0].sistema)) consejos.push("Desde que se prendió el TV hubo " + directos + (directos === 1 ? " llamado dicho" : " llamados dichos") + " con la voz del TV (elegida o por falla).");
  return { nivel, titulo, consejos, ls, m, tv };
}

function dibujarDiagnostico() {
  const caja = $("diagVoz");
  if (!caja) return;
  if (!diagTv || !diagTv.motor) { caja.hidden = true; return; }
  const e = evaluarDiagnostico(diagTv);
  caja.hidden = false;
  caja.className = "diag diag-" + e.nivel;
  const cuerpo = $("diagCuerpo");
  cuerpo.textContent = "";
  const p = document.createElement("p");
  p.className = "diag-titulo";
  p.textContent = e.titulo;
  cuerpo.appendChild(p);
  if (e.consejos.length) {
    const ul = document.createElement("ul");
    e.consejos.forEach((c) => { const li = document.createElement("li"); li.textContent = c; ul.appendChild(li); });
    cuerpo.appendChild(ul);
  }
  if (e.ls.length) {
    const tabla = document.createElement("table");
    tabla.className = "diag-tabla";
    const cab = tabla.createTHead().insertRow();
    ["Cuándo", "Voz", "Nombre", "Empezó a sonar"].forEach((t) => { const th = document.createElement("th"); th.textContent = t; cab.appendChild(th); });
    const cb = tabla.createTBody();
    e.ls.forEach((l) => {
      const f = cb.insertRow();
      const nombre = l.respaldo ? "voz del TV (no estaba listo)" : l.sistema ? "voz del TV" : l.listoAntes ? "preparado ✓" : "generado" + (l.generadoMs >= 0 ? " (" + seg(l.generadoMs) + ")" : "");
      [hace(l.hora), l.voz, nombre, seg(l.totalMs)].forEach((t) => { f.insertCell().textContent = t; });
    });
    cuerpo.appendChild(tabla);
  }
  const t = document.createElement("p");
  t.className = "ayuda";
  const cargada = (e.m.cargados || []).length;
  const sint = e.m.sintonia ? " Medición de velocidad (segundos de cálculo por segundo de voz, con 1, 2 o 4 hilos): " +
    Object.keys(e.m.sintonia).sort().map((k) => k + " → " + String(e.m.sintonia[k]).replace(".", ",")).join(" · ") + "; usa " + e.m.hilos + "." : "";
  t.textContent = "Este TV: " + (e.m.nucleos || "?") + " núcleos, " + (e.m.memoriaMb || "?") + " MB de memoria; mantiene hasta " + (e.m.maxMotores || "?") +
    " voces cargadas a la vez (ahora " + cargada + ")." + sint + " Si se oye poco claro en la sala aunque el nombre salga rápido, en el menú de sonido del TV elegí el modo «Estándar» o «Voz» y apagá el sonido envolvente virtual.";
  cuerpo.appendChild(t);
}

async function guardarVoz() {
  const c = leerFormulario();
  await Almacen.set({ voz: c.voz, tono: c.tono, velocidad: c.velocidad, respaldo: c.respaldo });
}

$("seccionVoz").addEventListener("change", (e) => {
  if (e.target.name === "vozElegida") {
    VL.parar();
    $("voz").value = e.target.value;
    explicarVoz();
    guardarVoz();
  }
});

function enviarMensaje(m) {
  return new Promise((res) => chrome.runtime.sendMessage(m, res));
}

$("guardar").addEventListener("click", guardar);

$("probar").addEventListener("click", async () => {
  if (!(await guardar())) return;
  const r = await enviarMensaje({ tipo: "estado" });
  if (r && r.ok) {
    mostrar("Conectado con el TV " + (r.via === "internet" ? "por internet" : "por la red local") + (r.dispositivo ? " (" + r.dispositivo + ")" : "") + ".", true);
    await cargarVoces();
  }
  else mostrar("No conecta: " + (r ? r.error : "sin respuesta"), false);
});

$("prueba").addEventListener("click", async () => {
  if (!(await guardar())) return;
  const c = leerFormulario();
  const r = await enviarMensaje({
    tipo: "prueba",
    datos: { paciente: "Gutiérrez María Fernanda", consultorio: c.consultorio, voz: c.voz, tono: c.tono, velocidad: c.velocidad, prueba: true }
  });
  if (r && r.ok) mostrar("Prueba enviada: el TV dice «María Fernanda Gutiérrez, consultorio " + (c.consultorio || "") + "». La voz elegida ya quedó guardada.", true);
  else mostrar("No se pudo enviar: " + (r ? r.error : "sin respuesta"), false);
});

Almacen.get(PREDETERMINADO).then((c) => {
  $("consultorio").value = c.consultorio;
  $("ipTv").value = c.ipTv;
  $("puerto").value = c.puerto;
  $("codigo").value = c.codigo ? LlamadorRemoto.formatear(c.codigo) : "";
  $("servidor").value = c.servidor;
  $("usuarioServidor").value = c.usuarioServidor;
  $("claveServidor").value = c.claveServidor;
  if (c.servidor) document.querySelector("details.avanzado").open = true;
  $("soloConsultorio").checked = c.soloConsultorio;
  $("tono").value = c.tono;
  $("velocidad").value = c.velocidad;
  // Una voz que ya no existe (las Supertonic se sacaron por lentas) pasa a «Automática».
  $("voz").value = c.voz === "sistema" || VL.buscar(c.voz) ? c.voz : "auto";
  $("respaldo").checked = c.respaldo !== false;
  dibujarVoces();
  if (c.ipTv || c.codigo) cargarVoces();
});

$("consultorio").addEventListener("input", explicarVoz);
["tono", "velocidad"].forEach((id) => $(id).addEventListener("change", guardarVoz));
$("respaldo").addEventListener("change", () => { explicarVoz(); dibujarDiagnostico(); guardarVoz(); });


// Trae el código (y el servidor propio, si hay) directamente del TV. Solo funciona en la misma red.
$("traerCodigo").addEventListener("click", async () => {
  const c = leerFormulario();
  if (!c.ipTv) return mostrar("Para traer el código, cargá la dirección del TV en la red local.", false);
  if (!(await permisoTv(c))) return mostrar("Sin el permiso, la extensión no puede comunicarse con el TV.", false);
  await Almacen.set({ ipTv: c.ipTv, puerto: c.puerto });
  const r = await enviarMensaje({ tipo: "vinculoLocal" });
  if (!r || !r.ok) return mostrar("No se pudo traer el código: " + (r ? r.error : "sin respuesta") + ". Esta PC tiene que estar en la misma red que el TV.", false);
  $("codigo").value = LlamadorRemoto.formatear(r.codigo);
  $("servidor").value = r.servidor || "";
  $("usuarioServidor").value = r.usuario || "";
  $("claveServidor").value = r.clave || "";
  if (await guardar()) mostrar("Código cargado y guardado. Esta PC ya puede llamar aunque cambie de red.", true);
});

// Configura el servidor propio en el TV (solo desde la red local del TV).
$("servidorAlTv").addEventListener("click", async () => {
  const c = leerFormulario();
  if (c.servidor && !/^wss?:\/\//.test(c.servidor)) return mostrar("La dirección del servidor propio tiene que empezar con wss://", false);
  if (!c.ipTv || !(await permisoTv(c))) return mostrar("Para configurar el TV, esta PC tiene que estar en su misma red.", false);
  try {
    const r = await fetch("http://" + c.ipTv + ":" + c.puerto + "/vinculo/servidor", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ servidor: c.servidor, usuario: c.usuarioServidor, clave: c.claveServidor })
    }).then((x) => x.json());
    if (!r.ok) throw new Error(r.error);
    await guardar();
    mostrar(c.servidor ? "Servidor propio configurado en el TV y en esta PC." : "El TV vuelve a usar los servidores públicos.", true);
  } catch (e) {
    mostrar("No se pudo configurar el TV: " + e.message + ".", false);
  }
});

