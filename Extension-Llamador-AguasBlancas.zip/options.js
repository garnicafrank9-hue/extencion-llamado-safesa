const PREDETERMINADO = {
  consultorio: "",
  ipTv: "",
  puerto: 8765,
  codigo: "",
  servidor: "",
  usuarioServidor: "",
  claveServidor: "",
  soloConsultorio: true,
  voz: "auto",
  tono: "normal",
  velocidad: "normal"
};
const $ = (id) => document.getElementById(id);

function mostrar(msg, ok) {
  const e = $("estado");
  e.textContent = msg;
  e.className = "mensaje " + (ok ? "ok" : "error");
}

function leerFormulario() {
  return {
    consultorio: $("consultorio").value.trim(),
    ipTv: $("ipTv").value.trim().replace(/^https?:\/\//, "").replace(/[:/].*$/, ""),
    puerto: parseInt($("puerto").value, 10) || 8765,
    codigo: LlamadorRemoto.normalizar($("codigo").value),
    servidor: $("servidor").value.trim(),
    usuarioServidor: $("usuarioServidor").value.trim(),
    claveServidor: $("claveServidor").value,
    soloConsultorio: $("soloConsultorio").checked,
    voz: $("voz").value || "auto",
    tono: $("tono").value,
    velocidad: $("velocidad").value
  };
}

// Pide permiso para hablar con la dirección del TV. Chrome solo muestra la pregunta la primera vez;
// se llama directo desde el clic (sin esperas antes), porque Chrome exige que sea parte del clic.
function permisoTv(c) {
  return chrome.permissions.request({ origins: ["http://" + c.ipTv + "/*"] }).catch(() => false);
}

async function guardar() {
  const c = leerFormulario();
  if (!c.consultorio) return mostrar("Escribí el número de consultorio.", false), false;
  if (!c.ipTv && !c.codigo) return mostrar("Cargá la dirección del TV (misma red) o el código de vinculación (otra red).", false), false;
  if (c.ipTv && !/^[\w.-]+$/.test(c.ipTv)) return mostrar("Revisá la dirección del TV (ej: 192.168.1.50).", false), false;
  if (c.codigo && !LlamadorRemoto.valido(c.codigo)) return mostrar("El código de vinculación tiene 16 letras y números. Revisalo en el TV con OK del control remoto.", false), false;
  if (c.servidor && !/^wss?:\/\//.test(c.servidor)) return mostrar("La dirección del servidor propio tiene que empezar con wss://", false), false;
  if (c.ipTv && !(await permisoTv(c))) return mostrar("Sin el permiso, la extensión no puede comunicarse con el TV por la red local.", false), false;
  await Almacen.set(c);
  $("codigo").value = c.codigo ? LlamadorRemoto.formatear(c.codigo) : "";
  enviarMensaje({ tipo: "reiniciarConexion" });
  mostrar("Cambios guardados.", true);
  if (window.revisarConexionTv) window.revisarConexionTv();
  return true;
}

// ---------- Elegir la voz del llamado ----------
const VL = window.VocesLlamador;
let vocesTv = null;   // lo que informó el TV (null = todavía no respondió)
let descargaTv = null; // estado de la descarga de voces en el TV

function vozIncluidaEnTv() { return vocesTv && vocesTv.some((v) => v.incluida); }

// Arma las tarjetas de voces (se ven siempre, aunque el TV no responda).
function dibujarVoces() {
  const elegida = $("voz").value || "auto";
  [["femenina", "vocesFemeninas"], ["masculina", "vocesMasculinas"]].forEach(([g, idCaja]) => {
    const caja = $(idCaja);
    caja.innerHTML = "";
    VL.VOCES.filter((v) => v.genero === g).forEach((v) => {
      const deTv = vocesTv && vocesTv.find((x) => x.id === v.id);
      const bajando = !!(deTv && deTv.descargada === false);
      const label = document.createElement("label");
      label.className = "voz";
      const radio = document.createElement("input");
      radio.type = "radio"; radio.name = "vozElegida"; radio.value = v.id;
      radio.checked = elegida === v.id;
      const texto = document.createElement("span"); texto.className = "voz-texto";
      const b = document.createElement("b"); b.textContent = v.nombre;
      const det = document.createElement("span");
      det.textContent = (v.nativa ? "Acento de " + v.acento : "Acento latino neutro") + (v.rapida ? " · la más rápida" : "") +
        (bajando ? " · el TV la está descargando" : deTv && deTv.rtf ? " · en este TV ~" + segundos(deTv.rtf * 1.6) + " por nombre" : "");
      if (v.nativa && !bajando) det.className = "nativa";
      texto.append(b, det);
      label.append(radio, texto, VL.botonMuestra(v));
      caja.appendChild(label);
    });
  });
  document.querySelector('#opcionAuto input').checked = elegida === "auto";
  explicarVoz();
}

function segundos(s) { return (Math.max(0.1, s)).toFixed(1).replace(".", ",") + " s"; }

// Explica qué voz se va a escuchar (en «Automática», cuál le toca a este consultorio).
function explicarVoz() {
  const n = parseInt((/(\d+)/.exec($("consultorio").value) || [0, 1])[1], 10) || 1;
  const disponibles = vozIncluidaEnTv() ? vocesTv.map((v) => v.id) : null;
  const auto = VL.automatica(n, disponibles);
  $("autoDetalle").textContent = "Una voz distinta para cada consultorio. Al consultorio " + n + " le toca " + auto.nombre + ".";
  const ayuda = $("ayudaVoces");
  if (vocesTv && !vozIncluidaEnTv()) {
    ayuda.textContent = "Este TV tiene la app anterior, que usa las voces del TV. Instalá la versión nueva de la app para usar estas voces latinas.";
    return;
  }
  const v = $("voz").value === "auto" ? auto : VL.buscar($("voz").value);
  let texto = v ? "En el TV se va a escuchar a " + v.nombre + ". La elección se guarda sola; tocá «Escuchar en el TV» para oírla allá." : "";
  if (descargaTv && !descargaTv.completa) {
    texto = (descargaTv.texto ? descargaTv.texto + (descargaTv.porcentaje >= 0 ? " (" + descargaTv.porcentaje + " %)" : "") + ". "
      : "El TV todavía no terminó de descargar las voces. ") +
      "Mientras tanto usa una voz parecida que ya tenga (o la del TV). " + texto;
  }
  ayuda.textContent = texto;
}

// Pide al TV qué voces tiene (para marcar las que no estén y si la app es la anterior).
async function cargarVoces() {
  const r = await enviarMensaje({ tipo: "voces" });
  if (!r || !r.ok || !Array.isArray(r.voces)) return false;
  vocesTv = r.voces;
  descargaTv = r.descarga || null;
  // Mientras el TV descarga voces, se actualiza el avance cada 15 segundos.
  clearTimeout(cargarVoces._t);
  if (descargaTv && !descargaTv.completa) cargarVoces._t = setTimeout(cargarVoces, 15000);
  // El tono solo existe en las voces del sistema (app anterior del TV)
  $("campoTono").hidden = vozIncluidaEnTv() || !vocesTv.length;
  dibujarVoces();
  return true;
}

async function guardarVoz() {
  const c = leerFormulario();
  await Almacen.set({ voz: c.voz, tono: c.tono, velocidad: c.velocidad });
}

$("seccionVoz").addEventListener("change", (e) => {
  if (e.target.name === "vozElegida") {
    VL.parar();
    $("voz").value = e.target.value;
    explicarVoz();
    guardarVoz();
  }
});

function enviarMensaje(m) {
  return new Promise((res) => chrome.runtime.sendMessage(m, res));
}

$("guardar").addEventListener("click", guardar);

$("probar").addEventListener("click", async () => {
  if (!(await guardar())) return;
  const r = await enviarMensaje({ tipo: "estado" });
  if (r && r.ok) {
    mostrar("Conectado con el TV " + (r.via === "internet" ? "por internet" : "por la red local") + (r.dispositivo ? " (" + r.dispositivo + ")" : "") + ".", true);
    await cargarVoces();
  }
  else mostrar("No conecta: " + (r ? r.error : "sin respuesta"), false);
});

$("prueba").addEventListener("click", async () => {
  if (!(await guardar())) return;
  const c = leerFormulario();
  const r = await enviarMensaje({
    tipo: "prueba",
    datos: { paciente: "María Fernanda Gutiérrez", consultorio: c.consultorio, voz: c.voz, tono: c.tono, velocidad: c.velocidad, prueba: true }
  });
  if (r && r.ok) mostrar("Prueba enviada: el TV dice «María Fernanda Gutiérrez, consultorio " + (c.consultorio || "") + "». La voz elegida ya quedó guardada.", true);
  else mostrar("No se pudo enviar: " + (r ? r.error : "sin respuesta"), false);
});

Almacen.get(PREDETERMINADO).then((c) => {
  $("consultorio").value = c.consultorio;
  $("ipTv").value = c.ipTv;
  $("puerto").value = c.puerto;
  $("codigo").value = c.codigo ? LlamadorRemoto.formatear(c.codigo) : "";
  $("servidor").value = c.servidor;
  $("usuarioServidor").value = c.usuarioServidor;
  $("claveServidor").value = c.claveServidor;
  if (c.servidor) document.querySelector("details.avanzado").open = true;
  $("soloConsultorio").checked = c.soloConsultorio;
  $("tono").value = c.tono;
  $("velocidad").value = c.velocidad;
  $("voz").value = c.voz || "auto";
  dibujarVoces();
  if (c.ipTv || c.codigo) cargarVoces();
});

$("consultorio").addEventListener("input", explicarVoz);
["tono", "velocidad"].forEach((id) => $(id).addEventListener("change", guardarVoz));


// Trae el código (y el servidor propio, si hay) directamente del TV. Solo funciona en la misma red.
$("traerCodigo").addEventListener("click", async () => {
  const c = leerFormulario();
  if (!c.ipTv) return mostrar("Para traer el código, cargá la dirección del TV en la red local.", false);
  if (!(await permisoTv(c))) return mostrar("Sin el permiso, la extensión no puede comunicarse con el TV.", false);
  await Almacen.set({ ipTv: c.ipTv, puerto: c.puerto });
  const r = await enviarMensaje({ tipo: "vinculoLocal" });
  if (!r || !r.ok) return mostrar("No se pudo traer el código: " + (r ? r.error : "sin respuesta") + ". Esta PC tiene que estar en la misma red que el TV.", false);
  $("codigo").value = LlamadorRemoto.formatear(r.codigo);
  $("servidor").value = r.servidor || "";
  $("usuarioServidor").value = r.usuario || "";
  $("claveServidor").value = r.clave || "";
  if (await guardar()) mostrar("Código cargado y guardado. Esta PC ya puede llamar aunque cambie de red.", true);
});

// Configura el servidor propio en el TV (solo desde la red local del TV).
$("servidorAlTv").addEventListener("click", async () => {
  const c = leerFormulario();
  if (c.servidor && !/^wss?:\/\//.test(c.servidor)) return mostrar("La dirección del servidor propio tiene que empezar con wss://", false);
  if (!c.ipTv || !(await permisoTv(c))) return mostrar("Para configurar el TV, esta PC tiene que estar en su misma red.", false);
  try {
    const r = await fetch("http://" + c.ipTv + ":" + c.puerto + "/vinculo/servidor", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ servidor: c.servidor, usuario: c.usuarioServidor, clave: c.claveServidor })
    }).then((x) => x.json());
    if (!r.ok) throw new Error(r.error);
    await guardar();
    mostrar(c.servidor ? "Servidor propio configurado en el TV y en esta PC." : "El TV vuelve a usar los servidores públicos.", true);
  } catch (e) {
    mostrar("No se pudo configurar el TV: " + e.message + ".", false);
  }
});

