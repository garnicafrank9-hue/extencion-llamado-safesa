// Configuración de esta PC. Se guarda solo en esta computadora (chrome.storage.local) y no se sincroniza con la
// cuenta de Google: así el número de consultorio y la conexión de una PC nunca pisan los de otra.
// Las versiones anteriores la guardaban en chrome.storage.sync: la primera vez se copia lo que había.
(function (g) {
  "use strict";
  let migracion = null;

  function migrar() {
    if (!migracion) {
      migracion = (async () => {
        try {
          const marca = await chrome.storage.local.get("migradoDeSync");
          if (marca.migradoDeSync) return;
          const viejo = await chrome.storage.sync.get(null);
          const hay = viejo && Object.keys(viejo).length > 0;
          // Lo que ya hubiera en esta PC tiene prioridad sobre lo viejo de la cuenta.
          if (hay) await chrome.storage.local.set(Object.assign({}, viejo, await chrome.storage.local.get(null)));
          await chrome.storage.local.set({ migradoDeSync: true });
        } catch (e) {
          migracion = null; // se reintenta en el próximo acceso
        }
      })();
    }
    return migracion;
  }

  g.Almacen = {
    async get(predeterminado) { await migrar(); return chrome.storage.local.get(predeterminado); },
    async set(valores) { await migrar(); return chrome.storage.local.set(valores); }
  };
})(typeof self !== "undefined" ? self : this);
