// Fotos de los profesionales: se achican en esta PC antes de mandarlas al TV.
//
// • Una ilustración o foto con fondo transparente («recorte») se recorta justo al contorno de la persona.
// • Una fotografía común se recorta en vertical (4:5) y se centra en la parte de arriba, donde suele estar la cara.
// En los dos casos queda en formato WebP y pesa menos de 60 KB, así viaja rápido incluso por internet.
// Cada foto se identifica por el SHA-256 de su contenido: la misma imagen siempre tiene el mismo nombre.
(function (g) {
  "use strict";

  const MAX_BYTES = 60 * 1024;        // el TV acepta hasta 100 KB; se apunta más abajo
  const MAX_ARCHIVO = 25 * 1024 * 1024;
  const LADO_RECORTE = 560;           // lado mayor de un recorte
  const FOTO_ANCHO = 480, FOTO_ALTO = 600;
  const CLAVE_CACHE = "cacheFotos";
  const MAX_CACHE = 30;

  // Ilustraciones que vienen con la extensión (ya están achicadas y con fondo transparente).
  const incluidas = [
    { archivo: "fotos/dra-sanchez.webp", titulo: "Dra. Sánchez", detalle: "Clínica médica", clave: "sanchez" },
    { archivo: "fotos/dra-civila.webp", titulo: "Dra. Leila Civila", detalle: "Odontología", clave: "civila" }
  ];

  function sinTildes(s) { return String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase(); }

  // ---------- Conversión de bytes ----------

  function aBase64(bytes) {
    let s = "";
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }
  function deBase64(txt) {
    const s = atob(txt), b = new Uint8Array(s.length);
    for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i);
    return b;
  }
  async function idDe(bytes) {
    const h = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
    return Array.from(h.slice(0, 8)).map((x) => x.toString(16).padStart(2, "0")).join("");
  }
  function tipoDe(b) {
    if (b.length > 11 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
    if (b.length > 3 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
    if (b.length > 2 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
    return "";
  }

  // ---------- Procesar una imagen ----------

  function lienzo(w, h) { const c = document.createElement("canvas"); c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h)); return c; }

  async function abrir(blob) {
    if (!blob || !/^image\//.test(blob.type || "image/")) throw new Error("Ese archivo no es una imagen. Elegí un PNG, JPG o WebP.");
    if (blob.size > MAX_ARCHIVO) throw new Error("La imagen pesa demasiado (más de 25 MB). Elegí una más chica.");
    try { return await createImageBitmap(blob); }
    catch (e) { throw new Error("No se pudo leer la imagen. Probá con un archivo PNG, JPG o WebP."); }
  }

  /** ¿Tiene fondo transparente? (esquinas transparentes y una parte importante de la imagen sin color) */
  function esRecorte(bmp) {
    const w = Math.min(bmp.width, 160), h = Math.max(1, Math.round(bmp.height * w / bmp.width));
    const c = lienzo(w, h), x = c.getContext("2d", { willReadFrequently: true });
    x.drawImage(bmp, 0, 0, w, h);
    const d = x.getImageData(0, 0, c.width, c.height).data, W = c.width, H = c.height;
    let vacios = 0;
    for (let i = 3; i < d.length; i += 4) if (d[i] < 200) vacios++;
    const a = (px, py) => d[(py * W + px) * 4 + 3] < 200;
    const esquinas = [a(0, 0), a(W - 1, 0), a(0, H - 1), a(W - 1, H - 1)].filter(Boolean).length;
    return vacios / (W * H) > 0.04 && esquinas >= 2;
  }

  async function codificar(lienzoOrigen) {
    let c = lienzoOrigen;
    for (let ronda = 0; ronda < 6; ronda++) {
      for (const q of [0.86, 0.78, 0.7, 0.6, 0.5]) {
        const blob = await new Promise((ok) => c.toBlob(ok, "image/webp", q));
        if (!blob || blob.type !== "image/webp") throw new Error("Este navegador no pudo preparar la imagen.");
        if (blob.size <= MAX_BYTES) return new Uint8Array(await blob.arrayBuffer());
      }
      const n = lienzo(c.width * 0.85, c.height * 0.85);
      n.getContext("2d").drawImage(c, 0, 0, n.width, n.height);
      c = n;
    }
    throw new Error("No se pudo achicar lo suficiente la imagen. Probá con otra más simple.");
  }

  function recortar(bmp) {
    // Se trabaja a un tamaño razonable para no gastar memoria con imágenes enormes.
    const k = Math.min(1, 1400 / Math.max(bmp.width, bmp.height));
    const base = lienzo(bmp.width * k, bmp.height * k), bx = base.getContext("2d", { willReadFrequently: true });
    bx.drawImage(bmp, 0, 0, base.width, base.height);
    const d = bx.getImageData(0, 0, base.width, base.height).data, W = base.width, H = base.height;
    let x0 = W, y0 = H, x1 = -1, y1 = -1;
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        if (d[(y * W + x) * 4 + 3] > 24) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      }
    }
    if (x1 < 0) throw new Error("La imagen está vacía (todo transparente).");
    const mx = Math.round(W * 0.012), my = Math.round(H * 0.012);
    x0 = Math.max(0, x0 - mx); y0 = Math.max(0, y0 - my); x1 = Math.min(W - 1, x1 + mx); y1 = Math.min(H - 1, y1 + my);
    const cw = x1 - x0 + 1, ch = y1 - y0 + 1, e = Math.min(1, LADO_RECORTE / Math.max(cw, ch));
    const out = lienzo(cw * e, ch * e);
    out.getContext("2d").drawImage(base, x0, y0, cw, ch, 0, 0, out.width, out.height);
    return out;
  }

  function fotografia(bmp) {
    const e = Math.max(FOTO_ANCHO / bmp.width, FOTO_ALTO / bmp.height);
    const sw = FOTO_ANCHO / e, sh = FOTO_ALTO / e;
    const sx = (bmp.width - sw) / 2, sy = Math.min(Math.max(0, (bmp.height - sh) * 0.3), Math.max(0, bmp.height - sh));
    const out = lienzo(FOTO_ANCHO, FOTO_ALTO), x = out.getContext("2d");
    x.fillStyle = "#fff"; x.fillRect(0, 0, out.width, out.height);
    x.imageSmoothingQuality = "high";
    x.drawImage(bmp, sx, sy, sw, sh, 0, 0, FOTO_ANCHO, FOTO_ALTO);
    return out;
  }

  /** Achica y convierte una imagen elegida por la persona. Devuelve {id, modo, tipo, bytes, datos (base64)}. */
  async function procesar(blob) {
    const bmp = await abrir(blob);
    try {
      const modo = esRecorte(bmp) ? "recorte" : "foto";
      const bytes = await codificar(modo === "recorte" ? recortar(bmp) : fotografia(bmp));
      return await listo(bytes, modo);
    } finally {
      if (bmp.close) bmp.close();
    }
  }

  async function listo(bytes, modo) {
    return { id: await idDe(bytes), modo, tipo: tipoDe(bytes) || "image/webp", bytes, datos: aBase64(bytes) };
  }

  /** Una ilustración incluida en la extensión (se manda tal cual, ya está lista). */
  async function incluida(item) {
    const r = await fetch(chrome.runtime.getURL(item.archivo));
    if (!r.ok) throw new Error("No se pudo leer la ilustración incluida.");
    return listo(new Uint8Array(await r.arrayBuffer()), "recorte");
  }

  function url(f) { return "data:" + f.tipo + ";base64," + f.datos; }

  /** ¿Cuál de las ilustraciones incluidas corresponde a ese nombre? (para sugerirla) */
  function sugerida(nombre) {
    const n = sinTildes(nombre);
    const i = incluidas.find((x) => n.includes(x.clave));
    return i ? i.archivo : "";
  }

  // ---------- Memoria de las fotos ya vistas (para no pedirlas al TV cada vez) ----------

  const enMemoria = new Map();
  let cargada = null;

  async function cache() {
    if (!cargada) {
      cargada = (async () => {
        try {
          const r = await Almacen.get({ [CLAVE_CACHE]: {} });
          Object.entries(r[CLAVE_CACHE] || {}).forEach(([id, v]) => { if (v && typeof v.u === "string" && !enMemoria.has(id)) enMemoria.set(id, v.u); });
        } catch (e) { /* sin memoria guardada: se pide al TV */ }
      })();
    }
    return cargada;
  }
  const porGuardar = {};
  function recordar(id, u) {
    enMemoria.set(id, u);
    porGuardar[id] = u;
    clearTimeout(recordar.t);
    recordar.t = setTimeout(async () => {
      const lote = Object.assign({}, porGuardar);
      Object.keys(porGuardar).forEach((k) => { delete porGuardar[k]; });
      try {
        const ahora = await Almacen.get({ [CLAVE_CACHE]: {} });
        const todo = ahora[CLAVE_CACHE] || {};
        Object.entries(lote).forEach(([k, v]) => { todo[k] = { u: v, t: Date.now() }; });
        const ids = Object.keys(todo).sort((x, y) => todo[y].t - todo[x].t).slice(0, MAX_CACHE);
        const nuevo = {};
        ids.forEach((k) => { nuevo[k] = todo[k]; });
        await Almacen.set({ [CLAVE_CACHE]: nuevo });
      } catch (e) { /* no pasa nada: es solo una ayuda para ir más rápido */ }
    }, 400);
  }
  function memoria(id) { return enMemoria.get(id) || ""; }

  g.Fotos = { MAX_BYTES, incluidas, procesar, incluida, url, sugerida, cache, recordar, memoria, aBase64, deBase64, tipoDe, idDe };
})(typeof self !== "undefined" ? self : this);
