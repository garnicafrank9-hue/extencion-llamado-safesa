// Horario de atención de los profesionales (se muestra en el TV). La lista es una sola para todo el centro
// y se guarda en el TV: cada profesional tiene su consultorio, y la mañana y la tarde sus propios días y horas.
const $ = (id) => document.getElementById(id);
const DIAS = [[1, "Lun"], [2, "Mar"], [3, "Mié"], [4, "Jue"], [5, "Vie"], [6, "Sáb"], [0, "Dom"]];
const MAX = 80;
let cargado = false;   // solo se guarda si antes se leyó lo que tiene el TV (para no borrar nada sin querer)
let cambios = false;
let miConsultorio = "";
let instantanea = "";  // lo que había en el TV cuando se abrió la página (para avisar si otra PC lo cambió)

function mostrar(msg, ok) {
  const e = $("estado");
  e.textContent = msg;
  e.className = "mensaje " + (ok ? "ok" : "error");
  clearTimeout(e._t);
  if (ok) e._t = setTimeout(() => { e.className = "mensaje"; }, 8000);
}

function api(ruta, cuerpo) {
  return new Promise((ok, mal) => {
    chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
      if (chrome.runtime.lastError) return mal(new Error("La extensión no respondió; recargá la página."));
      if (r && r.ok) ok(r); else mal(new Error(primeraMayuscula((r && r.error) || "sin respuesta del TV")));
    });
  });
}
function primeraMayuscula(s) { s = String(s); return s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : "."); }

function el(tag, props, hijos) {
  const e = document.createElement(tag);
  Object.assign(e, props || {});
  (hijos || []).forEach((h) => e.appendChild(typeof h === "string" ? document.createTextNode(h) : h));
  return e;
}

/** "9", "930", "9.30", "14:5" -> "09:00", "09:30", "09:30", "14:05"; null si no es una hora válida. */
function normalizarHora(t) {
  t = String(t || "").trim().replace(/\s*(hs?|horas?)\.?$/i, "");
  let m = /^(\d{1,2})[:.,h ]?(\d{1,2})?$/.exec(t);
  if (/^\d{3,4}$/.test(t)) m = [t, t.slice(0, t.length - 2), t.slice(-2)];
  if (!m) return null;
  const h = +m[1], mi = m[2] === undefined ? 0 : +m[2];
  if (h > 23 || mi > 59) return null;
  return String(h).padStart(2, "0") + ":" + String(mi).padStart(2, "0");
}

/** "Consultorio 3" -> "3" (para el campo); texto libre si no tiene número. */
function numero(c) {
  const m = /(\d+)/.exec(c || "");
  return m ? String(parseInt(m[1], 10)) : String(c || "").trim();
}
function nombreDias(ds) {
  const orden = DIAS.filter(([d]) => ds.includes(d)).map(([, n]) => n);
  if (orden.join() === "Lun,Mar,Mié,Jue,Vie") return "Lun a Vie";
  if (orden.join() === "Lun,Mar,Mié,Jue,Vie,Sáb") return "Lun a Sáb";
  return orden.join(", ");
}

// ---------- Tarjeta de un profesional ----------

function bloqueTurno(titulo, clave, r, porDefecto, diasPorDefecto) {
  const activo = !!r;
  const v = r || porDefecto;
  const dias = (r && (r.dias || r._diasViejos)) || diasPorDefecto;
  const chk = el("input", { type: "checkbox", checked: activo, className: "usa" });
  const desde = el("input", { type: "text", inputMode: "numeric", maxLength: 5, value: v.desde, placeholder: porDefecto.desde, className: "hora-prof desde" });
  const hasta = el("input", { type: "text", inputMode: "numeric", maxLength: 5, value: v.hasta, placeholder: porDefecto.hasta, className: "hora-prof hasta" });
  [desde, hasta].forEach((i) => i.addEventListener("blur", () => { const h = normalizarHora(i.value); if (h) i.value = h; }));
  desde.setAttribute("aria-label", "Desde (" + titulo.toLowerCase() + ")");
  hasta.setAttribute("aria-label", "Hasta (" + titulo.toLowerCase() + ")");
  const chips = el("div", { className: "dias", role: "group" });
  chips.setAttribute("aria-label", "Días de la " + titulo.toLowerCase());
  DIAS.forEach(([d, n]) => chips.appendChild(el("label", {}, [el("input", { type: "checkbox", value: String(d), checked: dias.includes(d) }), el("span", { textContent: n })])));
  const caja = el("div", { className: "turno-prof turno-" + clave }, [
    el("label", { className: "check" }, [chk, " Atiende a la " + titulo.toLowerCase()]),
    el("div", { className: "horas-prof" }, ["De ", desde, " a ", hasta]),
    chips
  ]);
  const sync = () => { caja.classList.toggle("apagado", !chk.checked); desde.disabled = hasta.disabled = !chk.checked; };
  chk.addEventListener("change", sync);
  sync();
  return caja;
}

function tarjeta(p) {
  p = p || { consultorio: miConsultorio, profesional: "", especialidad: "", manana: { desde: "07:00", hasta: "13:00", dias: [1, 2, 3, 4, 5] }, tarde: null };
  // Datos de versiones anteriores: los días eran los mismos para los dos turnos.
  ["manana", "tarde"].forEach((k) => { if (p[k] && !p[k].dias && p.dias) p[k] = Object.assign({}, p[k], { dias: p.dias }); });
  const id = "p" + Math.random().toString(36).slice(2);
  const t = el("div", { className: "prof" });
  const nombre = el("input", { type: "text", className: "nombre-prof", value: p.profesional || "", placeholder: "Dra. Sánchez", maxLength: 60, id: id + "n" });
  const esp = el("input", { type: "text", className: "esp-prof", value: p.especialidad || "", placeholder: "Clínica médica", maxLength: 60, id: id + "e" });
  const cons = el("input", { type: "text", className: "cons-prof", value: numero(p.consultorio), placeholder: "3", maxLength: 20, id: id + "c", inputMode: "numeric" });
  const quitar = el("button", { type: "button", className: "quitar peligro", textContent: "Quitar" });
  quitar.addEventListener("click", () => { t.remove(); actualizarFiltro(); numerar(); marcar(); });
  t.append(
    el("div", { className: "prof-cab" }, [el("span", { className: "cons-chip" }), el("b", { className: "num-prof" }), el("span", { className: "resumen" }), el("span", { className: "espacio-linea" }), quitar]),
    el("div", { className: "datos-prof" }, [
      el("div", {}, [el("label", { htmlFor: id + "n", textContent: "Profesional" }), nombre]),
      el("div", {}, [el("label", { htmlFor: id + "e", textContent: "Especialidad" }), esp]),
      el("div", {}, [el("label", { htmlFor: id + "c", textContent: "Consultorio N.º" }), cons])
    ]),
    el("div", { className: "turnos-prof" }, [
      bloqueTurno("Mañana", "manana", p.manana, { desde: "07:00", hasta: "13:00" }, [1, 2, 3, 4, 5]),
      bloqueTurno("Tarde", "tarde", p.tarde, { desde: "14:00", hasta: "20:00" }, [1, 2, 3, 4, 5])
    ]),
    el("div", { className: "error-prof", hidden: true })
  );
  t.addEventListener("input", () => { marcar(); resumen(t); });
  t.addEventListener("change", () => { marcar(); resumen(t); });
  cons.addEventListener("change", actualizarFiltro);
  resumen(t);
  return t;
}

function leerTurno(t, k) {
  const caja = t.querySelector(".turno-" + k);
  if (!caja.querySelector(".usa").checked) return { r: null };
  const txt = k === "manana" ? "mañana" : "tarde";
  const desde = normalizarHora(caja.querySelector(".desde").value), hasta = normalizarHora(caja.querySelector(".hasta").value);
  const dias = [...caja.querySelectorAll(".dias input:checked")].map((i) => +i.value);
  if (!desde || !hasta) return { e: "revisá las horas de la " + txt + " (por ejemplo 14:30)" };
  if (desde >= hasta) return { e: "en la " + txt + ", «de» tiene que ser antes que «a»" };
  if (!dias.length) return { e: "elegí los días de la " + txt };
  return { r: { desde, hasta, dias } };
}

function leer(t) {
  const prof = t.querySelector(".nombre-prof").value.trim().replace(/\s+/g, " ");
  const cons = t.querySelector(".cons-prof").value.trim();
  const m = leerTurno(t, "manana"), ta = leerTurno(t, "tarde");
  let e = "";
  if (!prof) e = "escribí el nombre del profesional";
  else if (!cons) e = "escribí el número de consultorio";
  else if (m.e || ta.e) e = m.e || ta.e;
  else if (!m.r && !ta.r) e = "marcá si atiende a la mañana, a la tarde o en los dos turnos";
  return e ? { error: e, prof } : { item: {
    profesional: prof, especialidad: t.querySelector(".esp-prof").value.trim(),
    consultorio: /^\d+$/.test(cons) ? "Consultorio " + parseInt(cons, 10) : cons, manana: m.r, tarde: ta.r } };
}

// Encabezado de la tarjeta: consultorio y resumen de días y horas.
function resumen(t) {
  const cons = t.querySelector(".cons-prof").value.trim();
  t.querySelector(".cons-chip").textContent = cons ? (/^\d+$/.test(cons) ? "Consultorio " + parseInt(cons, 10) : cons) : "Sin consultorio";
  const partes = [];
  [["manana", "Mañana"], ["tarde", "Tarde"]].forEach(([k, n]) => {
    const r = leerTurno(t, k).r;
    if (r) partes.push(n + ": " + nombreDias(r.dias) + " " + r.desde + " a " + r.hasta);
  });
  t.querySelector(".resumen").textContent = partes.join(" · ");
}

function numerar() {
  const ts = [...$("profesionales").children];
  ts.forEach((x) => { x.querySelector(".num-prof").textContent = x.querySelector(".nombre-prof").value.trim() || "Profesional nuevo"; });
  $("sinProfesionales").hidden = ts.length > 0 || !cargado;
  $("agregarProfesional").disabled = ts.length >= MAX;
}

function marcar() {
  cambios = true;
  $("enviarHorarios").textContent = "Guardar y mostrar en el TV •";
  numerar();
}

// Filtro por consultorio (para encontrar rápido a los de cada uno).
function actualizarFiltro() {
  const sel = $("filtro"), antes = sel.value;
  const nums = [...new Set([...$("profesionales").children].map((t) => t.querySelector(".cons-prof").value.trim()).filter(Boolean))]
    .sort((a, b) => (parseInt(a, 10) || 999) - (parseInt(b, 10) || 999));
  sel.innerHTML = "";
  sel.add(new Option("Todos los consultorios", ""));
  nums.forEach((n) => sel.add(new Option(/^\d+$/.test(n) ? "Consultorio " + n : n, n)));
  sel.value = nums.includes(antes) ? antes : "";
  filtrar();
}
function filtrar() {
  const f = $("filtro").value;
  [...$("profesionales").children].forEach((t) => { t.hidden = !!f && t.querySelector(".cons-prof").value.trim() !== f; });
}
$("filtro").addEventListener("change", filtrar);

function dibujar(items) {
  const lista = $("profesionales");
  lista.innerHTML = "";
  items.slice().sort((a, b) => (parseInt(numero(a.consultorio), 10) || 999) - (parseInt(numero(b.consultorio), 10) || 999))
    .forEach((p) => lista.appendChild(tarjeta(p)));
  actualizarFiltro();
  numerar();
}

// ---------- Acciones ----------

async function cargar() {
  const c = await Almacen.get({ consultorio: "" });
  miConsultorio = numero(c.consultorio);
  try {
    const r = await api("/horarios");
    cargado = true;
    cambios = false;
    instantanea = JSON.stringify(r.items || []);
    dibujar(r.items || []);
    // Al abrir, se muestran los de este consultorio (si tiene alguno).
    if (miConsultorio && [...$("filtro").options].some((o) => o.value === miConsultorio)) { $("filtro").value = miConsultorio; filtrar(); }
  } catch (e) {
    mostrar("No se pudieron leer los horarios del TV: " + e.message + " Revisá la conexión y recargá la página.", false);
  }
}

$("agregarProfesional").addEventListener("click", () => {
  if (!cargado) return mostrar("Primero tiene que responder el TV (para no borrar los horarios que ya tiene).", false);
  const f = $("filtro").value;
  const t = tarjeta({ consultorio: f || miConsultorio, profesional: "", especialidad: "", manana: { desde: "07:00", hasta: "13:00", dias: [1, 2, 3, 4, 5] }, tarde: null });
  $("profesionales").appendChild(t);
  actualizarFiltro();
  marcar();
  t.scrollIntoView({ block: "center", behavior: "smooth" });
  t.querySelector(".nombre-prof").focus();
});

$("enviarHorarios").addEventListener("click", async () => {
  if (!cargado) return mostrar("Primero tiene que responder el TV (para no borrar los horarios que ya tiene). Recargá la página.", false);
  const items = [];
  let primero = null;
  [...$("profesionales").children].forEach((t) => {
    const r = leer(t);
    const err = t.querySelector(".error-prof");
    err.hidden = !r.error;
    err.textContent = r.error ? (r.prof || "Profesional nuevo") + ": " + r.error + "." : "";
    t.classList.toggle("con-error", !!r.error);
    if (r.error && !primero) primero = { t, msg: err.textContent };
    if (r.item) items.push(r.item);
  });
  if (primero) {
    $("filtro").value = ""; filtrar();
    primero.t.scrollIntoView({ block: "center", behavior: "smooth" });
    return mostrar(primero.msg, false);
  }
  const b = $("enviarHorarios");
  b.disabled = true;
  try {
    // Si otra computadora guardó horarios mientras se editaba acá, se pregunta antes de pisarlos.
    const actual = await api("/horarios");
    if (JSON.stringify(actual.items || []) !== instantanea &&
        !confirm("Otra computadora cambió los horarios del TV mientras los editabas.\n\nSi guardás ahora, se reemplazan por lo que ves en esta pantalla.\n\n¿Guardar de todos modos?")) {
      mostrar("No se guardó. Recargá la página (F5) para ver los cambios de la otra computadora.", false);
      return;
    }
    const r = await api("/horarios/guardar", { items });
    cambios = false;
    const filtro = $("filtro").value;
    const nuevo = await api("/horarios").catch(() => r);
    instantanea = JSON.stringify(nuevo.items || []);
    dibujar(r.items || items);
    if ([...$("filtro").options].some((o) => o.value === filtro)) { $("filtro").value = filtro; filtrar(); }
    b.textContent = "Guardar y mostrar en el TV";
    mostrar("Horarios guardados en el TV (" + items.length + (items.length === 1 ? " profesional" : " profesionales") + ").", true);
  } catch (e) {
    mostrar("No se pudieron guardar: " + e.message + (/consultorio/.test(e.message) ? " Puede que el TV tenga la app anterior: actualizala." : ""), false);
  } finally {
    b.disabled = false;
  }
});

window.addEventListener("beforeunload", (e) => { if (cambios) { e.preventDefault(); e.returnValue = ""; } });
cargar();
