// Horario de atención de los profesionales (se muestra en el TV). La lista es una sola para todo el centro
// y se guarda en el TV: cada profesional tiene su consultorio, y la mañana y la tarde sus propios días y horas.
const $ = (id) => document.getElementById(id);
const DIAS = [[1, "Lun"], [2, "Mar"], [3, "Mié"], [4, "Jue"], [5, "Vie"], [6, "Sáb"], [0, "Dom"]];
const MAX = 80;
let cargado = false;   // solo se guarda si antes se leyó lo que tiene el TV (para no borrar nada sin querer)
let cambios = false;
let miConsultorio = "";
let instantanea = "";  // lo que había en el TV cuando se abrió la página (para avisar si otra PC lo cambió)

function mostrar(msg, ok) {
  const e = $("estado");
  e.textContent = msg;
  e.className = "mensaje " + (ok ? "ok" : "error");
  clearTimeout(e._t);
  if (ok) e._t = setTimeout(() => { e.className = "mensaje"; }, 8000);
}

function api(ruta, cuerpo) {
  return new Promise((ok, mal) => {
    chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
      if (chrome.runtime.lastError) return mal(new Error("La extensión no respondió; recargá la página."));
      if (r && r.ok) ok(r); else mal(new Error(primeraMayuscula((r && r.error) || "sin respuesta del TV")));
    });
  });
}
function primeraMayuscula(s) { s = String(s); return s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : "."); }

function el(tag, props, hijos) {
  const e = document.createElement(tag);
  Object.assign(e, props || {});
  (hijos || []).forEach((h) => e.appendChild(typeof h === "string" ? document.createTextNode(h) : h));
  return e;
}

/** "9", "930", "9.30", "14:5" -> "09:00", "09:30", "09:30", "14:05"; null si no es una hora válida. */
function normalizarHora(t) {
  t = String(t || "").trim().replace(/\s*(hs?|horas?)\.?$/i, "");
  let m = /^(\d{1,2})[:.,h ]?(\d{1,2})?$/.exec(t);
  if (/^\d{3,4}$/.test(t)) m = [t, t.slice(0, t.length - 2), t.slice(-2)];
  if (!m) return null;
  const h = +m[1], mi = m[2] === undefined ? 0 : +m[2];
  if (h > 23 || mi > 59) return null;
  return String(h).padStart(2, "0") + ":" + String(mi).padStart(2, "0");
}

/** "Consultorio 3" -> "3" (para el campo); texto libre si no tiene número. */
function numero(c) {
  const m = /(\d+)/.exec(c || "");
  return m ? String(parseInt(m[1], 10)) : String(c || "").trim();
}
function nombreDias(ds) {
  const orden = DIAS.filter(([d]) => ds.includes(d)).map(([, n]) => n);
  if (orden.join() === "Lun,Mar,Mié,Jue,Vie") return "Lun a Vie";
  if (orden.join() === "Lun,Mar,Mié,Jue,Vie,Sáb") return "Lun a Sáb";
  return orden.join(", ");
}

// ---------- Tarjeta de un profesional ----------

function bloqueTurno(titulo, clave, r, porDefecto, diasPorDefecto) {
  const activo = !!r;
  const v = r || porDefecto;
  const dias = (r && (r.dias || r._diasViejos)) || diasPorDefecto;
  const chk = el("input", { type: "checkbox", checked: activo, className: "usa" });
  const desde = el("input", { type: "text", inputMode: "numeric", maxLength: 5, value: v.desde, placeholder: porDefecto.desde, className: "hora-prof desde" });
  const hasta = el("input", { type: "text", inputMode: "numeric", maxLength: 5, value: v.hasta, placeholder: porDefecto.hasta, className: "hora-prof hasta" });
  [desde, hasta].forEach((i) => i.addEventListener("blur", () => { const h = normalizarHora(i.value); if (h) i.value = h; }));
  desde.setAttribute("aria-label", "Desde (" + titulo.toLowerCase() + ")");
  hasta.setAttribute("aria-label", "Hasta (" + titulo.toLowerCase() + ")");
  const chips = el("div", { className: "dias", role: "group" });
  chips.setAttribute("aria-label", "Días de la " + titulo.toLowerCase());
  DIAS.forEach(([d, n]) => chips.appendChild(el("label", {}, [el("input", { type: "checkbox", value: String(d), checked: dias.includes(d) }), el("span", { textContent: n })])));
  const caja = el("div", { className: "turno-prof turno-" + clave }, [
    el("label", { className: "check" }, [chk, " Atiende a la " + titulo.toLowerCase()]),
    el("div", { className: "horas-prof" }, ["De ", desde, " a ", hasta]),
    chips
  ]);
  const sync = () => { caja.classList.toggle("apagado", !chk.checked); desde.disabled = hasta.disabled = !chk.checked; };
  chk.addEventListener("change", sync);
  sync();
  return caja;
}

function tarjeta(p) {
  p = p || { consultorio: miConsultorio, profesional: "", especialidad: "", manana: { desde: "07:00", hasta: "13:00", dias: [1, 2, 3, 4, 5] }, tarde: null };
  // Datos de versiones anteriores: los días eran los mismos para los dos turnos.
  ["manana", "tarde"].forEach((k) => { if (p[k] && !p[k].dias && p.dias) p[k] = Object.assign({}, p[k], { dias: p.dias }); });
  const id = "p" + Math.random().toString(36).slice(2);
  const t = el("div", { className: "prof" });
  const nombre = el("input", { type: "text", className: "nombre-prof", value: p.profesional || "", placeholder: "Dra. Sánchez", maxLength: 60, id: id + "n" });
  const esp = el("input", { type: "text", className: "esp-prof", value: p.especialidad || "", placeholder: "Clínica médica", maxLength: 60, id: id + "e" });
  const cons = el("input", { type: "text", className: "cons-prof", value: numero(p.consultorio), placeholder: "3", maxLength: 20, id: id + "c", inputMode: "numeric" });
  const quitar = el("button", { type: "button", className: "quitar peligro", textContent: "Quitar" });
  quitar.addEventListener("click", () => { t.remove(); actualizarFiltro(); numerar(); marcar(); });
  // Foto: {id, modo, url (para mostrarla), datos (base64, solo si todavía hay que mandarla al TV)}
  t._foto = p.foto ? { id: p.foto, modo: p.fotoModo === "foto" ? "foto" : "recorte", url: Fotos.memoria(p.foto), datos: null } : null;
  const marco = el("button", { type: "button", className: "foto-marco" });
  marco.addEventListener("click", () => abrirDialogoFoto(t));
  const quitarFoto = el("button", { type: "button", className: "enlace foto-quitar", textContent: "Quitar foto" });
  quitarFoto.addEventListener("click", () => { t._foto = null; pintarFoto(t); marcar(); });
  // Si el nombre coincide con una de las ilustraciones incluidas, se ofrece usarla con un solo clic.
  const sugerir = el("button", { type: "button", className: "enlace sugerir", hidden: true });
  sugerir.addEventListener("click", async () => {
    try { ponerFoto(t, await Fotos.incluida(sugerir._item)); } catch (e) { mostrar(e.message || "No se pudo usar la ilustración.", false); }
  });
  t.append(
    el("div", { className: "prof-cab" }, [el("span", { className: "cons-chip" }), el("b", { className: "num-prof" }), el("span", { className: "resumen" }), el("span", { className: "espacio-linea" }), quitar]),
    el("div", { className: "prof-cuerpo" }, [
      el("div", { className: "foto-prof" }, [marco, quitarFoto, sugerir]),
      el("div", { className: "prof-campos" }, [
        el("div", { className: "datos-prof" }, [
          el("div", {}, [el("label", { htmlFor: id + "n", textContent: "Profesional" }), nombre]),
          el("div", {}, [el("label", { htmlFor: id + "e", textContent: "Especialidad" }), esp]),
          el("div", {}, [el("label", { htmlFor: id + "c", textContent: "Consultorio N.º" }), cons])
        ]),
        el("div", { className: "turnos-prof" }, [
          bloqueTurno("Mañana", "manana", p.manana, { desde: "07:00", hasta: "13:00" }, [1, 2, 3, 4, 5]),
          bloqueTurno("Tarde", "tarde", p.tarde, { desde: "14:00", hasta: "20:00" }, [1, 2, 3, 4, 5])
        ])
      ])
    ]),
    el("div", { className: "error-prof", hidden: true })
  );
  pintarFoto(t);
  t.addEventListener("input", () => { marcar(); resumen(t); actualizarSugerencia(t); });
  t.addEventListener("change", () => { marcar(); resumen(t); });
  cons.addEventListener("change", actualizarFiltro);
  resumen(t);
  return t;
}

function leerTurno(t, k) {
  const caja = t.querySelector(".turno-" + k);
  if (!caja.querySelector(".usa").checked) return { r: null };
  const txt = k === "manana" ? "mañana" : "tarde";
  const desde = normalizarHora(caja.querySelector(".desde").value), hasta = normalizarHora(caja.querySelector(".hasta").value);
  const dias = [...caja.querySelectorAll(".dias input:checked")].map((i) => +i.value);
  if (!desde || !hasta) return { e: "revisá las horas de la " + txt + " (por ejemplo 14:30)" };
  if (desde >= hasta) return { e: "en la " + txt + ", «de» tiene que ser antes que «a»" };
  if (!dias.length) return { e: "elegí los días de la " + txt };
  return { r: { desde, hasta, dias } };
}

function leer(t) {
  const prof = t.querySelector(".nombre-prof").value.trim().replace(/\s+/g, " ");
  const cons = t.querySelector(".cons-prof").value.trim();
  const m = leerTurno(t, "manana"), ta = leerTurno(t, "tarde");
  let e = "";
  if (!prof) e = "escribí el nombre del profesional";
  else if (!cons) e = "escribí el número de consultorio";
  else if (m.e || ta.e) e = m.e || ta.e;
  else if (!m.r && !ta.r) e = "marcá si atiende a la mañana, a la tarde o en los dos turnos";
  return e ? { error: e, prof } : { item: {
    profesional: prof, especialidad: t.querySelector(".esp-prof").value.trim(),
    consultorio: /^\d+$/.test(cons) ? "Consultorio " + parseInt(cons, 10) : cons, manana: m.r, tarde: ta.r,
    foto: t._foto ? t._foto.id : "", fotoModo: t._foto ? t._foto.modo : "" } };
}

// Encabezado de la tarjeta: consultorio y resumen de días y horas.
function resumen(t) {
  const cons = t.querySelector(".cons-prof").value.trim();
  t.querySelector(".cons-chip").textContent = cons ? (/^\d+$/.test(cons) ? "Consultorio " + parseInt(cons, 10) : cons) : "Sin consultorio";
  const partes = [];
  [["manana", "Mañana"], ["tarde", "Tarde"]].forEach(([k, n]) => {
    const r = leerTurno(t, k).r;
    if (r) partes.push(n + ": " + nombreDias(r.dias) + " " + r.desde + " a " + r.hasta);
  });
  t.querySelector(".resumen").textContent = partes.join(" · ");
}

function numerar() {
  const ts = [...$("profesionales").children];
  ts.forEach((x) => { x.querySelector(".num-prof").textContent = x.querySelector(".nombre-prof").value.trim() || "Profesional nuevo"; });
  $("sinProfesionales").hidden = ts.length > 0 || !cargado;
  $("agregarProfesional").disabled = ts.length >= MAX;
}

function marcar() {
  cambios = true;
  $("enviarHorarios").textContent = "Guardar y mostrar en el TV •";
  numerar();
}

// Filtro por consultorio (para encontrar rápido a los de cada uno).
function actualizarFiltro() {
  const sel = $("filtro"), antes = sel.value;
  const nums = [...new Set([...$("profesionales").children].map((t) => t.querySelector(".cons-prof").value.trim()).filter(Boolean))]
    .sort((a, b) => (parseInt(a, 10) || 999) - (parseInt(b, 10) || 999));
  sel.innerHTML = "";
  sel.add(new Option("Todos los consultorios", ""));
  nums.forEach((n) => sel.add(new Option(/^\d+$/.test(n) ? "Consultorio " + n : n, n)));
  sel.value = nums.includes(antes) ? antes : "";
  filtrar();
}
function filtrar() {
  const f = $("filtro").value;
  [...$("profesionales").children].forEach((t) => { t.hidden = !!f && t.querySelector(".cons-prof").value.trim() !== f; });
}
$("filtro").addEventListener("change", filtrar);

function dibujar(items) {
  const lista = $("profesionales");
  lista.innerHTML = "";
  items.slice().sort((a, b) => (parseInt(numero(a.consultorio), 10) || 999) - (parseInt(numero(b.consultorio), 10) || 999))
    .forEach((p) => lista.appendChild(tarjeta(p)));
  [...lista.children].forEach(pedirFoto);   // las vistas previas se piden cuando las tarjetas ya están en la página
  actualizarFiltro();
  numerar();
}

// ---------- Foto del profesional ----------

const CAMARA = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h3l1.6-2.4h6.8L17 8h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.2" r="3.6"/></svg>';

function pintarFoto(t) {
  const caja = t.querySelector(".foto-marco"), f = t._foto;
  const nombre = t.querySelector(".nombre-prof").value.trim() || "el profesional";
  caja.innerHTML = "";
  caja.classList.toggle("tiene", !!f);
  caja.classList.toggle("fotografia", !!f && f.modo === "foto");
  caja.setAttribute("aria-label", (f ? "Cambiar la foto de " : "Agregar una foto a ") + nombre);
  if (!f) {
    const v = el("span", { className: "foto-vacia" });
    v.innerHTML = CAMARA;
    v.appendChild(document.createTextNode("Agregar foto"));
    caja.appendChild(v);
  } else if (f.url) {
    caja.appendChild(el("img", { src: f.url, alt: "" }));
    caja.appendChild(el("span", { className: "foto-cambiar", textContent: "Cambiar" }));
  } else {
    caja.appendChild(el("span", { className: "foto-cargando", textContent: f.error ? "Sin vista previa" : "Cargando…" }));
  }
  t.querySelector(".foto-quitar").hidden = !f;
  actualizarSugerencia(t);
}

function actualizarSugerencia(t) {
  const b = t.querySelector(".sugerir");
  const archivo = t._foto ? "" : Fotos.sugerida(t.querySelector(".nombre-prof").value);
  const item = Fotos.incluidas.find((i) => i.archivo === archivo);
  b.hidden = !item;
  b._item = item || null;
  if (item) b.textContent = "Usar la de " + item.titulo;
}

function ponerFoto(t, f) {
  const url = Fotos.url(f);
  Fotos.recordar(f.id, url);
  t._foto = { id: f.id, modo: f.modo, url, datos: f.datos };
  pintarFoto(t);
  marcar();
}

// Las vistas previas de las fotos que ya están en el TV se piden de a dos (y se recuerdan en esta PC).
const colaFotos = [];
let fotosActivas = 0;
function pedirFoto(t) {
  const f = t._foto;
  if (!f || f.url) return;
  const guardada = Fotos.memoria(f.id);
  if (guardada) { f.url = guardada; pintarFoto(t); return; }
  colaFotos.push(t);
  avanzarFotos();
}
function avanzarFotos() {
  while (fotosActivas < 2 && colaFotos.length) {
    const t = colaFotos.shift(), f = t._foto;
    if (!f || f.url || !t.isConnected) continue;
    fotosActivas++;
    api("/foto/obtener", { id: f.id })
      .then((r) => { f.url = "data:" + (r.tipo || "image/webp") + ";base64," + r.datos; Fotos.recordar(f.id, f.url); })
      .catch(() => { f.error = true; })
      .finally(() => { fotosActivas--; if (t._foto === f) pintarFoto(t); avanzarFotos(); });
  }
}

function mensajeFoto(m) {
  return /no encontrado|no permitida|no disponible|solo se puede hacer desde la red local/i.test(m)
    ? "el TV todavía tiene una versión de la aplicación que no acepta fotos. Instalá la versión 2.9 o más nueva (pestaña «Actualizaciones»)"
    : m;
}

let fotoTarjeta = null;   // la tarjeta a la que se le está eligiendo la foto

function errorFoto(msg) {
  const e = $("dlgFotoError");
  e.textContent = msg || "";
  e.className = "mensaje" + (msg ? " error" : "");
}

function abrirDialogoFoto(t) {
  fotoTarjeta = t;
  const nombre = t.querySelector(".nombre-prof").value.trim();
  $("dlgFotoTitulo").textContent = nombre ? "Foto de " + nombre : "Foto del profesional";
  $("dlgFotoQuitar").hidden = !t._foto;
  errorFoto("");
  const sugerida = Fotos.sugerida(nombre);
  const g = $("galeria");
  g.innerHTML = "";
  Fotos.incluidas.forEach((i) => {
    const b = el("button", { type: "button" }, [
      el("span", { className: "miniatura" }, [el("img", { src: chrome.runtime.getURL(i.archivo), alt: "" })]),
      el("span", {}, [el("b", { textContent: i.titulo }), el("small", { textContent: i.detalle })])
    ]);
    if (i.archivo === sugerida) b.insertBefore(el("span", { className: "sugerida", textContent: "Sugerida" }), b.firstChild);
    b.addEventListener("click", () => aplicarFoto(() => Fotos.incluida(i)));
    g.appendChild(b);
  });
  $("dlgFoto").showModal();
}

async function aplicarFoto(preparar) {
  const t = fotoTarjeta, dlg = $("dlgFoto");
  if (!t || !t.isConnected) return;
  const botones = dlg.querySelectorAll("button");
  botones.forEach((b) => { b.disabled = true; });
  errorFoto("");
  try {
    ponerFoto(t, await preparar());
    dlg.close();
  } catch (e) {
    errorFoto(e.message || "No se pudo usar esa imagen.");
  } finally {
    botones.forEach((b) => { b.disabled = false; });
  }
}

$("elegirArchivo").addEventListener("click", () => { $("archivoFoto").value = ""; $("archivoFoto").click(); });
$("archivoFoto").addEventListener("change", () => {
  const a = $("archivoFoto").files && $("archivoFoto").files[0];
  if (a) aplicarFoto(() => Fotos.procesar(a));
});
$("dlgFotoQuitar").addEventListener("click", () => {
  if (fotoTarjeta && fotoTarjeta.isConnected) { fotoTarjeta._foto = null; pintarFoto(fotoTarjeta); marcar(); }
  $("dlgFoto").close();
});
$("dlgFotoCerrar").addEventListener("click", () => $("dlgFoto").close());

// ---------- Acciones ----------

async function cargar() {
  const c = await Almacen.get({ consultorio: "" });
  miConsultorio = numero(c.consultorio);
  await Fotos.cache();
  try {
    const r = await api("/horarios");
    cargado = true;
    cambios = false;
    instantanea = JSON.stringify(r.items || []);
    dibujar(r.items || []);
    // Al abrir, se muestran los de este consultorio (si tiene alguno).
    if (miConsultorio && [...$("filtro").options].some((o) => o.value === miConsultorio)) { $("filtro").value = miConsultorio; filtrar(); }
  } catch (e) {
    mostrar("No se pudieron leer los horarios del TV: " + e.message + " Revisá la conexión y recargá la página.", false);
  }
}

$("agregarProfesional").addEventListener("click", () => {
  if (!cargado) return mostrar("Primero tiene que responder el TV (para no borrar los horarios que ya tiene).", false);
  const f = $("filtro").value;
  const t = tarjeta({ consultorio: f || miConsultorio, profesional: "", especialidad: "", manana: { desde: "07:00", hasta: "13:00", dias: [1, 2, 3, 4, 5] }, tarde: null });
  $("profesionales").appendChild(t);
  actualizarFiltro();
  marcar();
  t.scrollIntoView({ block: "center", behavior: "smooth" });
  t.querySelector(".nombre-prof").focus();
});

$("enviarHorarios").addEventListener("click", async () => {
  if (!cargado) return mostrar("Primero tiene que responder el TV (para no borrar los horarios que ya tiene). Recargá la página.", false);
  const items = [];
  let primero = null;
  [...$("profesionales").children].forEach((t) => {
    const r = leer(t);
    const err = t.querySelector(".error-prof");
    err.hidden = !r.error;
    err.textContent = r.error ? (r.prof || "Profesional nuevo") + ": " + r.error + "." : "";
    t.classList.toggle("con-error", !!r.error);
    if (r.error && !primero) primero = { t, msg: err.textContent };
    if (r.item) items.push(r.item);
  });
  if (primero) {
    $("filtro").value = ""; filtrar();
    primero.t.scrollIntoView({ block: "center", behavior: "smooth" });
    return mostrar(primero.msg, false);
  }
  const b = $("enviarHorarios");
  b.disabled = true;
  try {
    // Si otra computadora guardó horarios mientras se editaba acá, se pregunta antes de pisarlos.
    const actual = await api("/horarios");
    if (JSON.stringify(actual.items || []) !== instantanea &&
        !confirm("Otra computadora cambió los horarios del TV mientras los editabas.\n\nSi guardás ahora, se reemplazan por lo que ves en esta pantalla.\n\n¿Guardar de todos modos?")) {
      mostrar("No se guardó. Recargá la página (F5) para ver los cambios de la otra computadora.", false);
      return;
    }
    // Las fotos nuevas viajan primero; si alguna falla, no se guarda nada y se avisa cuál fue.
    for (const t of [...$("profesionales").children]) {
      if (!t._foto || !t._foto.datos) continue;
      const quien = t.querySelector(".nombre-prof").value.trim() || "el profesional";
      try {
        await api("/foto/subir", { id: t._foto.id, datos: t._foto.datos });
        t._foto.datos = null;
      } catch (e) {
        mostrar("No se pudo subir la foto de " + quien + ": " + mensajeFoto(e.message) + ".", false);
        return;
      }
    }
    const r = await api("/horarios/guardar", { items });
    cambios = false;
    const filtro = $("filtro").value;
    const nuevo = await api("/horarios").catch(() => r);
    instantanea = JSON.stringify(nuevo.items || []);
    dibujar(r.items || items);
    if ([...$("filtro").options].some((o) => o.value === filtro)) { $("filtro").value = filtro; filtrar(); }
    b.textContent = "Guardar y mostrar en el TV";
    mostrar("Horarios guardados en el TV (" + items.length + (items.length === 1 ? " profesional" : " profesionales") + ").", true);
  } catch (e) {
    mostrar("No se pudieron guardar: " + e.message + (/consultorio/.test(e.message) ? " Puede que el TV tenga la app anterior: actualizala." : ""), false);
  } finally {
    b.disabled = false;
  }
});

window.addEventListener("beforeunload", (e) => { if (cambios) { e.preventDefault(); e.returnValue = ""; } });
cargar();
