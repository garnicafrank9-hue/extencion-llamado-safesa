// Avisos por voz para la sala de espera: se guardan en el TV y el TV los dice solo, a la hora indicada.
const $ = (id) => document.getElementById(id);
const VL = window.VocesLlamador;
const MAX_AVISOS = 12, MAX_TEXTO = 400;
const REPETIR = [
  [0, "Solo cuando lo pida"], [15, "Cada 15 minutos"], [20, "Cada 20 minutos"], [30, "Cada 30 minutos"],
  [45, "Cada 45 minutos"], [60, "Cada 1 hora"], [90, "Cada 1 hora y media"], [120, "Cada 2 horas"],
  [180, "Cada 3 horas"], [240, "Cada 4 horas"]
];
const DIAS = [[1, "Lun"], [2, "Mar"], [3, "Mié"], [4, "Jue"], [5, "Vie"], [6, "Sáb"], [0, "Dom"]];
let cargado = false;      // solo se guarda si antes se leyó lo que tiene el TV (para no borrar nada sin querer)
let cambios = false;
let instantanea = "";     // lo que había en el TV cuando se abrió la página (para avisar si otra PC lo cambió)

function mostrar(msg, ok) {
  const e = $("estado");
  e.textContent = msg;
  e.className = "mensaje " + (ok ? "ok" : "error");
  clearTimeout(e._t);
  if (ok) e._t = setTimeout(() => { e.className = "mensaje"; }, 7000);
}

function api(ruta, cuerpo) {
  return new Promise((ok, mal) => {
    chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
      if (chrome.runtime.lastError) return mal(new Error("La extensión no respondió; recargá la página."));
      if (r && r.ok) ok(r); else mal(new Error(primeraMayuscula((r && r.error) || "sin respuesta del TV")));
    });
  });
}
function primeraMayuscula(s) { s = String(s); return s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : "."); }

function el(tag, props, hijos) {
  const e = document.createElement(tag);
  Object.assign(e, props || {});
  (hijos || []).forEach((h) => e.appendChild(typeof h === "string" ? document.createTextNode(h) : h));
  return e;
}

/** "9", "930", "9.30" -> "09:00", "09:30"; null si no es una hora. */
function normalizarHora(t) {
  t = String(t || "").trim();
  let m = /^(\d{1,2})[:.,h ]?(\d{2})?$/.exec(t);
  if (/^\d{3,4}$/.test(t)) m = [t, t.slice(0, t.length - 2), t.slice(-2)];
  if (!m) return null;
  const h = +m[1], mi = m[2] === undefined ? 0 : +m[2];
  if (h > 23 || mi > 59) return null;
  return String(h).padStart(2, "0") + ":" + String(mi).padStart(2, "0");
}
const aMin = (h) => +h.slice(0, 2) * 60 + +h.slice(3, 5);
const aHora = (m) => String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0");

// ---------- Tarjetas ----------

function tarjeta(a) {
  a = Object.assign({ id: "", texto: "", voz: "n-daniela", velocidad: "normal", repetir: 60, desde: "07:00", hasta: "20:00",
    dias: [1, 2, 3, 4, 5], mostrar: true, activo: true }, a || {});
  const t = el("div", { className: "aviso-tarjeta" });
  t.dataset.id = a.id || "";
  const activo = el("input", { type: "checkbox", className: "activo", checked: a.activo !== false });
  const quitar = el("button", { type: "button", className: "quitar peligro", textContent: "Quitar" });
  const texto = el("textarea", { className: "texto", maxLength: MAX_TEXTO, value: a.texto, placeholder: "Por ejemplo: Les pedimos, por favor, mantener silencio en la sala de espera." });
  const idTexto = "t" + Math.random().toString(36).slice(2);
  texto.id = idTexto;
  const contador = el("div", { className: "contador" });
  const voz = el("select", { className: "voz" });
  VL.llenarSelect(voz, a.voz, false);
  const vel = el("select", { className: "vel" });
  [["lenta", "Lenta"], ["normal", "Normal"], ["rapida", "Rápida"]].forEach(([v, n]) => vel.add(new Option(n, v)));
  vel.value = a.velocidad || "normal";
  const rep = el("select", { className: "repetir" });
  REPETIR.forEach(([v, n]) => rep.add(new Option(n, String(v))));
  rep.value = String(REPETIR.some(([v]) => v === a.repetir) ? a.repetir : 0);
  const desde = el("input", { type: "text", className: "hora desde", value: a.desde || "07:00", maxLength: 5, inputMode: "numeric" });
  const hasta = el("input", { type: "text", className: "hora hasta", value: a.hasta || "20:00", maxLength: 5, inputMode: "numeric" });
  desde.setAttribute("aria-label", "Desde");
  hasta.setAttribute("aria-label", "Hasta");
  const dias = el("div", { className: "dias", role: "group" });
  dias.setAttribute("aria-label", "Días");
  DIAS.forEach(([d, n]) => dias.appendChild(el("label", {}, [el("input", { type: "checkbox", value: String(d), checked: (a.dias || []).includes(d) }), el("span", { textContent: n })])));
  const horario = el("div", { className: "horario" }, ["De ", desde, " a ", hasta, dias]);
  const mostrarChk = el("input", { type: "checkbox", className: "mostrar", checked: a.mostrar !== false });
  const decir = el("button", { type: "button", textContent: "Decir ahora en el TV" });
  const ids = ["v", "r", "s"].map((x) => x + Math.random().toString(36).slice(2));
  voz.id = ids[0]; rep.id = ids[1]; vel.id = ids[2];

  t.append(
    el("div", { className: "aviso-cab" }, [el("b", { className: "num" }), el("label", { className: "check" }, [activo, " Activo"]), el("span", { className: "espacio" }), quitar]),
    el("label", { htmlFor: idTexto, className: "solo-lectores", textContent: "Texto del aviso" }),
    texto, contador,
    el("div", { className: "opciones-aviso" }, [
      el("div", {}, [el("label", { htmlFor: ids[1], textContent: "Repetir" }), rep]),
      el("div", {}, [el("label", { htmlFor: ids[0], textContent: "Voz" }), voz]),
      el("div", {}, [el("label", { htmlFor: ids[2], textContent: "Velocidad" }), vel])
    ]),
    horario,
    el("div", { className: "proximas" }),
    el("div", { className: "acciones-aviso" }, [decir, el("label", { className: "check" }, [mostrarChk, " Mostrar el texto en la pantalla del TV"])]),
    el("div", { className: "error-aviso", hidden: true })
  );

  [desde, hasta].forEach((i) => i.addEventListener("blur", () => { const h = normalizarHora(i.value); if (h) i.value = h; actualizar(t); }));
  t.addEventListener("input", () => { marcar(); actualizar(t); });
  t.addEventListener("change", () => { marcar(); actualizar(t); });
  quitar.addEventListener("click", () => { t.remove(); numerar(); marcar(); });
  decir.addEventListener("click", () => decirAhora(leerTarjeta(t, true), decir));
  actualizar(t);
  return t;
}

function leerTarjeta(t, sinValidar) {
  const g = (s) => t.querySelector(s);
  const rep = +g(".repetir").value;
  const a = {
    id: t.dataset.id || undefined,
    texto: g(".texto").value.replace(/\s+/g, " ").trim(),
    voz: g(".voz").value,
    velocidad: g(".vel").value,
    repetir: rep,
    desde: normalizarHora(g(".desde").value) || g(".desde").value.trim(),
    hasta: normalizarHora(g(".hasta").value) || g(".hasta").value.trim(),
    dias: [...t.querySelectorAll(".dias input:checked")].map((i) => +i.value),
    mostrar: g(".mostrar").checked,
    activo: g(".activo").checked
  };
  if (!rep) {   // "solo cuando lo pida": el horario no se usa, pero el TV igual lo guarda
    if (!normalizarHora(a.desde)) a.desde = "07:00";
    if (!normalizarHora(a.hasta)) a.hasta = "20:00";
    if (!a.dias.length) a.dias = [1, 2, 3, 4, 5];
  }
  if (sinValidar) return a;
  let e = "";
  if (a.texto.replace(/[^\p{L}]/gu, "").length < 3) e = "escribí el texto del aviso";
  else if (rep > 0 && (!normalizarHora(a.desde) || !normalizarHora(a.hasta))) e = "revisá el horario (por ejemplo 07:15 a 20:00)";
  else if (rep > 0 && a.desde >= a.hasta) e = "«De» tiene que ser antes que «a»";
  else if (rep > 0 && !a.dias.length) e = "elegí al menos un día";
  return e ? { error: e } : { aviso: a };
}

// Cuenta de letras, horario visible y próximas veces de hoy.
function actualizar(t) {
  const a = leerTarjeta(t, true);
  const c = t.querySelector(".contador");
  c.textContent = a.texto.length + " / " + MAX_TEXTO;
  c.classList.toggle("mucho", a.texto.length > MAX_TEXTO - 30);
  t.classList.toggle("apagado", !a.activo);
  t.querySelector(".horario").classList.toggle("apagado", !a.repetir);
  const p = t.querySelector(".proximas");
  p.className = "proximas";
  if (!a.activo) { p.textContent = "Desactivado: no se dice solo."; p.classList.add("nada"); return; }
  if (!a.repetir) { p.textContent = "Se dice solo cuando tocás «Decir ahora en el TV»."; p.classList.add("nada"); return; }
  const d = normalizarHora(a.desde), h = normalizarHora(a.hasta);
  if (!d || !h || d >= h) { p.textContent = ""; return; }
  const ahora = new Date();
  if (!a.dias.includes(ahora.getDay())) { p.textContent = "Hoy no se dice (no es uno de los días marcados)."; p.classList.add("nada"); return; }
  const min = ahora.getHours() * 60 + ahora.getMinutes();
  const proximas = [];
  for (let m = aMin(d); m <= aMin(h) && proximas.length < 4; m += a.repetir) if (m >= min) proximas.push(aHora(m));
  if (!proximas.length) { p.textContent = "Por hoy ya no se dice más."; p.classList.add("nada"); return; }
  p.textContent = "Próximas veces hoy: " + proximas.join(", ") + (proximas.length === 4 ? "…" : "") + (cambios ? " (cuando guardes)" : "");
}

function numerar() {
  const ts = [...$("avisos").children];
  ts.forEach((t, i) => { t.querySelector(".num").textContent = "Aviso " + (i + 1); });
  $("sinAvisos").hidden = ts.length > 0 || !cargado;
  $("agregar").disabled = ts.length >= MAX_AVISOS;
}

function marcar() {
  if (!cambios) { cambios = true; [...$("avisos").children].forEach(actualizar); }
  $("guardar").textContent = "Guardar avisos en el TV •";
}

function dibujar(items) {
  $("avisos").innerHTML = "";
  items.forEach((a) => $("avisos").appendChild(tarjeta(a)));
  numerar();
}

// ---------- Acciones ----------

async function cargar() {
  try {
    const r = await api("/avisos");
    cargado = true;
    cambios = false;
    instantanea = JSON.stringify(r.items || []);
    dibujar(r.items || []);
    $("guardar").textContent = "Guardar avisos en el TV";
  } catch (e) {
    mostrar("No se pudieron leer los avisos del TV: " + e.message + " Revisá la conexión y recargá la página.", false);
  }
}

$("agregar").addEventListener("click", () => {
  if (!cargado) return mostrar("Primero tiene que responder el TV (para no borrar los avisos que ya tiene).", false);
  const t = tarjeta({ texto: "", repetir: 60 });
  $("avisos").appendChild(t);
  numerar();
  marcar();
  t.querySelector(".texto").focus();
});

$("guardar").addEventListener("click", async () => {
  if (!cargado) return mostrar("Primero tiene que responder el TV (para no borrar los avisos que ya tiene). Recargá la página.", false);
  const items = [];
  let primero = null;
  [...$("avisos").children].forEach((t, i) => {
    const r = leerTarjeta(t);
    const err = t.querySelector(".error-aviso");
    err.hidden = !r.error;
    err.textContent = r.error ? "Aviso " + (i + 1) + ": " + r.error + "." : "";
    t.classList.toggle("con-error", !!r.error);
    if (r.error && !primero) primero = { t, msg: err.textContent };
    if (r.aviso) items.push(r.aviso);
  });
  if (primero) { primero.t.scrollIntoView({ block: "center", behavior: "smooth" }); return mostrar(primero.msg, false); }
  const b = $("guardar");
  b.disabled = true;
  try {
    // Si otra computadora guardó avisos mientras se editaba acá, se pregunta antes de pisarlos.
    const actual = await api("/avisos");
    if (JSON.stringify(actual.items || []) !== instantanea &&
        !confirm("Otra computadora cambió los avisos del TV mientras los editabas.\n\nSi guardás ahora, se reemplazan por lo que ves en esta pantalla.\n\n¿Guardar de todos modos?")) {
      mostrar("No se guardó. Recargá la página (F5) para ver los cambios de la otra computadora.", false);
      return;
    }
    const r = await api("/avisos/guardar", { items });
    cambios = false;
    const nuevo = await api("/avisos").catch(() => r);
    instantanea = JSON.stringify(nuevo.items || []);
    dibujar(r.items || items);
    b.textContent = "Guardar avisos en el TV";
    mostrar("Avisos guardados en el TV (" + items.length + ").", true);
  } catch (e) {
    mostrar("No se pudieron guardar: " + e.message, false);
  } finally {
    b.disabled = false;
  }
});

async function decirAhora(a, boton) {
  if (a.texto.replace(/[^\p{L}]/gu, "").length < 3) return mostrar("Escribí el texto del aviso.", false);
  boton.disabled = true;
  try {
    await api("/avisos/decir", { texto: a.texto, voz: a.voz, velocidad: a.velocidad, mostrar: a.mostrar });
    mostrar("El TV va a decir el aviso ahora (si está llamando a un paciente, apenas termine).", true);
  } catch (e) {
    mostrar("No se pudo enviar el aviso: " + e.message, false);
  } finally {
    setTimeout(() => { boton.disabled = false; }, 1500);
  }
}

VL.llenarSelect($("vozRapido"), "n-daniela", false);
$("decirRapido").addEventListener("click", () => decirAhora({
  texto: $("textoRapido").value.replace(/\s+/g, " ").trim(), voz: $("vozRapido").value,
  velocidad: $("velRapido").value, mostrar: $("mostrarRapido").checked
}, $("decirRapido")));

window.addEventListener("beforeunload", (e) => { if (cambios) { e.preventDefault(); e.returnValue = ""; } });
setInterval(() => [...$("avisos").children].forEach(actualizar), 60000);
cargar();
