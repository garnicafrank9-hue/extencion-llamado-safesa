// Avisos por voz para la sala de espera: se guardan en el TV y el TV los dice solo, a la hora indicada.
const $ = (id) => document.getElementById(id);
const VL = window.VocesLlamador;
const MAX_AVISOS = 12, MAX_TEXTO = 400;
const MAX_HORAS = 24;
const DIAS = [[1, "Lun"], [2, "Mar"], [3, "Mié"], [4, "Jue"], [5, "Vie"], [6, "Sáb"], [0, "Dom"]];
let cargado = false;      // solo se guarda si antes se leyó lo que tiene el TV (para no borrar nada sin querer)
let cambios = false;
let instantanea = "";     // lo que había en el TV cuando se abrió la página (para avisar si otra PC lo cambió)

function mostrar(msg, ok) {
  const e = $("estado");
  e.textContent = msg;
  e.className = "mensaje " + (ok ? "ok" : "error");
  clearTimeout(e._t);
  if (ok) e._t = setTimeout(() => { e.className = "mensaje"; }, 7000);
}

function api(ruta, cuerpo) {
  return new Promise((ok, mal) => {
    chrome.runtime.sendMessage({ tipo: "api", ruta, cuerpo }, (r) => {
      if (chrome.runtime.lastError) return mal(new Error("La extensión no respondió; recargá la página."));
      if (r && r.ok) ok(r); else mal(new Error(primeraMayuscula((r && r.error) || "sin respuesta del TV")));
    });
  });
}
function primeraMayuscula(s) { s = String(s); return s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : "."); }

function el(tag, props, hijos) {
  const e = document.createElement(tag);
  Object.assign(e, props || {});
  (hijos || []).forEach((h) => e.appendChild(typeof h === "string" ? document.createTextNode(h) : h));
  return e;
}

/** "9", "930", "9.30" -> "09:00", "09:30"; null si no es una hora. */
function normalizarHora(t) {
  t = String(t || "").trim();
  let m = /^(\d{1,2})[:.,h ]?(\d{2})?$/.exec(t);
  if (/^\d{3,4}$/.test(t)) m = [t, t.slice(0, t.length - 2), t.slice(-2)];
  if (!m) return null;
  const h = +m[1], mi = m[2] === undefined ? 0 : +m[2];
  if (h > 23 || mi > 59) return null;
  return String(h).padStart(2, "0") + ":" + String(mi).padStart(2, "0");
}
const aMin = (h) => +h.slice(0, 2) * 60 + +h.slice(3, 5);
const aHora = (m) => String(Math.floor(m / 60)).padStart(2, "0") + ":" + String(m % 60).padStart(2, "0");

/** "7:15, 09:00 14" -> ["07:15","09:00","14:00"] ordenadas y sin repetir; null si alguna no es una hora. */
function leerHoras(texto) {
  const partes = String(texto || "").split(/[,;\s]+/).filter(Boolean);
  const r = [];
  for (const p of partes) {
    const h = normalizarHora(p);
    if (!h) return null;
    if (!r.includes(h)) r.push(h);
  }
  return r.sort();
}

/** Avisos viejos ("cada 60 minutos entre 07:00 y 20:00") se muestran como una lista de horas. */
function horasDeAvisoViejo(a) {
  const d = normalizarHora(a.desde), h = normalizarHora(a.hasta);
  if (!a.repetir || !d || !h) return [];
  const r = [];
  for (let m = aMin(d); m <= aMin(h) && r.length < MAX_HORAS; m += a.repetir) r.push(aHora(m));
  return r;
}

// ---------- Tarjetas ----------

function tarjeta(a) {
  a = Object.assign({ id: "", texto: "", voz: "n-daniela", velocidad: "normal", repetir: 0, horas: [], desde: "07:00", hasta: "20:00",
    dias: [1, 2, 3, 4, 5], mostrar: true, activo: true }, a || {});
  if (!(a.horas && a.horas.length)) a.horas = horasDeAvisoViejo(a);
  const t = el("div", { className: "aviso-tarjeta" });
  t.dataset.id = a.id || "";
  const activo = el("input", { type: "checkbox", className: "activo", checked: a.activo !== false });
  const quitar = el("button", { type: "button", className: "quitar peligro", textContent: "Quitar" });
  const texto = el("textarea", { className: "texto", maxLength: MAX_TEXTO, value: a.texto, placeholder: "Por ejemplo: Les pedimos, por favor, mantener silencio en la sala de espera." });
  const idTexto = "t" + Math.random().toString(36).slice(2);
  texto.id = idTexto;
  const contador = el("div", { className: "contador" });
  const voz = el("select", { className: "voz" });
  VL.llenarSelect(voz, a.voz, false);
  const vel = el("select", { className: "vel" });
  [["lenta", "Lenta"], ["normal", "Normal"], ["rapida", "Rápida"]].forEach(([v, n]) => vel.add(new Option(n, v)));
  vel.value = a.velocidad || "normal";
  const rep = el("select", { className: "repetir" });
  [["0", "Solo cuando lo pida"], ["1", "Automático, a estas horas"]].forEach(([v, n]) => rep.add(new Option(n, v)));
  rep.value = a.horas.length ? "1" : "0";
  const horas = el("input", { type: "text", className: "horas-av", value: a.horas.join(", "), placeholder: "07:15, 09:00, 11:30", maxLength: 200, autocomplete: "off" });
  horas.setAttribute("aria-label", "Horas");
  const dias = el("div", { className: "dias", role: "group" });
  dias.setAttribute("aria-label", "Días");
  DIAS.forEach(([d, n]) => dias.appendChild(el("label", {}, [el("input", { type: "checkbox", value: String(d), checked: (a.dias || []).includes(d) }), el("span", { textContent: n })])));
  const horario = el("div", { className: "horario" }, [el("label", { textContent: "Horas" }), horas, dias]);
  const mostrarChk = el("input", { type: "checkbox", className: "mostrar", checked: a.mostrar !== false });
  const decir = el("button", { type: "button", textContent: "Decir ahora en el TV" });
  const ids = ["v", "r", "s"].map((x) => x + Math.random().toString(36).slice(2));
  voz.id = ids[0]; rep.id = ids[1]; vel.id = ids[2];

  t.append(
    el("div", { className: "aviso-cab" }, [el("b", { className: "num" }), el("label", { className: "check" }, [activo, " Activo"]), el("span", { className: "espacio" }), quitar]),
    el("label", { htmlFor: idTexto, className: "solo-lectores", textContent: "Texto del aviso" }),
    texto, contador,
    el("div", { className: "opciones-aviso" }, [
      el("div", {}, [el("label", { htmlFor: ids[1], textContent: "Cuándo se dice" }), rep]),
      el("div", {}, [el("label", { htmlFor: ids[0], textContent: "Voz" }), voz]),
      el("div", {}, [el("label", { htmlFor: ids[2], textContent: "Velocidad" }), vel])
    ]),
    horario,
    el("div", { className: "proximas" }),
    el("div", { className: "acciones-aviso" }, [decir, el("label", { className: "check" }, [mostrarChk, " Mostrar el texto en la pantalla del TV"])]),
    el("div", { className: "error-aviso", hidden: true })
  );

  horas.addEventListener("blur", () => { const h = leerHoras(horas.value); if (h) horas.value = h.join(", "); actualizar(t); });
  rep.addEventListener("change", () => { if (rep.value === "1" && !horas.value.trim()) horas.focus(); });
  t.addEventListener("input", () => { marcar(); actualizar(t); });
  t.addEventListener("change", () => { marcar(); actualizar(t); });
  quitar.addEventListener("click", () => { t.remove(); numerar(); marcar(); });
  decir.addEventListener("click", () => decirAhora(leerTarjeta(t, true), decir));
  actualizar(t);
  return t;
}

function leerTarjeta(t, sinValidar) {
  const g = (s) => t.querySelector(s);
  const automatico = g(".repetir").value === "1";
  const lista = leerHoras(g(".horas-av").value);
  const a = {
    id: t.dataset.id || undefined,
    texto: g(".texto").value.replace(/\s+/g, " ").trim(),
    voz: g(".voz").value,
    velocidad: g(".vel").value,
    repetir: 0,
    horas: automatico && lista ? lista : [],
    desde: "07:00",
    hasta: "20:00",
    dias: [...t.querySelectorAll(".dias input:checked")].map((i) => +i.value),
    mostrar: g(".mostrar").checked,
    activo: g(".activo").checked
  };
  if (!a.dias.length && !automatico) a.dias = [1, 2, 3, 4, 5];
  if (sinValidar) return a;
  let e = "";
  if (a.texto.replace(/[^\p{L}]/gu, "").length < 3) e = "escribí el texto del aviso";
  else if (automatico && lista === null) e = "revisá las horas (por ejemplo 07:15, 09:00)";
  else if (automatico && !lista.length) e = "escribí al menos una hora, o elegí «Solo cuando lo pida»";
  else if (automatico && lista.length > MAX_HORAS) e = "como máximo " + MAX_HORAS + " horas";
  else if (automatico && !a.dias.length) e = "elegí al menos un día";
  return e ? { error: e } : { aviso: a };
}

// Cuenta de letras, horario visible y próximas veces de hoy.
function actualizar(t) {
  const a = leerTarjeta(t, true);
  const automatico = t.querySelector(".repetir").value === "1";
  const c = t.querySelector(".contador");
  c.textContent = a.texto.length + " / " + MAX_TEXTO;
  c.classList.toggle("mucho", a.texto.length > MAX_TEXTO - 30);
  t.classList.toggle("apagado", !a.activo);
  t.querySelector(".horario").classList.toggle("apagado", !automatico);
  const p = t.querySelector(".proximas");
  p.className = "proximas";
  if (!a.activo) { p.textContent = "Desactivado: no se dice solo."; p.classList.add("nada"); return; }
  if (!automatico) { p.textContent = "Se dice solo cuando tocás «Decir ahora en el TV»."; p.classList.add("nada"); return; }
  if (!a.horas.length) { p.textContent = ""; return; }
  const ahora = new Date();
  if (!a.dias.includes(ahora.getDay())) { p.textContent = "Hoy no se dice (no es uno de los días marcados)."; p.classList.add("nada"); return; }
  const min = ahora.getHours() * 60 + ahora.getMinutes();
  const proximas = a.horas.filter((h) => aMin(h) >= min);
  if (!proximas.length) { p.textContent = "Por hoy ya no se dice más."; p.classList.add("nada"); return; }
  p.textContent = "Hoy se dice a las: " + proximas.slice(0, 6).join(", ") + (proximas.length > 6 ? "…" : "") + (cambios ? " (cuando guardes)" : "");
}

function numerar() {
  const ts = [...$("avisos").children];
  ts.forEach((t, i) => { t.querySelector(".num").textContent = "Aviso " + (i + 1); });
  $("sinAvisos").hidden = ts.length > 0 || !cargado;
  $("agregar").disabled = ts.length >= MAX_AVISOS;
}

function marcar() {
  if (!cambios) { cambios = true; [...$("avisos").children].forEach(actualizar); }
  $("guardar").textContent = "Guardar avisos en el TV •";
}

function dibujar(items) {
  $("avisos").innerHTML = "";
  items.forEach((a) => $("avisos").appendChild(tarjeta(a)));
  numerar();
}

// ---------- Acciones ----------

async function cargar() {
  try {
    const r = await api("/avisos");
    cargado = true;
    cambios = false;
    instantanea = JSON.stringify(r.items || []);
    dibujar(r.items || []);
    $("guardar").textContent = "Guardar avisos en el TV";
  } catch (e) {
    mostrar("No se pudieron leer los avisos del TV: " + e.message + " Revisá la conexión y recargá la página.", false);
  }
}

$("agregar").addEventListener("click", () => {
  if (!cargado) return mostrar("Primero tiene que responder el TV (para no borrar los avisos que ya tiene).", false);
  const t = tarjeta({ texto: "" });
  $("avisos").appendChild(t);
  numerar();
  marcar();
  t.querySelector(".texto").focus();
});

$("guardar").addEventListener("click", async () => {
  if (!cargado) return mostrar("Primero tiene que responder el TV (para no borrar los avisos que ya tiene). Recargá la página.", false);
  const items = [];
  let primero = null;
  [...$("avisos").children].forEach((t, i) => {
    const r = leerTarjeta(t);
    const err = t.querySelector(".error-aviso");
    err.hidden = !r.error;
    err.textContent = r.error ? "Aviso " + (i + 1) + ": " + r.error + "." : "";
    t.classList.toggle("con-error", !!r.error);
    if (r.error && !primero) primero = { t, msg: err.textContent };
    if (r.aviso) items.push(r.aviso);
  });
  if (primero) { primero.t.scrollIntoView({ block: "center", behavior: "smooth" }); return mostrar(primero.msg, false); }
  const b = $("guardar");
  b.disabled = true;
  try {
    // Si otra computadora guardó avisos mientras se editaba acá, se pregunta antes de pisarlos.
    const actual = await api("/avisos");
    if (JSON.stringify(actual.items || []) !== instantanea &&
        !confirm("Otra computadora cambió los avisos del TV mientras los editabas.\n\nSi guardás ahora, se reemplazan por lo que ves en esta pantalla.\n\n¿Guardar de todos modos?")) {
      mostrar("No se guardó. Recargá la página (F5) para ver los cambios de la otra computadora.", false);
      return;
    }
    const r = await api("/avisos/guardar", { items });
    cambios = false;
    const nuevo = await api("/avisos").catch(() => r);
    instantanea = JSON.stringify(nuevo.items || []);
    dibujar(r.items || items);
    b.textContent = "Guardar avisos en el TV";
    mostrar("Avisos guardados en el TV (" + items.length + ").", true);
  } catch (e) {
    mostrar("No se pudieron guardar: " + e.message, false);
  } finally {
    b.disabled = false;
  }
});

async function decirAhora(a, boton) {
  if (a.texto.replace(/[^\p{L}]/gu, "").length < 3) return mostrar("Escribí el texto del aviso.", false);
  boton.disabled = true;
  try {
    await api("/avisos/decir", { texto: a.texto, voz: a.voz, velocidad: a.velocidad, mostrar: a.mostrar });
    mostrar("El TV va a decir el aviso ahora (si está llamando a un paciente, apenas termine).", true);
  } catch (e) {
    mostrar("No se pudo enviar el aviso: " + e.message, false);
  } finally {
    setTimeout(() => { boton.disabled = false; }, 1500);
  }
}

VL.llenarSelect($("vozRapido"), "n-daniela", false);
$("decirRapido").addEventListener("click", () => decirAhora({
  texto: $("textoRapido").value.replace(/\s+/g, " ").trim(), voz: $("vozRapido").value,
  velocidad: $("velRapido").value, mostrar: $("mostrarRapido").checked
}, $("decirRapido")));

window.addEventListener("beforeunload", (e) => { if (cambios) { e.preventDefault(); e.returnValue = ""; } });
setInterval(() => [...$("avisos").children].forEach(actualizar), 60000);
cargar();
