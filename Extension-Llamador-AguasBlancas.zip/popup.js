// Panel rápido al tocar el ícono de la extensión.
const $ = (id) => document.getElementById(id);
const PREDETERMINADO = { consultorio: "", ipTv: "", codigo: "", voz: "auto", tono: "normal", velocidad: "normal" };

function mensaje(texto, ok) {
  $("msg").textContent = texto;
  $("msg").className = "mensaje " + (ok ? "ok" : "error");
}

Almacen.get(PREDETERMINADO).then((c) => {
  const num = /(\d+)/.exec(c.consultorio || "");
  $("consul").textContent = !c.consultorio ? "Sin configurar" : num ? "Consultorio " + parseInt(num[1], 10) : c.consultorio;
  if (!c.consultorio || (!c.ipTv && !c.codigo)) {
    $("probar").disabled = true;
    mensaje("Falta configurar el consultorio y la conexión con el TV.", false);
  }
  $("probar").addEventListener("click", () => {
    $("probar").disabled = true;
    chrome.runtime.sendMessage({
      tipo: "prueba",
      datos: { paciente: "PRUEBA", consultorio: c.consultorio, voz: c.voz, tono: c.tono, velocidad: c.velocidad, prueba: true }
    }, (r) => {
      $("probar").disabled = false;
      if (r && r.ok) mensaje("Prueba enviada. Debería verse y escucharse en el TV.", true);
      else mensaje("No se pudo llamar en el TV: " + (r ? r.error : "sin respuesta") + ".", false);
    });
  });
});

$("config").addEventListener("click", () => { chrome.runtime.openOptionsPage(); window.close(); });
$("horarios").addEventListener("click", () => { chrome.tabs.create({ url: "horarios.html" }); window.close(); });
$("avisos").addEventListener("click", () => { chrome.tabs.create({ url: "avisos.html" }); window.close(); });
$("publi").addEventListener("click", () => { chrome.tabs.create({ url: "publicidad.html" }); window.close(); });
$("actualizar").addEventListener("click", () => { chrome.tabs.create({ url: "actualizaciones.html" }); window.close(); });
$("verAct").addEventListener("click", (e) => { e.preventDefault(); chrome.tabs.create({ url: "actualizaciones.html" }); window.close(); });

// ¿El TV avisa que hay una versión nueva de esta extensión?
function masNueva(a, b) {
  const x = String(a).split(".").map((n) => parseInt(n, 10) || 0), y = String(b).split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  return false;
}
chrome.runtime.sendMessage({ tipo: "api", ruta: "/actualizar/estado" }, (r) => {
  if (chrome.runtime.lastError || !r || !r.ok || !r.extension || !r.extension.version) return;
  if (masNueva(r.extension.version, chrome.runtime.getManifest().version)) $("extNueva").hidden = false;
});
