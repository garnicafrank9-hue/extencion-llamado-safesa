// Voces latinas incluidas en la app del TV (mismo orden que en el TV: así se reparten en "Automática").
// La muestra de cada voz dice "María Fernanda Gutiérrez, consultorio tres" (se escucha en esta PC).
(function () {
  const VOCES = [
    { id: "n-daniela", nombre: "Daniela", genero: "femenina", acento: "Argentina", nativa: true },
    { id: "n-alejandro", nombre: "Alejandro", genero: "masculina", acento: "México", nativa: true, rapida: true },
    { id: "n-claudia", nombre: "Claudia", genero: "femenina", acento: "México", nativa: true, rapida: true },
    { id: "n-mateo", nombre: "Mateo", genero: "masculina", acento: "Latino neutro" },
    { id: "n-sofia", nombre: "Sofía", genero: "femenina", acento: "Latino neutro" },
    { id: "n-diego", nombre: "Diego", genero: "masculina", acento: "Latino neutro" },
    { id: "n-lucia", nombre: "Lucía", genero: "femenina", acento: "Latino neutro" },
    { id: "n-martin", nombre: "Martín", genero: "masculina", acento: "Latino neutro" },
    { id: "n-valentina", nombre: "Valentina", genero: "femenina", acento: "Latino neutro" },
    { id: "n-tomas", nombre: "Tomás", genero: "masculina", acento: "Latino neutro" },
    { id: "n-camila", nombre: "Camila", genero: "femenina", acento: "Latino neutro" },
    { id: "n-joaquin", nombre: "Joaquín", genero: "masculina", acento: "Latino neutro" },
    { id: "n-julieta", nombre: "Julieta", genero: "femenina", acento: "Latino neutro" }
  ];

  let sonando = null; // { audio, boton }

  function parar() {
    if (!sonando) return;
    sonando.audio.pause();
    sonando.boton.classList.remove("sonando");
    sonando.boton.setAttribute("aria-label", "Escuchar a " + sonando.voz.nombre);
    sonando = null;
  }

  /** Botón ▶ que reproduce en esta PC la muestra de la voz. */
  function botonMuestra(v) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "muestra";
    b.setAttribute("aria-label", "Escuchar a " + v.nombre);
    b.title = "Escuchar la muestra en esta PC";
    b.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="ic-play" d="M8 5.5v13l11-6.5z"/><path class="ic-pausa" d="M7 5h3.6v14H7zM13.4 5H17v14h-3.6z"/></svg>';
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const era = sonando && sonando.voz === v;
      parar();
      if (era) return;
      const audio = new Audio("voces/" + v.id + ".mp3");
      sonando = { audio, boton: b, voz: v };
      b.classList.add("sonando");
      b.setAttribute("aria-label", "Detener la muestra de " + v.nombre);
      audio.addEventListener("ended", () => { if (sonando && sonando.audio === audio) parar(); });
      audio.play().catch(parar);
    });
    return b;
  }

  /** Voz que usa "Automática" para un número de consultorio, entre las voces disponibles. */
  function automatica(consultorio, disponibles) {
    const lista = disponibles && disponibles.length ? VOCES.filter((v) => disponibles.includes(v.id)) : VOCES;
    const n = parseInt((/(\d+)/.exec(String(consultorio || "")) || [0, 1])[1], 10) || 1;
    return lista[(n - 1) % lista.length];
  }

  /** <select> con las voces agrupadas (para los avisos). */
  function llenarSelect(sel, valor, conAutomatica) {
    sel.innerHTML = "";
    if (conAutomatica) sel.add(new Option("Automática", "auto"));
    [["femenina", "Voces femeninas"], ["masculina", "Voces masculinas"]].forEach(([g, t]) => {
      const grupo = document.createElement("optgroup");
      grupo.label = t;
      VOCES.filter((v) => v.genero === g).forEach((v) => grupo.appendChild(new Option(v.nombre + " · " + v.acento, v.id)));
      sel.appendChild(grupo);
    });
    sel.value = [...sel.options].some((o) => o.value === valor) ? valor : sel.options[0].value;
  }

  window.VocesLlamador = { VOCES, botonMuestra, parar, automatica, llenarSelect, buscar: (id) => VOCES.find((v) => v.id === id) };
})();
