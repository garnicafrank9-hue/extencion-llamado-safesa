// Voces latinas incluidas en la app del TV (mismo orden que en el TV).
// La muestra de cada voz dice "Pérez. Diríjase al consultorio tres." (se escucha en esta PC).
(function () {
  const VOCES = [
    { id: "n-claudia", nombre: "Claudia", genero: "femenina", acento: "México", nativa: true, rapida: true, recomendada: true },
    { id: "n-elena", nombre: "Elena", genero: "femenina", acento: "España", nativa: true, rapida: true },
    { id: "n-daniela", nombre: "Daniela", genero: "femenina", acento: "Argentina", nativa: true },
    { id: "n-alejandro", nombre: "Alejandro", genero: "masculina", acento: "México", nativa: true, rapida: true, menosClara: true },
    { id: "n-pablo", nombre: "Pablo", genero: "masculina", acento: "España", nativa: true, rapida: true },
    { id: "n-david", nombre: "David", genero: "masculina", acento: "España", nativa: true, rapida: true }
  ];

  // La voz de fábrica del TV (la de Google, español latino si el TV la tiene): sale al instante y no hace falta prepararla.
  const VOZ_TV = { id: "sistema", nombre: "Voz del TV", genero: "", acento: "", sistema: true, rapida: true };

  let sonando = null; // { audio, boton }

  function parar() {
    if (!sonando) return;
    sonando.audio.pause();
    sonando.boton.classList.remove("sonando");
    sonando.boton.setAttribute("aria-label", "Escuchar a " + sonando.voz.nombre);
    sonando = null;
  }

  /** Botón ▶ que reproduce en esta PC la muestra de la voz. */
  function botonMuestra(v) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "muestra";
    b.setAttribute("aria-label", "Escuchar a " + v.nombre);
    b.title = "Escuchar la muestra en esta PC";
    b.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="ic-play" d="M8 5.5v13l11-6.5z"/><path class="ic-pausa" d="M7 5h3.6v14H7zM13.4 5H17v14h-3.6z"/></svg>';
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const era = sonando && sonando.voz === v;
      parar();
      if (era) return;
      const audio = new Audio("voces/" + v.id + ".mp3");
      sonando = { audio, boton: b, voz: v };
      b.classList.add("sonando");
      b.setAttribute("aria-label", "Detener la muestra de " + v.nombre);
      audio.addEventListener("ended", () => { if (sonando && sonando.audio === audio) parar(); });
      audio.play().catch(parar);
    });
    return b;
  }

  /**
   * Voz que usa "Automática" (igual que en el TV): Claudia, en todos los consultorios. Es la que sale al instante y mejor
   * se entiende por los parlantes de un TV. Si el TV todavía no la descargó, otra rápida y, si tampoco, la que tenga.
   */
  function automatica(consultorio, disponibles) {
    const hay = (v) => !disponibles || !disponibles.length || disponibles.includes(v.id);
    const claudia = VOCES.find((v) => v.recomendada && hay(v));
    if (claudia) return claudia;
    const rapida = VOCES.find((v) => v.rapida && hay(v));
    if (rapida) return rapida;
    const n = parseInt((/(\d+)/.exec(String(consultorio || "")) || [0, 1])[1], 10) || 1;
    const lista = VOCES.filter(hay);
    const base = lista.length ? lista : VOCES;
    return base[(n - 1) % base.length];
  }

  /** <select> con las voces agrupadas (para los avisos). */
  function llenarSelect(sel, valor, conAutomatica) {
    sel.innerHTML = "";
    if (conAutomatica) sel.add(new Option("Automática", "auto"));
    [["femenina", "Voces femeninas"], ["masculina", "Voces masculinas"]].forEach(([g, t]) => {
      const grupo = document.createElement("optgroup");
      grupo.label = t;
      VOCES.filter((v) => v.genero === g).forEach((v) => grupo.appendChild(new Option(v.nombre + " · " + v.acento, v.id)));
      sel.appendChild(grupo);
    });
    sel.value = [...sel.options].some((o) => o.value === valor) ? valor : sel.options[0].value;
  }

  window.VocesLlamador = { VOCES, VOZ_TV, botonMuestra, parar, automatica, llenarSelect, buscar: (id) => id === VOZ_TV.id ? VOZ_TV : VOCES.find((v) => v.id === id) };
})();
