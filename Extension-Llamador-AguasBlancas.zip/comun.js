// Comportamiento común de las páginas: indicador de conexión con el TV en la barra superior.
(function () {
  const pill = document.getElementById("conexionTv");
  if (!pill) return;

  async function revisar() {
    const c = await Almacen.get({ ipTv: "", codigo: "" });
    if (!c.ipTv && !c.codigo) {
      pill.className = "conexion";
      pill.textContent = "TV sin configurar";
      return;
    }
    chrome.runtime.sendMessage({ tipo: "estado" }, (r) => {
      if (chrome.runtime.lastError) return;
      if (r && r.ok) {
        pill.className = "conexion ok";
        pill.textContent = r.via === "internet" ? "TV conectado por internet" : "TV conectado";
        pill.title = (r.via === "internet" ? "Conexión cifrada por internet" : "TV en " + c.ipTv) + (r.dispositivo ? " (" + r.dispositivo + ")" : "");
      } else {
        pill.className = "conexion error";
        pill.textContent = "Sin conexión con el TV";
        pill.title = r && r.error ? r.error : "";
      }
    });
  }

  window.revisarConexionTv = revisar;
  revisar();
  setInterval(revisar, 30000);
})();
